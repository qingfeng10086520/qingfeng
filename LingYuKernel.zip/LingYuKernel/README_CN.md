# LingYuKernel 中文文档

LingYuKernel 是一个面向 ARM64 Android GKI 内核的 Linux 内核模块项目。项目代码围绕进程查询、内存访问、输入控制、系统调用追踪、硬件断点、模块隐藏、进程隐藏和路径隐藏等能力组织。

仓库中 `src/` 保存内核模块源码，`out/` 保存构建后的模块产物。

## 功能概览

- 进程工具
  - 按进程名查找 PID。
  - 检查进程是否存活。
  - 读取进程基础信息和模块基址信息。
  - 支持进程间内存复制。

- 内存工具
  - 将进程虚拟地址转换为物理地址。
  - 通过页表路径或 ioremap 路径读写物理内存。
  - 查询页表项和页面信息。
  - 维护 PTE window 辅助逻辑，用于优化重复物理内存读取。

- 隐藏与过滤
  - 从常规模块列表中隐藏内核模块。
  - 从 `/proc` 遍历结果中隐藏指定 PID。
  - 对指定路径进行隐藏过滤。
  - 对部分信号路径进行过滤保护。

- 输入与传感器控制
  - 支持多种后端模式的触摸事件注入。
  - 支持基于 fops 的触摸 read/poll hook 路径。
  - 支持基于 `input_handle_event` 的事件提交路径。
  - 支持陀螺仪/加速度计数据覆盖辅助逻辑。

- 追踪与执行辅助
  - 支持指定进程 syscall 追踪。
  - 支持基于 task work 的远程调用辅助逻辑。
  - 支持 ARM64 硬件断点/观察点信息读取、设置和清理。
  - 提供 ARM64 inline hook 辅助能力，并包含基础目标校验。

## 项目结构

```text
LingYuKernel/
├── README.md              # 英文项目文档
├── README_CN.md           # 中文项目文档
├── .gitignore             # Git 上传忽略规则
├── docs/
│   └── SDK_USAGE_CN.md    # SDK 对接说明
├── sdk/
│   ├── lingyu_kernel_sdk.h
│   └── examples/
│       └── basic_usage.c
├── out/
│   ├── LinYuKernel.ko     # stripped 发行版模块
│   └── LinYuKernel.debug.ko
└── src/
    ├── Makefile
    ├── comm.h             # ioctl ABI 和协议结构
    ├── linyu.h            # 模块内部共享声明
    ├── entry.c            # 模块生命周期和 ioctl 分发
    ├── memory.c
    ├── process.c
    ├── pte_window.c
    ├── hide.c
    ├── hide_vfs.c
    ├── touch.c
    ├── gyro.c
    ├── remote_call.c
    ├── safe_signal.c
    ├── syscall_trace.c
    ├── hwbp.c
    ├── inline_hook.c
    ├── arraylist.c
    └── README.md          # 重构与验证记录
```

## 构建方式

默认内核源码路径在 `src/Makefile` 中配置：

```sh
cd src
make
```

如果需要指定其他内核源码目录：

```sh
cd src
make KDIR=/path/to/kernel/common
```

当前构建参数：

- `ARCH=arm64`
- `LLVM=1`
- `LLVM_IAS=1`
- `KBUILD_MODPOST_WARN=1`
- `CONFIG_DEBUG_INFO_BTF_MODULES=`

## 输出产物

构建成功后：

- `out/LinYuKernel.ko`：已移除调试段的发行版模块，推荐部署时使用。
- `out/LinYuKernel.debug.ko`：保留调试段的调试版模块，适合定位问题。
- `src/LinYuKernel.ko`：Kbuild 构建过程中的临时原始产物，不建议作为 GitHub 上传发行文件。

当前验证体积：

- 发行版模块：约 `182K`。
- 调试版模块：约 `1.4M`。

## 清理方式

```sh
cd src
make clean
```

仓库根目录的 `.gitignore` 已忽略常见 Kbuild 中间文件，例如 `.cmd`、`.o`、`.mod`、`Module.symvers`、`modules.order` 等，避免上传编译垃圾。

## 部署示例

推送并加载发行版模块：

```sh
adb push out/LinYuKernel.ko /data/local/tmp/LinYuKernel.ko
adb shell 'su -c "insmod /data/local/tmp/LinYuKernel.ko"'
```

如果设备上已有旧模块实例，可以先尝试卸载：

```sh
adb shell 'su -c "rmmod LinYuKernel 2>/dev/null || true"'
```

模块初始化时可能会执行自隐藏逻辑，因此加载成功后，`/proc/modules` 和 `/sys/module/LinYuKernel` 不一定能看到模块条目。

## 构建警告说明

当前本地内核构建目录没有匹配目标内核的 `Module.symvers`。因此即使源码编译和最终链接成功，`modpost` 仍可能报告 unresolved symbol 警告。

如果需要彻底消除这些警告，需要提供与目标内核构建完全匹配的 `Module.symvers`。

## 开发说明

- 保留函数统一使用 `linyu_` 前缀。
- 默认关闭 info 级调试日志，只有显式定义 `LINYU_DEBUG_LOG` 时才输出。
- 默认不启用 CFI handler patch 和 kprobe blacklist 改写逻辑。
- 该模块依赖 ARM64/GKI 内核符号和结构体布局，不同内核版本之间需要重新实机验证。
