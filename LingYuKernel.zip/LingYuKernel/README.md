# LingYuKernel

[中文文档](README_CN.md) | [SDK 使用说明](docs/SDK_USAGE_CN.md)

LingYuKernel is an ARM64 Android GKI Linux kernel module project. The source code is organized around process inspection, memory access, input control, syscall tracing, hardware breakpoint support, and module/process/path hiding helpers.

This repository keeps the kernel module source in `src/` and generated module outputs in `out/`.

## Features

- Process utilities
  - Find process ID by name.
  - Check whether a process is alive.
  - Read process metadata and module base information.
  - Copy memory between processes.

- Memory utilities
  - Translate process virtual addresses to physical addresses.
  - Read/write physical memory through page table and ioremap based paths.
  - Inspect page table entries and page metadata.
  - Maintain PTE window helpers for faster repeated reads.

- Visibility control
  - Hide kernel module entry from regular module listing.
  - Hide selected process IDs from `/proc` iteration.
  - Hide selected paths from selected VFS/open paths.
  - Filter selected signal paths.

- Input and sensor control
  - Touch event injection with multiple backend modes.
  - Fops based touch read/poll hook path.
  - `input_handle_event` based event flush path.
  - Gyroscope/accelerometer value override helpers.

- Tracing and execution helpers
  - Syscall tracing for selected processes.
  - Remote call support through task work.
  - Hardware breakpoint/watchpoint information, setup, and cleanup.
  - ARM64 inline hook helper with basic target validation.

## Project Layout

```text
LingYuKernel/
├── README.md              # GitHub-facing project documentation
├── README_CN.md           # Chinese project documentation
├── docs/
│   └── SDK_USAGE_CN.md    # SDK integration guide
├── sdk/
│   ├── lingyu_kernel_sdk.h
│   └── examples/
│       └── basic_usage.c
├── out/
│   ├── LinYuKernel.ko     # stripped release module
│   └── LinYuKernel.debug.ko
└── src/
    ├── Makefile
    ├── comm.h             # ioctl ABI
    ├── linyu.h            # shared internal declarations
    ├── entry.c            # module lifecycle and ioctl dispatch
    ├── memory.c
    ├── process.c
    ├── pte_window.c
    ├── hide.c
    ├── hide_vfs.c
    ├── touch.c
    ├── gyro.c
    ├── remote_call.c
    ├── safe_signal.c
    ├── syscall_trace.c
    ├── hwbp.c
    ├── inline_hook.c
    ├── arraylist.c
    └── README.md          # refactor and verification notes
```

## Build

The default kernel source path is configured in `src/Makefile`:

```sh
cd src
make
```

To build against another kernel tree:

```sh
cd src
make KDIR=/path/to/kernel/common
```

The build uses:

- `ARCH=arm64`
- `LLVM=1`
- `LLVM_IAS=1`
- `KBUILD_MODPOST_WARN=1`
- `CONFIG_DEBUG_INFO_BTF_MODULES=`

## Outputs

After a successful build:

- `out/LinYuKernel.ko` is the stripped release module. This is the recommended file for deployment.
- `out/LinYuKernel.debug.ko` keeps debug sections and is useful for troubleshooting.
- `src/LinYuKernel.ko` may be produced during build, but it is a temporary Kbuild output and should not be uploaded as the release artifact.

Current verified size:

- Release module: about `182K`.
- Debug module: about `1.4M`.

## Clean

```sh
cd src
make clean
```

The repository `.gitignore` also excludes common Kbuild intermediate files such as `.cmd`, `.o`, `.mod`, `Module.symvers`, and `modules.order`.

## Deployment

Example deployment flow:

```sh
adb push out/LinYuKernel.ko /data/local/tmp/LinYuKernel.ko
adb shell 'su -c "insmod /data/local/tmp/LinYuKernel.ko"'
```

If an older module instance is loaded:

```sh
adb shell 'su -c "rmmod LinYuKernel 2>/dev/null || true"'
```

The module can hide itself during initialization. Because of that, `/proc/modules` and `/sys/module/LinYuKernel` may not show the module after successful loading.

## Build Warnings

The current local kernel tree does not contain a matching `Module.symvers`. Because of that, `modpost` may report unresolved-symbol warnings even when compilation and final linking complete successfully.

To remove those warnings completely, provide the `Module.symvers` that matches the target kernel build.

## Notes

- All retained internal functions follow the `linyu_` prefix convention.
- Default info-level debug logging is disabled unless `LINYU_DEBUG_LOG` is explicitly defined.
- CFI handler patching and kprobe blacklist rewriting are not enabled by default.
- This module depends on ARM64/GKI kernel symbol availability and structure layouts, so real-device validation is required when switching kernel versions.
