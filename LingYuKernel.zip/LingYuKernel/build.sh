#!/bin/bash
# ============================================================================
# LingYuKernel - 一键编译脚本
# ============================================================================

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SRC_DIR="$SCRIPT_DIR/src"
OUT_DIR="$SCRIPT_DIR/out"
KDIR="${KDIR:-$HOME/gki-kernel/common}"

echo "========================================"
echo "  LingYuKernel 编译工具"
echo "========================================"
echo "  内核源码: $KDIR"
echo "  驱动源码: $SRC_DIR"
echo "  输出目录: $OUT_DIR"
echo "========================================"
echo ""

case "${1:-build}" in
    build)
        echo "[*] 开始编译..."
        make -C "$SRC_DIR" KDIR="$KDIR" -j$(nproc)
        ;;
    clean)
        echo "[*] 清理编译产物..."
        make -C "$SRC_DIR" KDIR="$KDIR" clean
        ;;
    push)
        echo "[*] 推送到设备..."
        if [ ! -f "$OUT_DIR/LinYuKernel.ko" ]; then
            echo "[!] 错误: out/LinYuKernel.ko 不存在, 请先编译"
            exit 1
        fi
        adb push "$OUT_DIR/LinYuKernel.ko" /data/local/tmp/LinYuKernel.ko
        echo "[*] 推送完成: /data/local/tmp/LinYuKernel.ko"
        ;;
    load)
        echo "[*] 加载驱动..."
        adb shell "/system/bin/su -c 'insmod /data/local/tmp/LinYuKernel.ko'"
        adb shell "/system/bin/su -c 'lsmod | grep LinYuKernel || true'"
        adb shell "/system/bin/su -c 'dmesg | grep -i linyu | tail -5 || true'"
        ;;
    unload)
        echo "[*] 卸载驱动..."
        adb shell "/system/bin/su -c 'rmmod LinYuKernel'"
        ;;
    all)
        "$0" build && "$0" push && "$0" load
        ;;
    *)
        echo "用法: $0 {build|clean|push|load|unload|all}"
        echo ""
        echo "  build   - 编译驱动模块"
        echo "  clean   - 清理编译产物"
        echo "  push    - 推送 .ko 到设备"
        echo "  load    - insmod 加载驱动"
        echo "  unload  - rmmod 卸载驱动"
        echo "  all     - 编译 + 推送 + 加载"
        ;;
esac
