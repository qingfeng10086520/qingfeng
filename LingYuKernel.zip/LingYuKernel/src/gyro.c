#include "linyu.h"
#include "comm.h"
#include <linux/kprobes.h>
#include <linux/uaccess.h>
#include <linux/sched.h>
#include <linux/string.h>

#define SENSOR_EVENT_SIZE 104        
#define SENSOR_TYPE_OFF   16         
#define SENSOR_XY_OFF     24         
#define SENDTO_LEN_MAX    (1000 * SENSOR_EVENT_SIZE)

#define GYRO_TYPE_GYRO   0x01  
#define GYRO_TYPE_ACCEL  0x02  

bool   g_gyro_enabled;
int    g_gyro_type_mask = GYRO_TYPE_GYRO | GYRO_TYPE_ACCEL;
int    g_gyro_x_raw;        
int    g_gyro_y_raw;        

static pid_t cached_ss_tgid = -1;

static struct kprobe sendto_kp;
static bool sendto_kp_registered;
static bool hooked_syscall_wrapper; 

u32 linyu_add_float_ieee754(u32 a, u32 b)
{
	u32 a_exp = (a >> 23) & 0xFF;
	u32 b_exp = (b >> 23) & 0xFF;
	u32 a_sign, b_sign, out_sign;
	u64 a_mant, b_mant, sum;
	u32 out_exp;

	if (a_exp == 0)
		return b;
	if (b_exp == 0)
		return a;
	if (a_exp == 0xFF)
		return a;
	if (b_exp == 0xFF)
		return b;

	a_sign = a & 0x80000000u;
	b_sign = b & 0x80000000u;
	a_mant = (u64)(a & 0x7FFFFFu) | 0x800000ULL;
	b_mant = (u64)(b & 0x7FFFFFu) | 0x800000ULL;

	
	if (a_exp < b_exp) {
		a_mant >>= (b_exp - a_exp);
		out_exp = b_exp;
	} else {
		b_mant >>= (a_exp - b_exp);
		out_exp = a_exp;
	}

	if (a_sign == b_sign) {
		sum = a_mant + b_mant;
		out_sign = a_sign;
	} else if (a_mant >= b_mant) {
		sum = a_mant - b_mant;
		out_sign = a_sign;
	} else {
		sum = b_mant - a_mant;
		out_sign = b_sign;
	}

	if (sum == 0)
		return 0;

	
	while ((sum >> 24) && out_exp <= 0xFD) {
		sum >>= 1;
		out_exp++;
	}
	
	while (!(sum & 0x800000) && out_exp > 1) {
		sum <<= 1;
		out_exp--;
	}

	return (u32)(out_sign | (out_exp << 23) | (sum & 0x7FFFFFu));
}

static bool linyu_gyro_caller_is_system_server(void)
{
	pid_t tgid = current->tgid;
	pid_t cached = READ_ONCE(cached_ss_tgid);

	if (tgid == cached)
		return true;

	if (strcmp(current->comm, "system_server") == 0) {
		WRITE_ONCE(cached_ss_tgid, tgid);
		return true;
	}
	return false;
}

static void linyu_gyro_hijack_one_event(unsigned long uevent, int type_mask, u32 dx, u32 dy)
{
	s32 type = 0;
	u32 xy[2] = { 0, 0 };

	if (copy_from_user(&type, (void __user *)(uevent + SENSOR_TYPE_OFF), sizeof(type)))
		return;

	{
		bool wants = false;
		if ((type_mask & GYRO_TYPE_ACCEL) && type == 16) wants = true;
		if ((type_mask & GYRO_TYPE_GYRO)  && type == 4)  wants = true;
		if (!wants)
			return;
	}

	if (copy_from_user(xy, (void __user *)(uevent + SENSOR_XY_OFF), sizeof(xy)))
		return;

	xy[0] = linyu_add_float_ieee754(xy[0], dx);
	xy[1] = linyu_add_float_ieee754(xy[1], dy);

	if (copy_to_user((void __user *)(uevent + SENSOR_XY_OFF), xy, sizeof(xy)))
		return;
}

static int linyu_gyro_sendto_pre(struct kprobe *p, struct pt_regs *regs)
{
	unsigned long uev;
	unsigned long len;
	int type_mask;
	u32 dx, dy;
	unsigned int n, i;

	if (!READ_ONCE(g_gyro_enabled))
		return 0;
	if (!linyu_gyro_caller_is_system_server())
		return 0;

	if (hooked_syscall_wrapper) {
		struct pt_regs *user = (struct pt_regs *)regs->regs[0];
		if (!user)
			return 0;
		uev = user->regs[1];
		len = user->regs[2];
	} else {
		uev = regs->regs[1];
		len = regs->regs[2];
	}

	if (!uev || !len || len > SENDTO_LEN_MAX)
		return 0;
	if (len % SENSOR_EVENT_SIZE)
		return 0;

	type_mask = READ_ONCE(g_gyro_type_mask);
	dx        = (u32)READ_ONCE(g_gyro_x_raw);
	dy        = (u32)READ_ONCE(g_gyro_y_raw);

	n = (unsigned int)(len / SENSOR_EVENT_SIZE);
	for (i = 0; i < n; i++)
		linyu_gyro_hijack_one_event(uev + (unsigned long)i * SENSOR_EVENT_SIZE,
				 type_mask, dx, dy);

	return 0;
}

int linyu_gyro_init(void)
{
	static const char *candidates[] = {
		"__arm64_sys_sendto",
		"__se_sys_sendto",
		"sys_sendto",
		NULL,
	};
	int i;

	if (sendto_kp_registered)
		return 0;

	for (i = 0; candidates[i]; i++) {
		memset(&sendto_kp, 0, sizeof(sendto_kp));
		sendto_kp.symbol_name = candidates[i];
		sendto_kp.pre_handler = linyu_gyro_sendto_pre;

		if (register_kprobe(&sendto_kp) == 0) {
			sendto_kp_registered = true;
			hooked_syscall_wrapper = (i == 0); 
			linyu_info("gyro: kprobe installed @ %s\n", candidates[i]);
			return 0;
		}
	}

	linyu_warn("gyro: no sendto symbol resolvable\n");
	return -ENOENT;
}

void linyu_gyro_exit(void)
{
	if (sendto_kp_registered) {
		unregister_kprobe(&sendto_kp);
		sendto_kp_registered = false;
	}
	WRITE_ONCE(g_gyro_enabled, false);
	WRITE_ONCE(cached_ss_tgid, -1);
}
