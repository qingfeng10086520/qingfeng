#include "linyu.h"
#include "comm.h"
#include <asm/sysreg.h>
#include <linux/smp.h>
#include <linux/cpumask.h>

#define HWBP_BUF_SIZE  3473968  
#define HWBP_INFO_SIZE 3473936  

#define HWBP_REG_BVR  0
#define HWBP_REG_BCR  16
#define HWBP_REG_WVR  32
#define HWBP_REG_WCR  48

void *linyu_hwbp_k_buf;
static DEFINE_MUTEX(hwbp_mutex);

static int hwbp_num_brps;
static int hwbp_num_wrps;

#define DEFINE_WB_WRITE(group, idx, regname)                                  \
	case (group) + (idx):                                                  \
		asm volatile("msr " #regname ", %0" :: "r"(val) : "memory");   \
		break

#define DEFINE_WB_READ(group, idx, regname)                                    \
	case (group) + (idx):                                                  \
		asm volatile("mrs %0, " #regname : "=r"(v));                   \
		break

static void linyu_hwbp_write_reg(int group, int idx, u64 val)
{
	switch (group + idx) {
	
	DEFINE_WB_WRITE(HWBP_REG_BVR,  0, dbgbvr0_el1);
	DEFINE_WB_WRITE(HWBP_REG_BVR,  1, dbgbvr1_el1);
	DEFINE_WB_WRITE(HWBP_REG_BVR,  2, dbgbvr2_el1);
	DEFINE_WB_WRITE(HWBP_REG_BVR,  3, dbgbvr3_el1);
	DEFINE_WB_WRITE(HWBP_REG_BVR,  4, dbgbvr4_el1);
	DEFINE_WB_WRITE(HWBP_REG_BVR,  5, dbgbvr5_el1);
	DEFINE_WB_WRITE(HWBP_REG_BVR,  6, dbgbvr6_el1);
	DEFINE_WB_WRITE(HWBP_REG_BVR,  7, dbgbvr7_el1);
	DEFINE_WB_WRITE(HWBP_REG_BVR,  8, dbgbvr8_el1);
	DEFINE_WB_WRITE(HWBP_REG_BVR,  9, dbgbvr9_el1);
	DEFINE_WB_WRITE(HWBP_REG_BVR, 10, dbgbvr10_el1);
	DEFINE_WB_WRITE(HWBP_REG_BVR, 11, dbgbvr11_el1);
	DEFINE_WB_WRITE(HWBP_REG_BVR, 12, dbgbvr12_el1);
	DEFINE_WB_WRITE(HWBP_REG_BVR, 13, dbgbvr13_el1);
	DEFINE_WB_WRITE(HWBP_REG_BVR, 14, dbgbvr14_el1);
	DEFINE_WB_WRITE(HWBP_REG_BVR, 15, dbgbvr15_el1);
	
	DEFINE_WB_WRITE(HWBP_REG_BCR,  0, dbgbcr0_el1);
	DEFINE_WB_WRITE(HWBP_REG_BCR,  1, dbgbcr1_el1);
	DEFINE_WB_WRITE(HWBP_REG_BCR,  2, dbgbcr2_el1);
	DEFINE_WB_WRITE(HWBP_REG_BCR,  3, dbgbcr3_el1);
	DEFINE_WB_WRITE(HWBP_REG_BCR,  4, dbgbcr4_el1);
	DEFINE_WB_WRITE(HWBP_REG_BCR,  5, dbgbcr5_el1);
	DEFINE_WB_WRITE(HWBP_REG_BCR,  6, dbgbcr6_el1);
	DEFINE_WB_WRITE(HWBP_REG_BCR,  7, dbgbcr7_el1);
	DEFINE_WB_WRITE(HWBP_REG_BCR,  8, dbgbcr8_el1);
	DEFINE_WB_WRITE(HWBP_REG_BCR,  9, dbgbcr9_el1);
	DEFINE_WB_WRITE(HWBP_REG_BCR, 10, dbgbcr10_el1);
	DEFINE_WB_WRITE(HWBP_REG_BCR, 11, dbgbcr11_el1);
	DEFINE_WB_WRITE(HWBP_REG_BCR, 12, dbgbcr12_el1);
	DEFINE_WB_WRITE(HWBP_REG_BCR, 13, dbgbcr13_el1);
	DEFINE_WB_WRITE(HWBP_REG_BCR, 14, dbgbcr14_el1);
	DEFINE_WB_WRITE(HWBP_REG_BCR, 15, dbgbcr15_el1);
	
	DEFINE_WB_WRITE(HWBP_REG_WVR,  0, dbgwvr0_el1);
	DEFINE_WB_WRITE(HWBP_REG_WVR,  1, dbgwvr1_el1);
	DEFINE_WB_WRITE(HWBP_REG_WVR,  2, dbgwvr2_el1);
	DEFINE_WB_WRITE(HWBP_REG_WVR,  3, dbgwvr3_el1);
	DEFINE_WB_WRITE(HWBP_REG_WVR,  4, dbgwvr4_el1);
	DEFINE_WB_WRITE(HWBP_REG_WVR,  5, dbgwvr5_el1);
	DEFINE_WB_WRITE(HWBP_REG_WVR,  6, dbgwvr6_el1);
	DEFINE_WB_WRITE(HWBP_REG_WVR,  7, dbgwvr7_el1);
	DEFINE_WB_WRITE(HWBP_REG_WVR,  8, dbgwvr8_el1);
	DEFINE_WB_WRITE(HWBP_REG_WVR,  9, dbgwvr9_el1);
	DEFINE_WB_WRITE(HWBP_REG_WVR, 10, dbgwvr10_el1);
	DEFINE_WB_WRITE(HWBP_REG_WVR, 11, dbgwvr11_el1);
	DEFINE_WB_WRITE(HWBP_REG_WVR, 12, dbgwvr12_el1);
	DEFINE_WB_WRITE(HWBP_REG_WVR, 13, dbgwvr13_el1);
	DEFINE_WB_WRITE(HWBP_REG_WVR, 14, dbgwvr14_el1);
	DEFINE_WB_WRITE(HWBP_REG_WVR, 15, dbgwvr15_el1);
	
	DEFINE_WB_WRITE(HWBP_REG_WCR,  0, dbgwcr0_el1);
	DEFINE_WB_WRITE(HWBP_REG_WCR,  1, dbgwcr1_el1);
	DEFINE_WB_WRITE(HWBP_REG_WCR,  2, dbgwcr2_el1);
	DEFINE_WB_WRITE(HWBP_REG_WCR,  3, dbgwcr3_el1);
	DEFINE_WB_WRITE(HWBP_REG_WCR,  4, dbgwcr4_el1);
	DEFINE_WB_WRITE(HWBP_REG_WCR,  5, dbgwcr5_el1);
	DEFINE_WB_WRITE(HWBP_REG_WCR,  6, dbgwcr6_el1);
	DEFINE_WB_WRITE(HWBP_REG_WCR,  7, dbgwcr7_el1);
	DEFINE_WB_WRITE(HWBP_REG_WCR,  8, dbgwcr8_el1);
	DEFINE_WB_WRITE(HWBP_REG_WCR,  9, dbgwcr9_el1);
	DEFINE_WB_WRITE(HWBP_REG_WCR, 10, dbgwcr10_el1);
	DEFINE_WB_WRITE(HWBP_REG_WCR, 11, dbgwcr11_el1);
	DEFINE_WB_WRITE(HWBP_REG_WCR, 12, dbgwcr12_el1);
	DEFINE_WB_WRITE(HWBP_REG_WCR, 13, dbgwcr13_el1);
	DEFINE_WB_WRITE(HWBP_REG_WCR, 14, dbgwcr14_el1);
	DEFINE_WB_WRITE(HWBP_REG_WCR, 15, dbgwcr15_el1);
	default:
		return;
	}
	isb();
}

static u64 linyu_hwbp_read_reg(int group, int idx)
{
	u64 v = 0;

	switch (group + idx) {
	DEFINE_WB_READ(HWBP_REG_BVR,  0, dbgbvr0_el1);
	DEFINE_WB_READ(HWBP_REG_BVR,  1, dbgbvr1_el1);
	DEFINE_WB_READ(HWBP_REG_BVR,  2, dbgbvr2_el1);
	DEFINE_WB_READ(HWBP_REG_BVR,  3, dbgbvr3_el1);
	DEFINE_WB_READ(HWBP_REG_BVR,  4, dbgbvr4_el1);
	DEFINE_WB_READ(HWBP_REG_BVR,  5, dbgbvr5_el1);
	DEFINE_WB_READ(HWBP_REG_BVR,  6, dbgbvr6_el1);
	DEFINE_WB_READ(HWBP_REG_BVR,  7, dbgbvr7_el1);
	DEFINE_WB_READ(HWBP_REG_BVR,  8, dbgbvr8_el1);
	DEFINE_WB_READ(HWBP_REG_BVR,  9, dbgbvr9_el1);
	DEFINE_WB_READ(HWBP_REG_BVR, 10, dbgbvr10_el1);
	DEFINE_WB_READ(HWBP_REG_BVR, 11, dbgbvr11_el1);
	DEFINE_WB_READ(HWBP_REG_BVR, 12, dbgbvr12_el1);
	DEFINE_WB_READ(HWBP_REG_BVR, 13, dbgbvr13_el1);
	DEFINE_WB_READ(HWBP_REG_BVR, 14, dbgbvr14_el1);
	DEFINE_WB_READ(HWBP_REG_BVR, 15, dbgbvr15_el1);
	DEFINE_WB_READ(HWBP_REG_BCR,  0, dbgbcr0_el1);
	DEFINE_WB_READ(HWBP_REG_BCR,  1, dbgbcr1_el1);
	DEFINE_WB_READ(HWBP_REG_BCR,  2, dbgbcr2_el1);
	DEFINE_WB_READ(HWBP_REG_BCR,  3, dbgbcr3_el1);
	DEFINE_WB_READ(HWBP_REG_BCR,  4, dbgbcr4_el1);
	DEFINE_WB_READ(HWBP_REG_BCR,  5, dbgbcr5_el1);
	DEFINE_WB_READ(HWBP_REG_BCR,  6, dbgbcr6_el1);
	DEFINE_WB_READ(HWBP_REG_BCR,  7, dbgbcr7_el1);
	DEFINE_WB_READ(HWBP_REG_BCR,  8, dbgbcr8_el1);
	DEFINE_WB_READ(HWBP_REG_BCR,  9, dbgbcr9_el1);
	DEFINE_WB_READ(HWBP_REG_BCR, 10, dbgbcr10_el1);
	DEFINE_WB_READ(HWBP_REG_BCR, 11, dbgbcr11_el1);
	DEFINE_WB_READ(HWBP_REG_BCR, 12, dbgbcr12_el1);
	DEFINE_WB_READ(HWBP_REG_BCR, 13, dbgbcr13_el1);
	DEFINE_WB_READ(HWBP_REG_BCR, 14, dbgbcr14_el1);
	DEFINE_WB_READ(HWBP_REG_BCR, 15, dbgbcr15_el1);
	DEFINE_WB_READ(HWBP_REG_WVR,  0, dbgwvr0_el1);
	DEFINE_WB_READ(HWBP_REG_WVR,  1, dbgwvr1_el1);
	DEFINE_WB_READ(HWBP_REG_WVR,  2, dbgwvr2_el1);
	DEFINE_WB_READ(HWBP_REG_WVR,  3, dbgwvr3_el1);
	DEFINE_WB_READ(HWBP_REG_WVR,  4, dbgwvr4_el1);
	DEFINE_WB_READ(HWBP_REG_WVR,  5, dbgwvr5_el1);
	DEFINE_WB_READ(HWBP_REG_WVR,  6, dbgwvr6_el1);
	DEFINE_WB_READ(HWBP_REG_WVR,  7, dbgwvr7_el1);
	DEFINE_WB_READ(HWBP_REG_WVR,  8, dbgwvr8_el1);
	DEFINE_WB_READ(HWBP_REG_WVR,  9, dbgwvr9_el1);
	DEFINE_WB_READ(HWBP_REG_WVR, 10, dbgwvr10_el1);
	DEFINE_WB_READ(HWBP_REG_WVR, 11, dbgwvr11_el1);
	DEFINE_WB_READ(HWBP_REG_WVR, 12, dbgwvr12_el1);
	DEFINE_WB_READ(HWBP_REG_WVR, 13, dbgwvr13_el1);
	DEFINE_WB_READ(HWBP_REG_WVR, 14, dbgwvr14_el1);
	DEFINE_WB_READ(HWBP_REG_WVR, 15, dbgwvr15_el1);
	DEFINE_WB_READ(HWBP_REG_WCR,  0, dbgwcr0_el1);
	DEFINE_WB_READ(HWBP_REG_WCR,  1, dbgwcr1_el1);
	DEFINE_WB_READ(HWBP_REG_WCR,  2, dbgwcr2_el1);
	DEFINE_WB_READ(HWBP_REG_WCR,  3, dbgwcr3_el1);
	DEFINE_WB_READ(HWBP_REG_WCR,  4, dbgwcr4_el1);
	DEFINE_WB_READ(HWBP_REG_WCR,  5, dbgwcr5_el1);
	DEFINE_WB_READ(HWBP_REG_WCR,  6, dbgwcr6_el1);
	DEFINE_WB_READ(HWBP_REG_WCR,  7, dbgwcr7_el1);
	DEFINE_WB_READ(HWBP_REG_WCR,  8, dbgwcr8_el1);
	DEFINE_WB_READ(HWBP_REG_WCR,  9, dbgwcr9_el1);
	DEFINE_WB_READ(HWBP_REG_WCR, 10, dbgwcr10_el1);
	DEFINE_WB_READ(HWBP_REG_WCR, 11, dbgwcr11_el1);
	DEFINE_WB_READ(HWBP_REG_WCR, 12, dbgwcr12_el1);
	DEFINE_WB_READ(HWBP_REG_WCR, 13, dbgwcr13_el1);
	DEFINE_WB_READ(HWBP_REG_WCR, 14, dbgwcr14_el1);
	DEFINE_WB_READ(HWBP_REG_WCR, 15, dbgwcr15_el1);
	default:
		break;
	}
	return v;
}

#undef DEFINE_WB_WRITE
#undef DEFINE_WB_READ

struct hwbp_write_req {
	int group;
	int idx;
	u64 val;
};

static void linyu_hwbp_write_ipi(void *info)
{
	struct hwbp_write_req *r = info;
	linyu_hwbp_write_reg(r->group, r->idx, r->val);
}

static void linyu_hwbp_write_all_cpus(int group, int idx, u64 val)
{
	struct hwbp_write_req req = { .group = group, .idx = idx, .val = val };
	on_each_cpu(linyu_hwbp_write_ipi, &req, 1);
}

int linyu_hw_breakpoint_parse(const void *in, u64 out[2])
{
	const u32 *p;
	u32 type, len_code;
	u64 addr, ctrl;
	u32 bas_mask;
	bool is_wp;
	u32 lsc = 0;
	int log_len;

	if (!in || !out)
		return -EINVAL;

	p = in;
	type = p[0];
	len_code = p[1];
	addr = *(u64 *)((const u8 *)in + 16);

	if (type < 1 || type > 4)
		return -EINVAL;
	if (len_code < 1 || len_code > 8)
		return -EINVAL;

	is_wp = type != 4;
	switch (type) {
	case 1:
		lsc = 1;
		break;
	case 2:
		lsc = 2;
		break;
	case 3:
		lsc = 3;
		break;
	case 4:
		lsc = 0;
		break;
	}

	bas_mask = (len_code <= 4) ? ((1u << len_code) - 1) : 0xFu;
	ctrl = 1ULL | (2ULL << 1) | ((u64)lsc << 3) |
	       ((u64)bas_mask << 5) | (3ULL << 29);

	if (len_code > 4) {
		log_len = (len_code <= 8) ? 1 : 2;
		ctrl |= ((u64)log_len << 24);
	}

	if (is_wp) {
		u64 align_mask = (len_code <= 4) ? 3ULL : 7ULL;
		addr &= ~align_mask;
	}

	out[0] = addr;
	out[1] = ctrl;
	return 0;
}

void linyu_sample_hbp_handler(void *event, struct pt_regs *regs)
{
	u64 *out;
	int i;

	if (!regs || !linyu_hwbp_k_buf)
		return;

	out = (u64 *)linyu_hwbp_k_buf;
	mutex_lock(&hwbp_mutex);
	out[2] = instruction_pointer(regs);
	out[3] = regs->sp;
	out[4] = regs->pstate;
	for (i = 0; i < 8; i++)
		out[5 + i] = regs->regs[i];
	mutex_unlock(&hwbp_mutex);
}

static void linyu_hwbp_detect_counts(void)
{
	u64 dfr0;

	asm volatile("mrs %0, id_aa64dfr0_el1" : "=r"(dfr0));
	hwbp_num_brps = ((dfr0 >> 12) & 0xF) + 1;
	hwbp_num_wrps = ((dfr0 >> 20) & 0xF) + 1;

	if (hwbp_num_brps > 16) hwbp_num_brps = 16;
	if (hwbp_num_wrps > 16) hwbp_num_wrps = 16;
}

static void linyu_hwbp_zero_all_ipi(void *unused)
{
	int i;
	for (i = 0; i < hwbp_num_brps; i++) {
		linyu_hwbp_write_reg(HWBP_REG_BVR, i, 0);
		linyu_hwbp_write_reg(HWBP_REG_BCR, i, 0);
	}
	for (i = 0; i < hwbp_num_wrps; i++) {
		linyu_hwbp_write_reg(HWBP_REG_WVR, i, 0);
		linyu_hwbp_write_reg(HWBP_REG_WCR, i, 0);
	}
}

static void linyu_hwbp_zero_all_cpus(void)
{
	on_each_cpu(linyu_hwbp_zero_all_ipi, NULL, 1);
}

int linyu_hwbp_init(void)
{
	if (linyu_hwbp_k_buf)
		return 0;

	linyu_hwbp_detect_counts();

	linyu_hwbp_k_buf = kvmalloc(HWBP_BUF_SIZE, GFP_KERNEL);
	if (!linyu_hwbp_k_buf)
		return -ENOMEM;

	memset(linyu_hwbp_k_buf, 0, HWBP_BUF_SIZE);
	((u64 *)linyu_hwbp_k_buf)[0] = hwbp_num_brps;
	((u64 *)linyu_hwbp_k_buf)[1] = hwbp_num_wrps;

	linyu_info("hwbp: initialized, brps=%d wrps=%d\n",
		   hwbp_num_brps, hwbp_num_wrps);
	return 0;
}

void linyu_hwbp_exit(void)
{
	linyu_hwbp_zero_all_cpus();
	if (linyu_hwbp_k_buf) {
		kvfree(linyu_hwbp_k_buf);
		linyu_hwbp_k_buf = NULL;
	}
}

void linyu_hwbp_init_insn_patch(void)
{
	
}

int linyu_hwbp_info(unsigned long arg)
{
	void *kbuf;
	int ret = 0;

	if (!hwbp_num_brps)
		linyu_hwbp_detect_counts();

	kbuf = kvmalloc(HWBP_INFO_SIZE, GFP_KERNEL);
	if (!kbuf)
		return -ENOMEM;

	mutex_lock(&hwbp_mutex);
	if (linyu_hwbp_k_buf)
		memcpy(kbuf, linyu_hwbp_k_buf, HWBP_INFO_SIZE);
	else
		memset(kbuf, 0, HWBP_INFO_SIZE);
	mutex_unlock(&hwbp_mutex);

	((u64 *)kbuf)[0] = hwbp_num_brps;
	((u64 *)kbuf)[1] = hwbp_num_wrps;

	if (copy_to_user((void __user *)arg, kbuf, HWBP_INFO_SIZE))
		ret = -EFAULT;

	kvfree(kbuf);
	return ret;
}

int linyu_hwbp_set(unsigned long arg)
{
	void *kbuf;
	u32  bvr_lo, bcr_lo;
	u64  addr, ctrl;
	int  slot;
	int  ret = 0;

	kbuf = kvmalloc(HWBP_BUF_SIZE, GFP_KERNEL);
	if (!kbuf)
		return -ENOMEM;

	if (copy_from_user(kbuf, (void __user *)arg, HWBP_BUF_SIZE)) {
		kvfree(kbuf);
		return -EFAULT;
	}

	mutex_lock(&hwbp_mutex);

	if (!hwbp_num_brps)
		linyu_hwbp_detect_counts();

	

	for (slot = 0; slot < 16; slot++) {
		u8 *p = (u8 *)kbuf + 0x20 + (size_t)slot * 27140;
		u32 pid    = *(u32 *)(p + 0x00);
		u32 type   = *(u32 *)(p + 0x10);
		u32 length = *(u32 *)(p + 0x14);

		addr = *(u64 *)(p + 0x08);
		if (pid == 0 && addr == 0)
			continue;

		

		ctrl = 1ULL                       
		     | (2ULL << 1)                
		     | ((u64)(type & 0x3) << 3)   
		     | (0xFULL << 5);             
		if (length > 4)
			ctrl |= 1ULL << 24;
		if (length > 8)
			ctrl |= 2ULL << 24;

		if (slot < hwbp_num_brps && type == 0) {
			linyu_hwbp_write_all_cpus(HWBP_REG_BVR, slot, addr);
			linyu_hwbp_write_all_cpus(HWBP_REG_BCR, slot, ctrl);
		} else if (slot < hwbp_num_wrps) {
			linyu_hwbp_write_all_cpus(HWBP_REG_WVR, slot, addr);
			linyu_hwbp_write_all_cpus(HWBP_REG_WCR, slot, ctrl);
		}

		
		bvr_lo = (u32)linyu_hwbp_read_reg(HWBP_REG_BVR, slot);
		bcr_lo = (u32)linyu_hwbp_read_reg(HWBP_REG_BCR, slot);
		(void)bvr_lo; (void)bcr_lo;
	}

	
	if (linyu_hwbp_k_buf)
		memcpy(linyu_hwbp_k_buf, kbuf, HWBP_BUF_SIZE);
	((u32 *)kbuf)[7] = 0; 

	mutex_unlock(&hwbp_mutex);

	if (copy_to_user((void __user *)arg, kbuf, HWBP_BUF_SIZE))
		ret = -EFAULT;

	kvfree(kbuf);
	return ret;
}

int linyu_hwbp_remove(unsigned long arg)
{
	mutex_lock(&hwbp_mutex);
	linyu_hwbp_zero_all_cpus();
	if (linyu_hwbp_k_buf)
		memset(linyu_hwbp_k_buf, 0, HWBP_BUF_SIZE);
	mutex_unlock(&hwbp_mutex);
	return 0;
}
