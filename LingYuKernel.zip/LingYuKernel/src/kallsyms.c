#include "linyu.h"

kallsyms_lookup_name_t linyu_kallsyms_lookup_name = NULL;

int linyu_kallsyms_init(void)
{
	struct kprobe kp = {};
	int ret;

	kp.symbol_name = "kallsyms_lookup_name";
	ret = register_kprobe(&kp);
	if (ret < 0) {
		linyu_err("kallsyms: kprobe register failed: %d\n", ret);
		return ret;
	}

	linyu_kallsyms_lookup_name = (kallsyms_lookup_name_t)kp.addr;
	unregister_kprobe(&kp);

	if (!linyu_kallsyms_lookup_name) {
		linyu_err("kallsyms: resolved to NULL\n");
		return -EFAULT;
	}

	linyu_info("kallsyms: resolved at %px\n", linyu_kallsyms_lookup_name);
	return 0;
}

unsigned long linyu_resolve_symbol(const char *name)
{
	if (!linyu_kallsyms_lookup_name)
		return 0;
	return linyu_kallsyms_lookup_name(name);
}
