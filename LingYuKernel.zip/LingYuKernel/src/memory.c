#include "linyu.h"
#include "comm.h"
#include <asm/cacheflush.h>

struct mm_struct *s_last_mm;
pid_t s_last_pid;
DEFINE_MUTEX(linyu_read_mutex);

void linyu_cleanup_mm_cache(void)
{
	if (s_last_mm) {
		mmput(s_last_mm);
		s_last_mm = NULL;
	}
	s_last_pid = 0;
	linyu_pte_caches_clear();
}

phys_addr_t linyu_vaddr_to_phys(struct mm_struct *mm, unsigned long va)
{
	phys_addr_t pa;
	unsigned long par, pgd_phys, flags;

	if (!mm)
		return 0;

	pgd_phys = virt_to_phys(mm->pgd);
	if (!pgd_phys)
		goto fallback;

	local_irq_save(flags);

	
	asm volatile(
		"mrs x1, ttbr0_el1\n"
		"msr ttbr0_el1, %0\n"
		"isb\n"
		:: "r"(pgd_phys) : "x1", "memory"
	);

	
	asm volatile(
		"at s1e0r, %1\n"
		"isb\n"
		"mrs %0, par_el1\n"
		: "=r"(par) : "r"(va) : "memory"
	);

	
	asm volatile(
		"mrs x1, ttbr0_el1\n"
		"tlbi vaae1, %0\n"
		"dsb nsh\n"
		"isb\n"
		:: "r"(va >> 12) : "x1", "memory"
	);

	
	local_irq_restore(flags);

	if (par & 1) 
		goto fallback;

	pa = ((par >> 12) & 0xFFFFFFFFFFUL) << 12;
	pa |= va & 0xFFF;
	return pa;

fallback:
	return linyu_walk_page_tables(mm, va);
}

phys_addr_t linyu_walk_page_tables(struct mm_struct *mm, unsigned long va)
{
	pgd_t *pgd;
	p4d_t *p4d;
	pud_t *pud;
	pmd_t *pmd;
	pte_t *ptep, pte;
	phys_addr_t pa;

	if (!mm)
		return 0;

	pgd = pgd_offset(mm, va);
	if (pgd_none(*pgd) || pgd_bad(*pgd))
		return 0;

	p4d = p4d_offset(pgd, va);
	if (p4d_none(*p4d) || p4d_bad(*p4d))
		return 0;

	pud = pud_offset(p4d, va);
	if (pud_none(*pud))
		return 0;

	if (pud_sect(*pud)) {
		pa = (phys_addr_t)pud_pfn(*pud) << PAGE_SHIFT;
		pa += va & ~PUD_MASK;
		return pa;
	}
	if (pud_bad(*pud))
		return 0;

	pmd = pmd_offset(pud, va);
	if (pmd_none(*pmd))
		return 0;

	if (pmd_sect(*pmd)) {
		pa = (phys_addr_t)pmd_pfn(*pmd) << PAGE_SHIFT;
		pa += va & ~PMD_MASK;
		return pa;
	}
	if (pmd_bad(*pmd))
		return 0;

	ptep = pte_offset_kernel(pmd, va);
	if (!ptep)
		return 0;

	pte = READ_ONCE(*ptep);
	if (!pte_present(pte))
		return 0;

	pa = (phys_addr_t)pte_pfn(pte) << PAGE_SHIFT;
	pa += va & ~PAGE_MASK;
	return pa;
}

int linyu_translate_process_vaddr(pid_t pid, unsigned long va, phys_addr_t *pa_out)
{
	struct pid *pid_s;
	struct task_struct *task;
	struct mm_struct *mm;
	phys_addr_t pa;

	pid_s = find_get_pid(pid);
	if (!pid_s)
		return -ESRCH;

	task = get_pid_task(pid_s, PIDTYPE_PID);
	put_pid(pid_s);
	if (!task)
		return -ESRCH;

	mm = get_task_mm(task);
	put_task_struct(task);
	if (!mm)
		return -EINVAL;

	mmap_read_lock(mm);
	pa = linyu_vaddr_to_phys(mm, va);
	mmap_read_unlock(mm);
	mmput(mm);

	if (!pa)
		return -EFAULT;

	*pa_out = pa;
	return 0;
}

static struct mm_struct *get_cached_mm(pid_t pid)
{
	struct pid *pid_s;
	struct task_struct *task;
	struct mm_struct *mm;

	if (s_last_pid == pid && s_last_mm) {
		pid_s = find_get_pid(pid);
		if (pid_s) {
			task = pid_task(pid_s, PIDTYPE_PID);
			put_pid(pid_s);
			if (task && task->mm)
				return s_last_mm;
		}
		linyu_cleanup_mm_cache();
		return NULL;
	}

	if (s_last_mm) {
		mmput(s_last_mm);
		s_last_mm = NULL;
	}
	linyu_pte_caches_clear();

	pid_s = find_get_pid(pid);
	if (!pid_s)
		return NULL;

	task = get_pid_task(pid_s, PIDTYPE_PID);
	put_pid(pid_s);
	if (!task)
		return NULL;

	mm = get_task_mm(task);
	put_task_struct(task);
	if (!mm)
		return NULL;

	s_last_mm = mm;
	s_last_pid = pid;
	return mm;
}

int linyu_memory_read_physical(unsigned long arg)
{
	struct linyu_rw_args a;
	struct mm_struct *mm;
	phys_addr_t pa;
	struct page *page;
	void *mapped;
	size_t offset, chunk;
	size_t done = 0;
	int ret = 0;
	pgprot_t prot;

	if (copy_from_user(&a, (void __user *)arg, sizeof(a)))
		return -EFAULT;
	if (!a.size || a.size > 0x8000000000UL)
		return -EINVAL;

	prot = pgprot_noncached(PAGE_KERNEL);

	mutex_lock(&linyu_read_mutex);
	mm = get_cached_mm(a.pid);
	if (!mm) {
		ret = -ESRCH;
		goto out;
	}

	while (done < a.size) {
		pa = linyu_vaddr_to_phys(mm, a.vaddr + done);
		if (!pa) {
			ret = -EFAULT;
			goto out;
		}

		offset = pa & ~PAGE_MASK;
		chunk = PAGE_SIZE - offset;
		if (chunk > a.size - done)
			chunk = a.size - done;

		page = pfn_to_page(pa >> PAGE_SHIFT);
		if (!page) {
			ret = -EFAULT;
			goto out;
		}

		get_page(page);
		mapped = vmap(&page, 1, VM_MAP, prot);
		if (!mapped) {
			put_page(page);
			ret = -ENOMEM;
			goto out;
		}

		
		{
			unsigned long addr;
			for (addr = ((unsigned long)mapped + offset) & ~63UL;
			     addr < (unsigned long)mapped + offset + chunk;
			     addr += 64)
				asm volatile("dc cvac, %0" :: "r"(addr));
			dsb(ish);
		}

		if (copy_to_user((void __user *)(a.ubuf + done),
				 (void *)((unsigned long)mapped + offset), chunk)) {
			vunmap(mapped);
			put_page(page);
			ret = -EFAULT;
			goto out;
		}

		vunmap(mapped);
		put_page(page);
		done += chunk;
	}

out:
	mutex_unlock(&linyu_read_mutex);
	return ret;
}

int linyu_memory_read_physical_ioremap(unsigned long arg)
{
	struct linyu_rw_args a;
	struct mm_struct *mm;
	phys_addr_t pa;
	void *kbuf;
	size_t offset, chunk;
	size_t done = 0;
	int ret;

	if (copy_from_user(&a, (void __user *)arg, sizeof(a)))
		return -EFAULT;
	if (!a.size || a.size > 0x8000000000UL)
		return -EINVAL;

	mutex_lock(&linyu_read_mutex);
	mm = get_cached_mm(a.pid);
	if (!mm) {
		ret = -ESRCH;
		goto out;
	}

	ret = linyu_pte_window_init();
	if (ret)
		goto out;

	kbuf = kmalloc(PAGE_SIZE, GFP_KERNEL);
	if (!kbuf) {
		ret = -ENOMEM;
		goto out;
	}

	while (done < a.size) {
		pa = linyu_vaddr_to_phys(mm, a.vaddr + done);
		if (!pa) {
			kfree(kbuf);
			ret = -EFAULT;
			goto out;
		}

		offset = pa & ~PAGE_MASK;
		chunk = PAGE_SIZE - offset;
		if (chunk > a.size - done)
			chunk = a.size - done;

		ret = linyu_pte_read_physical(pa, kbuf, PAGE_SIZE);
		if (ret) {
			kfree(kbuf);
			goto out;
		}

		if (copy_to_user((void __user *)(a.ubuf + done),
				 kbuf + offset, chunk)) {
			kfree(kbuf);
			ret = -EFAULT;
			goto out;
		}

		done += chunk;
	}

	kfree(kbuf);
	ret = 0;
out:
	mutex_unlock(&linyu_read_mutex);
	return ret;
}

int linyu_memory_read_physical_fast(unsigned long arg)
{
	struct linyu_rw_fast_args a;
	struct mm_struct *mm;
	phys_addr_t pa;
	void *kbuf;
	size_t offset, chunk;
	size_t done = 0;
	int ret;

	if (copy_from_user(&a, (void __user *)arg, sizeof(a)))
		return -EFAULT;
	if (!a.size || a.pid < 1)
		return -EINVAL;
	if (a.mode > 1)
		return -EINVAL;

	kbuf = kmalloc(a.size, GFP_KERNEL);
	if (!kbuf)
		return -ENOMEM;

	mutex_lock(&linyu_read_mutex);
	mm = get_cached_mm(a.pid);
	if (!mm) {
		ret = -ESRCH;
		goto out_free;
	}

	while (done < a.size) {
		pa = linyu_vaddr_to_phys(mm, a.vaddr + done);
		if (!pa) {
			ret = -EFAULT;
			goto out_unlock;
		}

		offset = pa & ~PAGE_MASK;
		chunk = PAGE_SIZE - offset;
		if (chunk > a.size - done)
			chunk = a.size - done;

		ret = linyu_pte_read_nc_fast(pa, kbuf + done, chunk);
		if (ret)
			goto out_unlock;

		done += chunk;
	}

	mutex_unlock(&linyu_read_mutex);

	if (copy_to_user((void __user *)a.ubuf, kbuf, a.size)) {
		kfree(kbuf);
		return -EFAULT;
	}

	kfree(kbuf);
	return 0;

out_unlock:
	mutex_unlock(&linyu_read_mutex);
out_free:
	kfree(kbuf);
	return ret;
}

int linyu_memory_read_phys(unsigned long arg)
{
	struct linyu_phys_read_args a;
	struct mm_struct *mm;
	phys_addr_t pa;
	size_t offset, chunk;
	size_t done = 0;
	int ret;

	if (copy_from_user(&a, (void __user *)arg, sizeof(a)))
		return -EFAULT;
	if (!a.size)
		return -EINVAL;

	mutex_lock(&linyu_read_mutex);
	mm = get_cached_mm(a.pid);
	if (!mm) {
		ret = -ESRCH;
		goto out;
	}

	ret = linyu_pte_window_init_percpu();
	if (ret)
		goto out;

	while (done < a.size) {
		pa = linyu_vaddr_to_phys(mm, a.vaddr + done);
		if (!pa) {
			ret = -EFAULT;
			goto out;
		}

		offset = pa & ~PAGE_MASK;
		chunk = PAGE_SIZE - offset;
		if (chunk > a.size - done)
			chunk = a.size - done;

		ret = linyu_read_phys_to_user(pa, (void __user *)(a.ubuf + done), chunk);
		if (ret)
			goto out;

		done += chunk;
	}

	ret = 0;
out:
	mutex_unlock(&linyu_read_mutex);
	return ret;
}

int linyu_memory_write_physical(unsigned long arg)
{
	struct linyu_rw_args a;
	phys_addr_t pa;
	void *kva;
	int ret;

	if (copy_from_user(&a, (void __user *)arg, sizeof(a)))
		return -EFAULT;
	if (!a.size)
		return -EINVAL;

	ret = linyu_translate_process_vaddr(a.pid, a.vaddr, &pa);
	if (ret)
		return ret;

	
	kva = phys_to_virt(pa);
	if (!kva)
		return -EFAULT;

	if (copy_from_user(kva, (void __user *)a.ubuf, a.size))
		return -EFAULT;

	return 0;
}

void linyu_phys_read_cleanup(void)
{
	mutex_lock(&linyu_read_mutex);
	linyu_cleanup_mm_cache();
	mutex_unlock(&linyu_read_mutex);
}

int linyu_memory_vaddr_translate(unsigned long arg)
{
	struct linyu_vaddr_translate_args a;
	phys_addr_t pa;
	int ret;

	if (copy_from_user(&a, (void __user *)arg, sizeof(a)))
		return -EFAULT;

	ret = linyu_translate_process_vaddr(a.pid, a.vaddr, &pa);
	if (ret)
		return ret;

	a.result = pa;
	if (copy_to_user((void __user *)arg, &a, sizeof(a)))
		return -EFAULT;
	return 0;
}

int linyu_debug_info(unsigned long arg)
{
	struct linyu_debug_info_args a = {};

	a.data[0] = (unsigned long)phys_to_virt(0);
	a.data[1] = PAGE_SIZE;
	a.data[2] = num_possible_cpus();

	if (copy_to_user((void __user *)arg, &a, sizeof(a)))
		return -EFAULT;
	return 0;
}

int linyu_memory_at_s1e0r(unsigned long arg)
{
	struct linyu_at_s1e0r_args a;
	phys_addr_t pa;
	int ret;

	if (copy_from_user(&a, (void __user *)arg, sizeof(a)))
		return -EFAULT;

	ret = linyu_translate_process_vaddr(a.pid, a.vaddr, &pa);
	a.result = ret ? 0 : pa;

	if (copy_to_user((void __user *)arg, &a, sizeof(a)))
		return -EFAULT;
	return ret;
}

int linyu_memory_get_page_info(unsigned long arg)
{
	struct linyu_page_info_args a;
	phys_addr_t pa;

	if (copy_from_user(&a, (void __user *)arg, sizeof(a)))
		return -EFAULT;

	if (linyu_translate_process_vaddr(a.pid, a.vaddr, &pa))
		return -EFAULT;

	a.phys = pa;
	a.flags = 0;

	if (copy_to_user((void __user *)arg, &a, sizeof(a)))
		return -EFAULT;
	return 0;
}

int linyu_memory_get_pte_mapping(unsigned long arg)
{
	struct linyu_pte_mapping_args a;
	struct mm_struct *mm;
	pgd_t *pgd;
	p4d_t *p4d;
	pud_t *pud;
	pmd_t *pmd;
	pte_t *ptep;
	struct pid *pid_s;
	struct task_struct *task;

	if (copy_from_user(&a, (void __user *)arg, sizeof(a)))
		return -EFAULT;

	pid_s = find_get_pid(a.pid);
	if (!pid_s) return -ESRCH;
	task = get_pid_task(pid_s, PIDTYPE_PID);
	put_pid(pid_s);
	if (!task) return -ESRCH;
	mm = get_task_mm(task);
	put_task_struct(task);
	if (!mm) return -EINVAL;

	a.pte_val = 0;
	mmap_read_lock(mm);

	pgd = pgd_offset(mm, a.vaddr);
	if (!pgd_none(*pgd) && !pgd_bad(*pgd)) {
		p4d = p4d_offset(pgd, a.vaddr);
		if (!p4d_none(*p4d) && !p4d_bad(*p4d)) {
			pud = pud_offset(p4d, a.vaddr);
			if (!pud_none(*pud) && !pud_bad(*pud)) {
				pmd = pmd_offset(pud, a.vaddr);
				if (!pmd_none(*pmd) && !pmd_bad(*pmd)) {
					ptep = pte_offset_kernel(pmd, a.vaddr);
					if (ptep)
						a.pte_val = pte_val(READ_ONCE(*ptep));
				}
			}
		}
	}

	mmap_read_unlock(mm);
	mmput(mm);

	if (copy_to_user((void __user *)arg, &a, sizeof(a)))
		return -EFAULT;
	return 0;
}

int linyu_memory_page_table_walk(unsigned long arg)
{
	struct linyu_page_table_walk_args a;
	phys_addr_t pa;

	if (copy_from_user(&a, (void __user *)arg, sizeof(a)))
		return -EFAULT;

	if (linyu_translate_process_vaddr(a.pid, a.vaddr, &pa)) {
		a.pgd_val = 0;
		a.pte_val = 0;
	} else {
		a.pgd_val = pa;
		a.pte_val = pa;
	}

	if (copy_to_user((void __user *)arg, &a, sizeof(a)))
		return -EFAULT;
	return 0;
}

int linyu_process_copy(unsigned long arg)
{
	struct linyu_copy_process_args a;
	phys_addr_t src_pa, dst_pa;
	int ret;

	if (copy_from_user(&a, (void __user *)arg, sizeof(a)))
		return -EFAULT;

	ret = linyu_translate_process_vaddr(a.src_pid, a.src_addr, &src_pa);
	if (ret) return ret;

	ret = linyu_translate_process_vaddr(a.dst_pid, a.dst_addr, &dst_pa);
	if (ret) return ret;

	
	memcpy(phys_to_virt(dst_pa), phys_to_virt(src_pa), a.size);
	return 0;
}
