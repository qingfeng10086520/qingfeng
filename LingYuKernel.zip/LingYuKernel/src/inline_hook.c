#include "linyu.h"
#include <asm/insn.h>

#define MAX_HOOKS 32
#define TRAMPOLINE_SIZE 64

struct hook_entry {
	void *target;
	void *hook;
	void *trampoline;
	u32 orig_insn[4];
	int orig_count;
	bool active;
};

static struct hook_entry hooks[MAX_HOOKS];
static int hook_count;
static DEFINE_SPINLOCK(hook_lock);

static u8 trampoline_slots[MAX_HOOKS * TRAMPOLINE_SIZE]
	__aligned(PAGE_SIZE);

typedef int (*aarch64_insn_write_t)(void *addr, u32 insn);
static aarch64_insn_write_t insn_write_fn;

static int linyu_inline_init_insn_write(void)
{
	if (insn_write_fn)
		return 0;

	insn_write_fn = (aarch64_insn_write_t)
		linyu_resolve_symbol("aarch64_insn_patch_text_nosync");
	if (!insn_write_fn) {
		linyu_err("inline_hook: cannot resolve insn_patch\n");
		return -ENOENT;
	}
	return 0;
}

static void linyu_inline_write_insn(void *addr, u32 insn)
{
	if (insn_write_fn)
		insn_write_fn(addr, insn);
}

static void linyu_inline_build_jump(void *from, void *to)
{
	u32 *p = (u32 *)from;

	linyu_inline_write_insn(&p[0], 0x58000050);
	linyu_inline_write_insn(&p[1], 0xD61F0200);
	memcpy(&p[2], &to, sizeof(void *));
}

int linyu_inline_hook_install(void *target, void *hook, void **orig)
{
	struct hook_entry *e;
	u8 *tramp;
	unsigned long flags;
	int idx;

	if (!target || !hook)
		return -EINVAL;
	if (linyu_inline_init_insn_write())
		return -ENOENT;
	if (!linyu_check_target_can_hijack(target, 4))
		return -EINVAL;

	spin_lock_irqsave(&hook_lock, flags);
	if (hook_count >= MAX_HOOKS) {
		spin_unlock_irqrestore(&hook_lock, flags);
		return -ENOMEM;
	}

	idx = hook_count++;
	e = &hooks[idx];
	tramp = &trampoline_slots[idx * TRAMPOLINE_SIZE];
	memcpy(e->orig_insn, target, sizeof(e->orig_insn));
	e->orig_count = ARRAY_SIZE(e->orig_insn);
	e->target = target;
	e->hook = hook;
	e->trampoline = tramp;
	e->active = true;
	spin_unlock_irqrestore(&hook_lock, flags);

	memcpy(tramp, target, sizeof(e->orig_insn));
	linyu_inline_build_jump(tramp + sizeof(e->orig_insn), (u8 *)target + sizeof(e->orig_insn));
	if (orig)
		*orig = tramp;

	linyu_inline_build_jump(target, hook);
	linyu_info("hook: installed at %px -> %px\n", target, hook);
	return 0;
}

int linyu_inline_hook_remove(void *target)
{
	unsigned long flags;
	int i;

	if (!target)
		return -EINVAL;
	if (linyu_inline_init_insn_write())
		return -ENOENT;

	spin_lock_irqsave(&hook_lock, flags);
	for (i = 0; i < hook_count; i++) {
		if (hooks[i].target == target && hooks[i].active) {
			int j;
			u32 *p = (u32 *)target;

			for (j = 0; j < hooks[i].orig_count; j++)
				linyu_inline_write_insn(&p[j], hooks[i].orig_insn[j]);
			hooks[i].active = false;
			spin_unlock_irqrestore(&hook_lock, flags);
			linyu_info("hook: removed at %px\n", target);
			return 0;
		}
	}
	spin_unlock_irqrestore(&hook_lock, flags);
	return -ENOENT;
}

void linyu_inline_hook_remove_all(void)
{
	unsigned long flags;
	int i;

	if (linyu_inline_init_insn_write())
		return;

	spin_lock_irqsave(&hook_lock, flags);
	for (i = 0; i < hook_count; i++) {
		if (hooks[i].active) {
			int j;
			u32 *p = (u32 *)hooks[i].target;

			for (j = 0; j < hooks[i].orig_count; j++)
				linyu_inline_write_insn(&p[j], hooks[i].orig_insn[j]);
			hooks[i].active = false;
		}
	}

	hook_count = 0;
	spin_unlock_irqrestore(&hook_lock, flags);
	linyu_info("hook: all hooks removed\n");
}

#define IS_ADRP(i)     (((i) & 0x9F000000u) == 0x90000000u)
#define IS_ADR(i)      (((i) & 0x9F000000u) == 0x10000000u)
#define IS_LDR_LIT(i)  (((i) & 0x3B000000u) == 0x18000000u)
#define IS_BCOND(i)    (((i) & 0xFF000000u) == 0x54000000u)
#define IS_CBZ(i)      (((i) & 0x7E000000u) == 0x34000000u)
#define IS_TBZ(i)      (((i) & 0x7E000000u) == 0x36000000u)

static bool linyu_inline_insn_is_pc_relative(u32 insn)
{
	return IS_ADRP(insn) || IS_ADR(insn) || IS_LDR_LIT(insn) ||
	       IS_BCOND(insn) || IS_CBZ(insn) || IS_TBZ(insn);
}

bool linyu_check_target_can_hijack(const void *target, int count)
{
	const u32 *p = target;
	int i;

	if (!target || count <= 0)
		return false;

	for (i = 0; i < count; i++)
		if (linyu_inline_insn_is_pc_relative(p[i]))
			return false;
	return true;
}

int linyu_hook_write_range(void *dst, const void *src, int len)
{
	int (*insn_write)(void *, u32);
	void (*icache_flush)(unsigned long, unsigned long);
	int i;

	if (!dst || !src || len <= 0 || (len & 3))
		return -EINVAL;

	insn_write = (void *)linyu_resolve_symbol("aarch64_insn_write");
	if (!insn_write)
		insn_write = (void *)linyu_resolve_symbol("aarch64_insn_patch_text_nosync");
	if (!insn_write)
		return -ENOENT;

	icache_flush = (void *)linyu_resolve_symbol("caches_clean_inval_pou");
	if (!icache_flush)
		icache_flush = (void *)linyu_resolve_symbol("flush_icache_range");
	if (!icache_flush)
		icache_flush = (void *)linyu_resolve_symbol("__flush_icache_range");

	for (i = 0; i < len; i += 4) {
		u32 word = *(const u32 *)((const u8 *)src + i);
		int ret = insn_write((u8 *)dst + i, word);
		if (ret)
			return ret;
	}

	if (icache_flush)
		icache_flush((unsigned long)dst, (unsigned long)dst + len);
	return 0;
}

int linyu_inline_hook_count(void)
{
	int n;
	unsigned long flags;

	spin_lock_irqsave(&hook_lock, flags);
	n = hook_count;
	spin_unlock_irqrestore(&hook_lock, flags);
	return n;
}
