#include "linyu.h"
#include "comm.h"
#include <linux/kprobes.h>
#include <linux/fs.h>
#include <linux/path.h>
#include <linux/dcache.h>
#include <linux/namei.h>
#include <linux/sched.h>
#include <linux/uaccess.h>

static char *(*p_d_path)(const struct path *, char *, int);

static bool linyu_hide_vfs_resolve_dpath_once(void)
{
	if (p_d_path)
		return true;
	p_d_path = (void *)linyu_resolve_symbol("d_path");
	return p_d_path != NULL;
}

bool linyu_hide_path_match(const char *fullpath);
bool linyu_hide_pid_match(pid_t pid);

static int linyu_hide_vfs_path_to_str(const struct path *p, char *buf, int buflen)
{
	char *resolved;

	if (!p || !p->dentry || !buf || buflen <= 0)
		return -EINVAL;
	if (!linyu_hide_vfs_resolve_dpath_once())
		return -ENOENT;

	resolved = p_d_path(p, buf, buflen);
	if (IS_ERR(resolved))
		return PTR_ERR(resolved);

	if (resolved != buf) {
		size_t len = strnlen(resolved, buflen);
		memmove(buf, resolved, len);
		buf[len] = '\0';
	}
	return 0;
}

static int linyu_hide_vfs_path_arg2_pre(struct kprobe *p, struct pt_regs *regs)
{
	const struct path *path_ptr = (const struct path *)regs->regs[1];
	char buf[256];

	if (!path_ptr)
		return 0;

	if (linyu_hide_vfs_path_to_str(path_ptr, buf, sizeof(buf)) != 0)
		return 0;

	if (!linyu_hide_path_match(buf))
		return 0;

	
	regs->regs[0] = (unsigned long)-ENOENT;
	instruction_pointer_set(regs, (unsigned long)regs->regs[30]);
	return 1;
}

static int linyu_hide_vfs_open_pre(struct kprobe *p, struct pt_regs *regs)
{
	const struct path *path_ptr = (const struct path *)regs->regs[0];
	char buf[256];

	if (!path_ptr)
		return 0;
	if (linyu_hide_vfs_path_to_str(path_ptr, buf, sizeof(buf)) != 0)
		return 0;
	if (!linyu_hide_path_match(buf))
		return 0;

	regs->regs[0] = (unsigned long)-ENOENT;
	instruction_pointer_set(regs, (unsigned long)regs->regs[30]);
	return 1;
}

struct hide_probe {
	struct kprobe kp;
	bool          registered;
};

#define HOOK_ENT(_sym, _pre)                          \
	{ .kp = { .symbol_name = _sym, .pre_handler = _pre } }

static struct hide_probe hide_probes[] = {
	HOOK_ENT("vfs_open",                 linyu_hide_vfs_open_pre),
	HOOK_ENT("vfs_getattr",              linyu_hide_vfs_path_arg2_pre),
	HOOK_ENT("vfs_getattr_nosec",        linyu_hide_vfs_path_arg2_pre),
	HOOK_ENT("vfs_statfs",               linyu_hide_vfs_path_arg2_pre),
};

static struct kprobe kill_kp;
static bool          kill_kp_registered;
static bool          kill_hook_is_syscall_wrapper;

static int linyu_hide_kill_pre(struct kprobe *p, struct pt_regs *regs)
{
	pid_t target;

	if (kill_hook_is_syscall_wrapper) {
		
		struct pt_regs *user = (struct pt_regs *)regs->regs[0];
		if (!user)
			return 0;
		target = (pid_t)user->regs[0];
	} else {
		
		target = (pid_t)regs->regs[0];
	}

	if (target <= 0)
		return 0;
	if (!linyu_hide_pid_match(target))
		return 0;

	
	regs->regs[0] = 0;
	instruction_pointer_set(regs, (unsigned long)regs->regs[30]);
	return 1;
}

int linyu_hide_kill_init(void)
{
	int ret;

	if (kill_kp_registered)
		return 0;

	memset(&kill_kp, 0, sizeof(kill_kp));
	kill_kp.symbol_name = "ksys_kill";
	kill_kp.pre_handler = linyu_hide_kill_pre;
	kill_hook_is_syscall_wrapper = false;

	ret = register_kprobe(&kill_kp);
	if (ret) {
		memset(&kill_kp, 0, sizeof(kill_kp));
		kill_kp.symbol_name = "__arm64_sys_kill";
		kill_kp.pre_handler = linyu_hide_kill_pre;
		kill_hook_is_syscall_wrapper = true;
		ret = register_kprobe(&kill_kp);
		if (ret) {
			linyu_warn("hide_vfs: kill kprobe failed: %d\n", ret);
			return ret;
		}
	}
	kill_kp_registered = true;
	linyu_info("hide_vfs: kill hook installed (%s)\n", kill_kp.symbol_name);
	return 0;
}

void linyu_hide_kill_exit(void)
{
	if (kill_kp_registered) {
		unregister_kprobe(&kill_kp);
		kill_kp_registered = false;
	}
}

int linyu_hide_vfs_init(void)
{
	int i, ok = 0;

	for (i = 0; i < ARRAY_SIZE(hide_probes); i++) {
		int rc = register_kprobe(&hide_probes[i].kp);
		if (rc == 0) {
			hide_probes[i].registered = true;
			ok++;
		} else {
			linyu_warn("hide_vfs: kprobe %s failed: %d\n",
				   hide_probes[i].kp.symbol_name, rc);
		}
	}
	linyu_info("hide_vfs: %d/%zu vfs probes installed\n",
		   ok, ARRAY_SIZE(hide_probes));
	return ok > 0 ? 0 : -ENOENT;
}

void linyu_hide_vfs_exit(void)
{
	int i;

	for (i = 0; i < ARRAY_SIZE(hide_probes); i++) {
		if (hide_probes[i].registered) {
			unregister_kprobe(&hide_probes[i].kp);
			hide_probes[i].registered = false;
		}
	}
}
