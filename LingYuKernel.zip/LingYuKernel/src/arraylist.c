#include "linyu.h"
#include <linux/slab.h>
#include <linux/string.h>

struct linyu_arraylist {
	void **items;
	size_t count;
	size_t capacity;
};

#define MIN_CAPACITY 16

struct linyu_arraylist *linyu_arraylist_create(size_t initial_capacity)
{
	struct linyu_arraylist *al;

	al = kmalloc(sizeof(*al), GFP_KERNEL);
	if (!al)
		return NULL;

	if (initial_capacity < MIN_CAPACITY)
		initial_capacity = MIN_CAPACITY;
	if (initial_capacity > (SIZE_MAX / sizeof(void *))) {
		kfree(al);
		return NULL;
	}

	al->items = kmalloc_array(initial_capacity, sizeof(void *), GFP_KERNEL);
	if (!al->items) {
		kfree(al);
		return NULL;
	}
	al->count = 0;
	al->capacity = initial_capacity;
	return al;
}

int linyu_arraylist_add(struct linyu_arraylist *al, void *item)
{
	if (!al)
		return -EINVAL;

	if (al->count == al->capacity) {
		size_t new_cap = al->capacity + (al->capacity >> 1);
		void **new_items;

		if (new_cap < al->count + 1)
			new_cap = al->count + 1;
		if (new_cap > (SIZE_MAX / sizeof(void *)))
			return -ENOMEM;

		new_items = krealloc(al->items, sizeof(void *) * new_cap, GFP_KERNEL);
		if (!new_items)
			return -ENOMEM;
		al->items = new_items;
		al->capacity = new_cap;
	}

	al->items[al->count++] = item;
	return 0;
}

void *linyu_arraylist_get(struct linyu_arraylist *al, size_t idx)
{
	if (!al || idx >= al->count)
		return NULL;
	return al->items[idx];
}

void *linyu_arraylist_remove(struct linyu_arraylist *al, size_t idx)
{
	void *ret;

	if (!al || idx >= al->count)
		return NULL;

	ret = al->items[idx];
	if (idx + 1 < al->count)
		memmove(&al->items[idx], &al->items[idx + 1],
			sizeof(void *) * (al->count - idx - 1));
	al->count--;
	return ret;
}

void linyu_arraylist_clear(struct linyu_arraylist *al)
{
	if (al)
		al->count = 0;
}

void linyu_arraylist_destroy(struct linyu_arraylist *al)
{
	if (!al)
		return;
	kfree(al->items);
	kfree(al);
}

size_t linyu_arraylist_count(const struct linyu_arraylist *al)
{
	return al ? al->count : 0;
}
