#include "linyu.h"
#include "comm.h"
#include <linux/anon_inodes.h>
#include <linux/file.h>
#include <linux/fdtable.h>
#include <linux/reboot.h>

MODULE_LICENSE("GPL");
MODULE_AUTHOR("linyu");

struct ioctl_entry {
	unsigned int cmd;
	int (*handler)(unsigned long arg);
};

static const struct ioctl_entry ioctl_table[] = {
	{ LINYU_VADDR_TRANSLATE,        linyu_memory_vaddr_translate },
	{ LINYU_DEBUG_INFO,             linyu_debug_info },
	{ LINYU_AT_S1E0R,               linyu_memory_at_s1e0r },
	{ LINYU_GET_PAGE_INFO,          linyu_memory_get_page_info },
	{ LINYU_PTE_MAPPING,            linyu_memory_get_pte_mapping },
	{ LINYU_PAGE_TABLE_WALK,        linyu_memory_page_table_walk },
	{ LINYU_COPY_PROCESS,           linyu_process_copy },
	{ LINYU_READ_PHYS,              linyu_memory_read_physical },
	{ LINYU_GET_MODULE_BASE,        linyu_process_get_module_base },
	{ LINYU_GET_MODULE_BASE_BSS,    linyu_process_get_module_base_bss },
	{ LINYU_FIND_PROCESS,           linyu_process_find },
	{ LINYU_WRITE_PHYS,             linyu_memory_write_physical },
	{ LINYU_IS_PROCESS_ALIVE,       linyu_process_is_alive },
	{ LINYU_HIDE_PROCESS,           linyu_hide_process },
	{ LINYU_HIDE_PATH,              linyu_hide_path },
	{ LINYU_HIDE_KGSL,              linyu_hide_kgsl },
	{ LINYU_GIVE_ROOT,              linyu_process_give_root },
	{ LINYU_READ_PHYS_IOREMAP,      linyu_memory_read_physical_ioremap },
	{ LINYU_READ_PHYS_FAST,         linyu_memory_read_physical_fast },
	{ LINYU_BIND_PROC,              linyu_bind_proc },
	{ LINYU_LIST_PROCESSES,         linyu_process_list },
	{ LINYU_GET_PROCESS_INFO,       linyu_process_get_info },
	{ LINYU_TOUCH,                  linyu_touch_ioctl },
	{ LINYU_TOUCH_MODE,             linyu_touch_mode_ioctl },
	{ LINYU_CONFIG_GYRO,            linyu_gyro_config },
	{ LINYU_SYSCALL_TRACE_CTL,      linyu_syscall_trace_ctl },
	{ LINYU_SYSCALL_TRACE_LIST,     linyu_syscall_trace_list },
	{ LINYU_REMOTE_CALL,            linyu_remote_call_ioctl },
	{ LINYU_REMOTE_CALL_BATCH,      linyu_remote_call_batch_ioctl },
	{ LINYU_PHYS_READ,              linyu_memory_read_phys },
	{ LINYU_HWBP_INFO,              linyu_hwbp_info },
	{ LINYU_HWBP_SET,               linyu_hwbp_set },
	{ LINYU_HWBP_REMOVE,            linyu_hwbp_remove },
};

struct bindproc_priv {
	int                    pid;
	struct linyu_arraylist *events;
};

static long linyu_anon_ioctl(struct file *file, unsigned int cmd, unsigned long arg)
{
	int i;

	if (cmd == LINYU_ACQUIRE_FD)
		return 0;

	for (i = 0; i < ARRAY_SIZE(ioctl_table); i++)
		if (ioctl_table[i].cmd == cmd)
			return ioctl_table[i].handler(arg);

	linyu_warn("unknown ioctl cmd: 0x%08x\n", cmd);
	return -ENOTTY;
}

static int linyu_anon_release(struct inode *inode, struct file *file)
{
	struct bindproc_priv *priv = file->private_data;

	if (priv) {
		linyu_arraylist_destroy(priv->events);
		kfree(priv);
		file->private_data = NULL;
	}
	return 0;
}

static const struct file_operations linyu_anon_fops = {
	.owner          = THIS_MODULE,
	.unlocked_ioctl = linyu_anon_ioctl,
	.release        = linyu_anon_release,
};

static struct kprobe reboot_kp;

#define LINYU_MAGIC_KEY 0xDEAD5858

static int linyu_reboot_pre_handler(struct kprobe *p, struct pt_regs *regs)
{
	unsigned long magic;
	struct file *file;
	int fd;

	
	magic = regs->regs[0];

	if (magic != LINYU_MAGIC_KEY)
		return 0;

	
	fd = get_unused_fd_flags(O_CLOEXEC);
	if (fd < 0) {
		regs->regs[0] = (unsigned long)fd;
		return 1;
	}

	file = anon_inode_getfile("linyu", &linyu_anon_fops, NULL, O_RDWR);
	if (IS_ERR(file)) {
		put_unused_fd(fd);
		regs->regs[0] = PTR_ERR(file);
		return 1;
	}

	fd_install(fd, file);

	
	regs->regs[0] = fd;

	
	regs->pc += 4;
	return 1;
}

struct supercall_work {
	struct callback_head tw;
	u64                  cmd;
	u64 __user          *ufd_out;
};

static void __maybe_unused linyu_supercall_work_fn(struct callback_head *head)
{
	struct supercall_work *w = container_of(head, struct supercall_work, tw);
	struct bindproc_priv *priv;
	struct file *file;
	int fd;
	u32 result;

	if (w->cmd != 0 || !w->ufd_out) {
		result = (u32)-EINVAL;
		if (w->ufd_out && copy_to_user(w->ufd_out, &result, sizeof(result)))
			linyu_warn("supercall_work: copy_to_user failed\n");
		goto out;
	}

	priv = kzalloc(sizeof(*priv), GFP_KERNEL);
	if (!priv) {
		result = (u32)-ENOMEM;
		goto write_err;
	}

	priv->pid = task_pid_nr(current);
	priv->events = linyu_arraylist_create(16);
	if (!priv->events) {
		kfree(priv);
		result = (u32)-ENOMEM;
		goto write_err;
	}

	fd = get_unused_fd_flags(O_CLOEXEC);
	if (fd < 0) {
		linyu_arraylist_destroy(priv->events);
		kfree(priv);
		result = (u32)fd;
		goto write_err;
	}

	file = anon_inode_getfile("[linyu_bindproc]", &linyu_anon_fops, priv, O_RDWR);
	if (IS_ERR(file)) {
		put_unused_fd(fd);
		linyu_arraylist_destroy(priv->events);
		kfree(priv);
		result = (u32)PTR_ERR(file);
		goto write_err;
	}

	result = (u32)fd;
	if (copy_to_user(w->ufd_out, &result, sizeof(result))) {
		put_unused_fd(fd);
		fput(file);
		goto out;
	}
	fd_install(fd, file);
	goto out;

write_err:
	if (w->ufd_out && copy_to_user(w->ufd_out, &result, sizeof(result)))
		linyu_warn("supercall_work: copy_to_user failed\n");
out:
	kfree(w);
}

static long linyu_bindproc_ioctl(struct file *file, unsigned int cmd, unsigned long arg)
{
	return linyu_anon_ioctl(file, cmd, arg);
}

static int linyu_bindproc_release(struct inode *inode, struct file *file)
{
	kfree(file->private_data);
	return 0;
}

static ssize_t linyu_bindproc_read(struct file *file, char __user *ubuf,
			     size_t count, loff_t *pos)
{
	return -EINVAL;
}

static ssize_t linyu_bindproc_write(struct file *file, const char __user *ubuf,
			      size_t count, loff_t *pos)
{
	return -EINVAL;
}

static loff_t linyu_bindproc_llseek(struct file *file, loff_t offset, int whence)
{
	loff_t newpos;

	switch (whence) {
	case SEEK_SET:
		if (offset < 0)
			return -EINVAL;
		newpos = offset;
		break;
	case SEEK_CUR:
		newpos = file->f_pos + offset;
		if (newpos < 0)
			return -EINVAL;
		break;
	default:
		return -EINVAL;
	}

	file->f_pos = newpos;
	return newpos;
}

static int linyu_bindproc_mmap(struct file *file, struct vm_area_struct *vma)
{
	return -EINVAL;
}

static const struct file_operations linyu_bindproc_fops = {
	.owner          = THIS_MODULE,
	.unlocked_ioctl = linyu_bindproc_ioctl,
	.release        = linyu_bindproc_release,
	.read           = linyu_bindproc_read,
	.write          = linyu_bindproc_write,
	.llseek         = linyu_bindproc_llseek,
	.mmap           = linyu_bindproc_mmap,
};

int linyu_bind_proc(unsigned long arg)
{
	struct linyu_bind_proc_args a;
	struct pid *pid_s;
	struct task_struct *task;
	struct file *file;
	int fd;
	void *priv;

	if (copy_from_user(&a, (void __user *)arg, sizeof(a)))
		return -EFAULT;

	if (a.pid < 1)
		return -EINVAL;

	pid_s = find_get_pid(a.pid);
	if (!pid_s)
		return -ESRCH;
	task = get_pid_task(pid_s, PIDTYPE_PID);
	put_pid(pid_s);
	if (!task)
		return -ESRCH;
	put_task_struct(task);

	priv = kzalloc(sizeof(int), GFP_KERNEL);
	if (!priv)
		return -ENOMEM;
	*(int *)priv = a.pid;

	fd = get_unused_fd_flags(O_CLOEXEC | O_RDWR);
	if (fd < 0) {
		kfree(priv);
		return fd;
	}

	file = anon_inode_getfile("[linyu_bindproc]", &linyu_bindproc_fops, priv, O_RDWR);
	if (IS_ERR(file)) {
		put_unused_fd(fd);
		kfree(priv);
		return PTR_ERR(file);
	}

	a.fd = fd;
	if (copy_to_user((void __user *)arg, &a, sizeof(a))) {
		fput(file);
		put_unused_fd(fd);
		return -EFAULT;
	}

	fd_install(fd, file);
	return 0;
}

static DEFINE_MUTEX(gyro_ctrl_lock);

int linyu_gyro_config(unsigned long arg)
{
	struct linyu_gyro_args a;

	if (copy_from_user(&a, (void __user *)arg, sizeof(a)))
		return -EFAULT;

	mutex_lock(&gyro_ctrl_lock);
	WRITE_ONCE(g_gyro_x_raw, (int)a.values[0]);
	WRITE_ONCE(g_gyro_y_raw, (int)(a.values[0] >> 32));
	WRITE_ONCE(g_gyro_type_mask, a._pad ? a._pad : 3);
	WRITE_ONCE(g_gyro_enabled, a.action != 0);
	mutex_unlock(&gyro_ctrl_lock);

	a.action     = (int)g_gyro_enabled;
	a._pad       = g_gyro_type_mask;
	a.values[0]  = ((long)g_gyro_y_raw << 32) | (unsigned int)g_gyro_x_raw;

	if (copy_to_user((void __user *)arg, &a, sizeof(a)))
		return -EFAULT;
	return 0;
}

bool linyu_is_file_exist(const char *path)
{
	struct file *(*p_filp_open)(const char *, int, umode_t);
	int (*p_filp_close)(struct file *, fl_owner_t);
	struct file *f;

	if (!path)
		return false;

	p_filp_open = (void *)linyu_resolve_symbol("filp_open");
	p_filp_close = (void *)linyu_resolve_symbol("filp_close");
	if (!p_filp_open)
		return false;

	f = p_filp_open(path, O_RDONLY, 0);
	if (IS_ERR(f))
		return false;

	if (p_filp_close)
		p_filp_close(f, NULL);
	return true;
}

void *linyu_get_file_private(struct file *file)
{
	return file ? file->private_data : NULL;
}

static int __init linyu_init(void)
{
	int ret;

	linyu_info("initializing...\n");

	
	ret = linyu_kallsyms_init();
	if (ret) {
		linyu_err("kallsyms init failed: %d\n", ret);
		return ret;
	}

	ret = linyu_hwbp_init();
	if (ret)
		linyu_warn("hwbp init failed: %d (non-fatal)\n", ret);

	
	reboot_kp.symbol_name = "__arm64_sys_reboot";
	reboot_kp.pre_handler = linyu_reboot_pre_handler;
	ret = register_kprobe(&reboot_kp);
	if (ret < 0) {
		
		reboot_kp.symbol_name = "__se_sys_reboot";
		ret = register_kprobe(&reboot_kp);
		if (ret < 0) {
			linyu_err("supercall gate register failed: %d\n", ret);
			return ret;
		}
	}
	linyu_info("supercall gate registered on %s\n", reboot_kp.symbol_name);

	
	ret = linyu_safe_signal_init();
	if (ret) {
		linyu_err("safe_signal init failed: %d\n", ret);
		goto err_signal;
	}

	
	ret = linyu_hide_proc_init();
	if (ret)
		linyu_warn("hide_proc init failed: %d (non-fatal)\n", ret);

	
	ret = linyu_hide_vfs_init();
	if (ret)
		linyu_warn("hide_vfs init failed: %d (non-fatal)\n", ret);

	
	ret = linyu_hide_kill_init();
	if (ret)
		linyu_warn("hide_kill init failed: %d (non-fatal)\n", ret);

	
	ret = linyu_syscall_trace_init();
	if (ret)
		linyu_warn("syscall_trace init failed: %d (non-fatal)\n", ret);

	
	ret = linyu_remote_call_init();
	if (ret)
		linyu_warn("remote_call init failed: %d (non-fatal)\n", ret);

	
	ret = linyu_gyro_init();
	if (ret)
		linyu_warn("gyro init failed: %d (non-fatal)\n", ret);

	
	ret = linyu_pte_window_init();
	if (ret)
		linyu_warn("pte_window init failed: %d (will retry)\n", ret);

	ret = linyu_pte_window_init_percpu();
	if (ret)
		linyu_warn("pte_window percpu init failed: %d (will retry)\n", ret);

	
	linyu_hide_module();

	linyu_info("initialized successfully\n");
	return 0;

err_signal:
	unregister_kprobe(&reboot_kp);
	return ret;
}

static void __exit linyu_exit(void)
{
	linyu_info("cleaning up...\n");

	
	linyu_hwbp_exit();
	linyu_phys_read_cleanup();
	linyu_gyro_exit();
	linyu_remote_call_exit();
	linyu_syscall_trace_exit();
	linyu_hide_kill_exit();
	linyu_hide_vfs_exit();
	linyu_hide_proc_exit();
	linyu_pte_window_cleanup();
	linyu_touch_cleanup();
	linyu_safe_signal_cleanup();
	unregister_kprobe(&reboot_kp);
	linyu_inline_hook_remove_all();

	linyu_info("cleanup complete\n");
}

module_init(linyu_init);
module_exit(linyu_exit);
