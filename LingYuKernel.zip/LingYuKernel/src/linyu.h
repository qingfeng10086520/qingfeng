#ifndef _LINYU_H_
#define _LINYU_H_

#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/types.h>
#include <linux/fs.h>
#include <linux/mm.h>
#include <linux/pid.h>
#include <linux/sched.h>
#include <linux/sched/mm.h>
#include <linux/sched/task.h>
#include <linux/uaccess.h>
#include <linux/slab.h>
#include <linux/mutex.h>
#include <linux/spinlock.h>
#include <linux/kprobes.h>
#include <linux/version.h>
#include <linux/vmalloc.h>
#include <asm/pgtable.h>
#include <asm/tlbflush.h>
#include <asm/io.h>

#define LINYU_TAG "[linyu] "
#ifdef LINYU_DEBUG_LOG
#define linyu_info(fmt, ...)  printk(KERN_INFO  LINYU_TAG fmt, ##__VA_ARGS__)
#else
#define linyu_info(fmt, ...)  do { } while (0)
#endif
#define linyu_err(fmt, ...)   printk(KERN_ERR   LINYU_TAG fmt, ##__VA_ARGS__)
#define linyu_warn(fmt, ...)  printk(KERN_WARNING LINYU_TAG fmt, ##__VA_ARGS__)

#define LINYU_MAX_CPUS 32

typedef unsigned long (*kallsyms_lookup_name_t)(const char *name);
extern kallsyms_lookup_name_t linyu_kallsyms_lookup_name;

int  linyu_kallsyms_init(void);
unsigned long linyu_resolve_symbol(const char *name);

struct pte_cpu_window {
	pte_t    *ptep;
	unsigned long vaddr;
	unsigned long last_pfn;
};

extern struct pte_cpu_window __percpu *g_cpu_windows;
extern unsigned long g_pte_window;
extern pte_t *g_pte_window_ptep;
extern unsigned long g_pte_read_last_pfn;

int  linyu_pte_window_init(void);
int  linyu_pte_window_init_percpu(void);
void linyu_pte_window_cleanup(void);

int  linyu_pte_read_physical(phys_addr_t pa, void *dest, size_t len);
int  linyu_pte_read_nc_fast(phys_addr_t pa, void *dest, size_t len);
int  linyu_read_phys_to_user(phys_addr_t pa, void __user *ubuf, size_t len);
int  linyu_pte_write_physical(phys_addr_t pa, const void *src, size_t len);

int  linyu_convert_wmt_to_pgprot(unsigned int wmt, u64 *out);
void linyu_clean_dcache_area(unsigned long addr, size_t len);
void *linyu_ioremap_prot(phys_addr_t phys, size_t len, unsigned long prot_val);
void linyu_pte_window_hide_vmalloc(void);
int  linyu_read_ptem(phys_addr_t pa, void *dest, size_t len);
int  linyu_read_line(phys_addr_t pa, void *dest);

phys_addr_t linyu_vaddr_to_phys(struct mm_struct *mm, unsigned long va);
phys_addr_t linyu_walk_page_tables(struct mm_struct *mm, unsigned long va);
int  linyu_translate_process_vaddr(pid_t pid, unsigned long va, phys_addr_t *pa_out);

int  linyu_memory_read_physical(unsigned long arg);
int  linyu_memory_write_physical(unsigned long arg);
int  linyu_memory_read_physical_ioremap(unsigned long arg);
int  linyu_memory_read_physical_fast(unsigned long arg);
int  linyu_memory_read_phys(unsigned long arg);

struct task_struct *linyu_get_target_task(pid_t pid);
unsigned long linyu_get_module_base(pid_t pid, const char *name);
unsigned long linyu_get_module_base_bss(pid_t pid, const char *name);
pid_t linyu_find_process_by_name(const char *name);
int   linyu_is_pid_alive(pid_t pid);

int  linyu_process_find(unsigned long arg);
int  linyu_process_get_module_base(unsigned long arg);
int  linyu_process_get_module_base_bss(unsigned long arg);
int  linyu_process_is_alive(unsigned long arg);
int  linyu_process_list(unsigned long arg);
int  linyu_process_get_info(unsigned long arg);
int  linyu_process_copy(unsigned long arg);

int  linyu_memory_vaddr_translate(unsigned long arg);
int  linyu_debug_info(unsigned long arg);
int  linyu_memory_at_s1e0r(unsigned long arg);
int  linyu_memory_get_page_info(unsigned long arg);
int  linyu_memory_get_pte_mapping(unsigned long arg);
int  linyu_memory_page_table_walk(unsigned long arg);

int  linyu_process_give_root(unsigned long arg);

int  linyu_hide_module(void);
int  linyu_hide_proc_init(void);
void linyu_hide_proc_exit(void);

bool linyu_hide_pid_match(pid_t pid);
bool linyu_hide_path_match(const char *fullpath);

int  linyu_hide_vfs_init(void);
void linyu_hide_vfs_exit(void);

int  linyu_hide_kill_init(void);
void linyu_hide_kill_exit(void);

int  linyu_hide_process(unsigned long arg);
int  linyu_hide_path(unsigned long arg);
int  linyu_hide_kgsl(unsigned long arg);

void linyu_touch_cleanup(void);

int  linyu_touch_ioctl(unsigned long arg);
int  linyu_touch_mode_ioctl(unsigned long arg);

extern bool g_gyro_enabled;
extern int  g_gyro_type_mask;
extern int  g_gyro_x_raw;
extern int  g_gyro_y_raw;
int  linyu_gyro_init(void);
void linyu_gyro_exit(void);
u32  linyu_add_float_ieee754(u32 a, u32 b);
int  linyu_gyro_config(unsigned long arg);

int  linyu_syscall_trace_init(void);
void linyu_syscall_trace_exit(void);

int  linyu_syscall_trace_ctl(unsigned long arg);
int  linyu_syscall_trace_list(unsigned long arg);

int  linyu_remote_call_init(void);
void linyu_remote_call_exit(void);
bool linyu_rc_try_restore_context(pid_t pid);

int  linyu_remote_call_ioctl(unsigned long arg);
int  linyu_remote_call_batch_ioctl(unsigned long arg);

extern void *linyu_hwbp_k_buf;
int  linyu_hwbp_init(void);
void linyu_hwbp_exit(void);
void linyu_hwbp_init_insn_patch(void);

int  linyu_hwbp_info(unsigned long arg);
int  linyu_hwbp_set(unsigned long arg);
int  linyu_hwbp_remove(unsigned long arg);
int  linyu_hw_breakpoint_parse(const void *in, u64 out[2]);
void linyu_sample_hbp_handler(void *event, struct pt_regs *regs);

int  linyu_inline_hook_install(void *target, void *hook, void **orig);
int  linyu_inline_hook_remove(void *target);
void linyu_inline_hook_remove_all(void);
bool linyu_check_target_can_hijack(const void *target, int count);
int  linyu_hook_write_range(void *dst, const void *src, int len);
int  linyu_inline_hook_count(void);

int  linyu_bind_proc(unsigned long arg);

int  linyu_safe_signal_init(void);
void linyu_safe_signal_cleanup(void);
int  linyu_add_unsafe_region(int pid, unsigned long vaddr, u32 size, u32 tag);
int  linyu_del_unsafe_region(int pid);
bool linyu_check_unsafe_region(int pid, unsigned long vaddr);

void linyu_phys_read_cleanup(void);

struct linyu_arraylist;
struct linyu_arraylist *linyu_arraylist_create(size_t initial_capacity);
int    linyu_arraylist_add(struct linyu_arraylist *al, void *item);
void  *linyu_arraylist_get(struct linyu_arraylist *al, size_t idx);
void  *linyu_arraylist_remove(struct linyu_arraylist *al, size_t idx);
void   linyu_arraylist_clear(struct linyu_arraylist *al);
void   linyu_arraylist_destroy(struct linyu_arraylist *al);
size_t linyu_arraylist_count(const struct linyu_arraylist *al);

bool linyu_is_file_exist(const char *path);
void *linyu_get_file_private(struct file *file);

extern struct mm_struct *s_last_mm;
extern pid_t s_last_pid;
extern struct mutex linyu_read_mutex;

void linyu_cleanup_mm_cache(void);
void linyu_pte_caches_clear(void);

#endif 
