#include "linyu.h"
#include "comm.h"
#include <linux/completion.h>
#include <linux/sched/signal.h>
#include <linux/pid.h>
#include <linux/task_work.h>
#include <linux/uaccess.h>
#include <linux/slab.h>
#include <linux/list.h>

#define RC_STRUCT_SIZE     360   
#define RC_BATCH_HDR_SIZE  40    
#define RC_MAX_BATCH       256

#define RC_STATE_PENDING   0
#define RC_STATE_RUNNING   1
#define RC_STATE_DONE      2
#define RC_STATE_FAILED    3

struct rc_call {
	u64 func_addr;
	u64 args[8];
	u64 caller_sp;       
	u32 retbuf_size;     
	u32 _pad;
};

struct rc_state {
	atomic_t       refcount;        
	struct list_head node;          
	struct callback_head tw;        
	struct task_struct *target;

	struct rc_call *call;           
	int             call_count;     
	int             cur_idx;        
	u64             saved_sp_copy;  

	
	bool            ctx_saved;      
	struct pt_regs  saved_regs;     

	
	u8              fpsimd_saved_state[520];
	bool            fpsimd_saved;   

	
	u64             saved_addr_limit;  
	u64             saved_ttbr;        
	u64             saved_pstate;      
	u64             saved_pc_extra;    
	bool            regs_saved;        

	
	int             status;          
	int             error_code;      

	
	struct completion done;          

	u64             retvals[8];      
	u8              retbuf[512];     
	u32             retbuf_len;
};

static LIST_HEAD(g_rc_list);
static DEFINE_SPINLOCK(g_rc_lock);
static bool rc_inited;

static int (*p_task_work_add)(struct task_struct *task,
			      struct callback_head *twork,
			      enum task_work_notify_mode mode);
static struct callback_head *(*p_task_work_cancel_func)(struct task_struct *task,
							task_work_func_t func);
static void (*p_fpsimd_preserve)(void);

static struct kprobe rc_force_sig_kp;
static bool rc_force_sig_kp_registered;

typedef int (*rc_trampoline_writer_t)(struct task_struct *,
				      struct rc_state *,
				      const struct rc_call *);
static rc_trampoline_writer_t __maybe_unused g_rc_trampoline_writer;

static void linyu_rc_get(struct rc_state *rc)
{
	atomic_inc(&rc->refcount);
}

static void linyu_rc_put(struct rc_state *rc)
{
	if (atomic_dec_and_test(&rc->refcount)) {
		kfree(rc->call);
		kfree(rc);
	}
}

static int linyu_rc_force_sig_pre(struct kprobe *p, struct pt_regs *regs)
{
	int sig      = (int)regs->regs[0];
	int code     = (int)regs->regs[1];
	unsigned long addr = regs->regs[2];
	pid_t pid;

	(void)code;

	if (sig != SIGSEGV && sig != SIGBUS)
		return 0;

	pid = task_pid_nr(current);
	if (linyu_check_unsafe_region(pid, addr)) {
		
		regs->pc += 4;
		return 1;
	}
	return 0;
}

int linyu_remote_call_init(void)
{
	int ret;

	p_task_work_add    = (void *)linyu_resolve_symbol("task_work_add");
	p_task_work_cancel_func =
		(void *)linyu_resolve_symbol("task_work_cancel_func");
	if (!p_task_work_add) {
		linyu_warn("remote_call: task_work_add not found\n");
		return -ENOENT;
	}

	p_fpsimd_preserve = (void *)linyu_resolve_symbol(
				"fpsimd_preserve_current_state");
	if (!p_fpsimd_preserve)
		linyu_warn("remote_call: fpsimd_preserve not found (non-fatal)\n");

	
	memset(&rc_force_sig_kp, 0, sizeof(rc_force_sig_kp));
	rc_force_sig_kp.symbol_name = "force_sig_fault";
	rc_force_sig_kp.pre_handler = linyu_rc_force_sig_pre;
	ret = register_kprobe(&rc_force_sig_kp);
	if (ret)
		linyu_warn("remote_call: force_sig_fault kprobe failed: %d\n", ret);
	else
		rc_force_sig_kp_registered = true;

	rc_inited = true;
	linyu_info("remote_call: initialized\n");
	return 0;
}

void linyu_remote_call_exit(void)
{
	struct rc_state *rc, *tmp;
	unsigned long flags;
	LIST_HEAD(drain);

	if (rc_force_sig_kp_registered) {
		unregister_kprobe(&rc_force_sig_kp);
		rc_force_sig_kp_registered = false;
	}

	spin_lock_irqsave(&g_rc_lock, flags);
	list_for_each_entry_safe(rc, tmp, &g_rc_list, node) {
		list_del_init(&rc->node);
		rc->status = RC_STATE_FAILED;
		list_add_tail(&rc->node, &drain);
	}
	spin_unlock_irqrestore(&g_rc_lock, flags);

	list_for_each_entry_safe(rc, tmp, &drain, node) {
		list_del_init(&rc->node);
		complete(&rc->done);
		linyu_rc_put(rc);
	}

	rc_inited = false;
}

static int linyu_rc_prepare_target(pid_t pid, struct task_struct **out_task)
{
	struct pid *pid_s;
	struct task_struct *task;

	pid_s = find_get_pid(pid);
	if (!pid_s)
		return -ESRCH;
	task = get_pid_task(pid_s, PIDTYPE_PID);
	put_pid(pid_s);
	if (!task)
		return -ESRCH;
	if (!task->mm) {
		put_task_struct(task);
		return -EINVAL;
	}
	*out_task = task;
	return 0;
}

static void linyu_rc_tw_callback(struct callback_head *head)
{
	struct rc_state *rc = container_of(head, struct rc_state, tw);
	struct pt_regs *regs;
	const struct rc_call *c;
	unsigned long flags;
	struct thread_struct *thread;

	if (!rc || !rc->call || !rc->call_count)
		goto done;

	
	thread = &current->thread;
	if (fatal_signal_pending(current) || !rc->call[0].func_addr) {
		
		spin_lock_irqsave(&g_rc_lock, flags);
		rc->status = RC_STATE_FAILED;
		rc->error_code = -EINTR;
		list_del_init(&rc->node);
		spin_unlock_irqrestore(&g_rc_lock, flags);
		complete(&rc->done);
		linyu_rc_put(rc);
		return;
	}

	regs = task_pt_regs(current);
	c    = &rc->call[0]; 

	
	memcpy(&rc->saved_regs, regs, sizeof(*regs));
	rc->ctx_saved = true;

	
	rc->saved_addr_limit = thread->uw.tp_value;
	rc->saved_ttbr       = thread->uw.tp2_value;
	rc->saved_pstate     = regs->pstate;
	rc->saved_pc_extra   = regs->pc;
	rc->regs_saved       = true;

	
	rc->cur_idx = 0;

	
	rc->saved_sp_copy = 0;

	
	regs->pc        = c->func_addr;
	regs->regs[0]   = c->args[0];
	regs->regs[1]   = c->args[1];
	regs->regs[2]   = c->args[2];
	regs->regs[3]   = c->args[3];
	regs->regs[4]   = c->args[4];
	regs->regs[5]   = c->args[5];
	regs->regs[6]   = c->args[6];
	regs->regs[7]   = c->args[7];

	
	regs->regs[30]  = rc->saved_regs.pc;

	

	if (c->retbuf_size) {
		u64 new_sp = (rc->saved_regs.sp -
			      ALIGN(c->retbuf_size, 16)) & ~0xFULL;
		regs->sp = new_sp;
		rc->saved_sp_copy = new_sp;
	} else if (c->caller_sp) {
		regs->sp = c->caller_sp;
	}

	
	rc->status = RC_STATE_RUNNING;

	
	if (p_fpsimd_preserve) {
		p_fpsimd_preserve();
		

		memcpy(rc->fpsimd_saved_state,
		       &thread->uw.fpsimd_state,
		       min_t(size_t, sizeof(rc->fpsimd_saved_state),
			     sizeof(thread->uw.fpsimd_state)));
		wmb();
		rc->fpsimd_saved = true;
	}

	linyu_rc_put(rc);
	return;

done:
	linyu_rc_put(rc);
}

static int linyu_rc_dispatch(struct task_struct *task, struct rc_state *rc)
{
	unsigned long flags;
	int ret;

	if (!p_task_work_add)
		return -ENOSYS;

	init_completion(&rc->done);
	atomic_set(&rc->refcount, 2); 
	rc->target = task;
	rc->cur_idx = 0;
	rc->ctx_saved = false;
	rc->fpsimd_saved = false;
	rc->regs_saved = false;
	rc->status = RC_STATE_PENDING;
	rc->error_code = 0;
	init_task_work(&rc->tw, linyu_rc_tw_callback);

	spin_lock_irqsave(&g_rc_lock, flags);
	list_add_tail(&rc->node, &g_rc_list);
	spin_unlock_irqrestore(&g_rc_lock, flags);

	ret = p_task_work_add(task, &rc->tw, TWA_RESUME);
	if (ret) {
		spin_lock_irqsave(&g_rc_lock, flags);
		list_del_init(&rc->node);
		spin_unlock_irqrestore(&g_rc_lock, flags);
		linyu_rc_put(rc); 
		rc->status = RC_STATE_FAILED;
		complete(&rc->done);
	}
	return ret;
}

bool linyu_rc_try_restore_context(pid_t pid)
{
	struct rc_state *rc;
	unsigned long flags;
	struct pt_regs *regs;
	struct thread_struct *thread;
	bool found = false;

	spin_lock_irqsave(&g_rc_lock, flags);
	list_for_each_entry(rc, &g_rc_list, node) {
		if (rc->target && task_pid_nr(rc->target) == pid &&
		    rc->status == RC_STATE_RUNNING) {
			found = true;
			linyu_rc_get(rc);
			break;
		}
	}
	spin_unlock_irqrestore(&g_rc_lock, flags);

	if (!found)
		return false;

	regs = task_pt_regs(current);
	thread = &current->thread;

	
	if (rc->ctx_saved)
		memcpy(regs, &rc->saved_regs, sizeof(*regs));

	
	if (rc->fpsimd_saved) {
		memcpy(&thread->uw.fpsimd_state,
		       rc->fpsimd_saved_state,
		       min_t(size_t, sizeof(rc->fpsimd_saved_state),
			     sizeof(thread->uw.fpsimd_state)));
	}

	
	spin_lock_irqsave(&g_rc_lock, flags);
	list_del_init(&rc->node);
	rc->status = RC_STATE_DONE;
	rc->error_code = 0;
	spin_unlock_irqrestore(&g_rc_lock, flags);

	complete(&rc->done);
	linyu_rc_put(rc); 
	linyu_rc_put(rc); 

	return true;
}

static int linyu_remote_call_invoke(void *call_buf)
{
	const u32 *hdr = call_buf;
	pid_t pid;
	struct task_struct *task = NULL;
	struct rc_state *rc;
	struct rc_call  *call;
	unsigned long flags;
	int ret;
	int i;

	if (!rc_inited)
		return -ENODEV;
	if (!call_buf)
		return -EINVAL;

	pid = (pid_t)hdr[0];
	if (pid < 1)
		return -EINVAL;

	ret = linyu_rc_prepare_target(pid, &task);
	if (ret)
		return ret;

	rc = kzalloc(sizeof(*rc), GFP_KERNEL);
	if (!rc) { ret = -ENOMEM; goto out_task; }

	call = kzalloc(sizeof(*call), GFP_KERNEL);
	if (!call) { kfree(rc); ret = -ENOMEM; goto out_task; }

	

	call->func_addr = *(u64 *)((u8 *)call_buf + 0x08);
	for (i = 0; i < 8; i++)
		call->args[i] = *(u64 *)((u8 *)call_buf + 0x10 + i * 8);

	rc->call = call;
	rc->call_count = 1;

	ret = linyu_rc_dispatch(task, rc);
	if (ret) {
		linyu_rc_put(rc);
		goto out_task;
	}

	

	{
		long wret;
		unsigned long tmo = msecs_to_jiffies(1000);

		wret = wait_for_completion_killable_timeout(&rc->done, tmo);
		if (wret <= 0) {
			
			spin_lock_irqsave(&g_rc_lock, flags);
			if (rc->status == RC_STATE_PENDING) {
				rc->status = RC_STATE_FAILED;
				rc->error_code = wret ? -EINTR : -ETIMEDOUT;
				list_del_init(&rc->node);
				spin_unlock_irqrestore(&g_rc_lock, flags);
				linyu_rc_put(rc); 
			} else {
				spin_unlock_irqrestore(&g_rc_lock, flags);
			}
			ret = wret ? -EINTR : -ETIMEDOUT;
		} else if (rc->status == RC_STATE_RUNNING ||
			   rc->status == RC_STATE_DONE) {
			
			for (i = 0; i < 8; i++)
				*(u64 *)((u8 *)call_buf + 0x60 + i * 8) = rc->retvals[i];
			
			*(u32 *)((u8 *)call_buf + 0x160) = (u32)rc->error_code;
			*(u32 *)((u8 *)call_buf + 0x164) = (u32)rc->status;
			ret = rc->error_code;
		} else {
			ret = -EIO;
		}
	}

	linyu_rc_put(rc); 
out_task:
	put_task_struct(task);
	return ret;
}

static int linyu_remote_call_batch_invoke(void *batch_buf, void __user *user_calls,
					   void __user *user_results,
					   unsigned long timeout_ms)
{
	const u32 *hdr = batch_buf;
	pid_t pid;
	struct task_struct *task = NULL;
	struct rc_state *rc;
	struct rc_call  *calls;
	int count, i, ret;
	u8 *upayload;

	if (!rc_inited)
		return -ENODEV;

	pid   = (pid_t)hdr[0];
	count = (int)hdr[2];
	if (pid < 1 || count < 1 || count > RC_MAX_BATCH)
		return -EINVAL;

	ret = linyu_rc_prepare_target(pid, &task);
	if (ret)
		return ret;

	rc = kzalloc(sizeof(*rc), GFP_KERNEL);
	if (!rc) { ret = -ENOMEM; goto out_task; }

	calls = kvzalloc(sizeof(*calls) * count, GFP_KERNEL);
	if (!calls) { kfree(rc); ret = -ENOMEM; goto out_task; }

	upayload = kvmalloc((size_t)RC_STRUCT_SIZE * count, GFP_KERNEL);
	if (!upayload) {
		kvfree(calls); kfree(rc); ret = -ENOMEM; goto out_task;
	}

	if (copy_from_user(upayload, user_calls, (size_t)RC_STRUCT_SIZE * count)) {
		ret = -EFAULT;
		goto out_free;
	}

	for (i = 0; i < count; i++) {
		u8 *p = upayload + (size_t)RC_STRUCT_SIZE * i;
		int j;
		calls[i].func_addr = *(u64 *)(p + 0x08);
		for (j = 0; j < 8; j++)
			calls[i].args[j] = *(u64 *)(p + 0x10 + j * 8);
	}

	rc->call = calls;
	rc->call_count = count;
	calls = NULL; 

	ret = linyu_rc_dispatch(task, rc);
	if (ret) {
		linyu_rc_put(rc);
		goto out_free;
	}

	if (timeout_ms == 0)
		timeout_ms = 5000;

	if (!wait_for_completion_killable_timeout(&rc->done, msecs_to_jiffies(timeout_ms))) {
		ret = -ETIMEDOUT;
		if (p_task_work_cancel_func)
			p_task_work_cancel_func(task, linyu_rc_tw_callback);
	} else if (rc->status == RC_STATE_DONE) {
		if (user_results &&
		    copy_to_user(user_results, rc->retvals,
				 (size_t)sizeof(u64) * min(count, 8)))
			ret = -EFAULT;
		else
			ret = 0;
	} else {
		ret = -EIO;
	}

	linyu_rc_put(rc);
out_free:
	kvfree(upayload);
	if (calls)
		kvfree(calls);
out_task:
	put_task_struct(task);
	return ret;
}

int linyu_remote_call_ioctl(unsigned long arg)
{
	char buf[RC_STRUCT_SIZE];
	int ret;

	if (copy_from_user(buf, (void __user *)arg, RC_STRUCT_SIZE))
		return -EFAULT;

	ret = linyu_remote_call_invoke(buf);

	if (copy_to_user((void __user *)arg, buf, RC_STRUCT_SIZE))
		return -EFAULT;

	return ret;
}

int linyu_remote_call_batch_ioctl(unsigned long arg)
{
	struct linyu_remote_call_batch_args a;

	if (copy_from_user(&a, (void __user *)arg, sizeof(a)))
		return -EFAULT;

	return linyu_remote_call_batch_invoke(&a,
					      (void __user *)a.calls,
					      (void __user *)a.results,
					      a.timeout_ms);
}
