#include "linyu.h"
#include <asm/cacheflush.h>

unsigned long g_pte_window;
pte_t *g_pte_window_ptep;
unsigned long g_pte_read_last_pfn = -1UL;

struct pte_cpu_window __percpu *g_cpu_windows;

static struct mm_struct *init_mm_ptr;

static pte_t *linyu_pte_kernel_va_to_ptep(unsigned long va)
{
	pgd_t *pgd;
	p4d_t *p4d;
	pud_t *pud;
	pmd_t *pmd;
	pte_t *ptep;

	if (!init_mm_ptr)
		return NULL;

	pgd = pgd_offset(init_mm_ptr, va);
	if (pgd_none(*pgd) || pgd_bad(*pgd))
		return NULL;

	p4d = p4d_offset(pgd, va);
	if (p4d_none(*p4d) || p4d_bad(*p4d))
		return NULL;

	pud = pud_offset(p4d, va);
	if (pud_none(*pud) || pud_bad(*pud))
		return NULL;

	pmd = pmd_offset(pud, va);
	if (pmd_none(*pmd) || pmd_bad(*pmd))
		return NULL;

	ptep = pte_offset_kernel(pmd, va);
	return ptep;
}

static inline pte_t linyu_pte_make_nc_pte(phys_addr_t pa)
{
	return pfn_pte(__phys_to_pfn(pa & PAGE_MASK),
		       pgprot_noncached(PAGE_KERNEL));
}

static inline void linyu_pte_window_remap(pte_t *ptep, unsigned long vaddr, phys_addr_t pa)
{
	pte_t new_pte = linyu_pte_make_nc_pte(pa);
	WRITE_ONCE(*ptep, new_pte);
	dsb(ishst);
	isb();
	flush_tlb_kernel_range(vaddr, vaddr + PAGE_SIZE);
	isb();
}

static inline void linyu_pte_dc_cvac_range(unsigned long start, size_t len)
{
	unsigned long addr;

	for (addr = start & ~63UL; addr < start + len; addr += 64)
		asm volatile("dc cvac, %0" :: "r"(addr));
	dsb(ish);
}

int linyu_pte_window_init(void)
{
	unsigned long va;
	pte_t *ptep;

	if (g_pte_window)
		return 0;

	init_mm_ptr = (struct mm_struct *)linyu_resolve_symbol("init_mm");
	if (!init_mm_ptr) {
		linyu_err("pte_window: cannot resolve init_mm\n");
		return -ENOENT;
	}

	va = (unsigned long)vmalloc(PAGE_SIZE);
	if (!va) {
		linyu_err("pte_window: vmalloc failed\n");
		return -ENOMEM;
	}
	memset((void *)va, 0, PAGE_SIZE);

	ptep = linyu_pte_kernel_va_to_ptep(va);
	if (!ptep) {
		vfree((void *)va);
		linyu_err("pte_window: cannot find PTE for window\n");
		return -EFAULT;
	}

	g_pte_window = va;
	g_pte_window_ptep = ptep;
	g_pte_read_last_pfn = -1UL;

	linyu_info("pte_window: global window at %lx, ptep=%px\n", va, ptep);
	return 0;
}

int linyu_pte_window_init_percpu(void)
{
	int cpu;
	struct pte_cpu_window *win;

	if (g_cpu_windows)
		return 0;

	if (!init_mm_ptr) {
		init_mm_ptr = (struct mm_struct *)linyu_resolve_symbol("init_mm");
		if (!init_mm_ptr)
			return -ENOENT;
	}

	g_cpu_windows = alloc_percpu(struct pte_cpu_window);
	if (!g_cpu_windows) {
		linyu_err("pte_window: percpu alloc failed\n");
		return -ENOMEM;
	}

	for_each_possible_cpu(cpu) {
		unsigned long va;
		pte_t *ptep;

		win = per_cpu_ptr(g_cpu_windows, cpu);

		va = (unsigned long)vmalloc(PAGE_SIZE);
		if (!va) {
			linyu_err("pte_window: vmalloc failed for cpu %d\n", cpu);
			win->ptep = NULL;
			win->vaddr = 0;
			win->last_pfn = -1UL;
			continue;
		}
		memset((void *)va, 0, PAGE_SIZE);

		ptep = linyu_pte_kernel_va_to_ptep(va);
		if (!ptep) {
			vfree((void *)va);
			win->ptep = NULL;
			win->vaddr = 0;
			win->last_pfn = -1UL;
			continue;
		}

		win->ptep = ptep;
		win->vaddr = va;
		win->last_pfn = -1UL;
	}

	linyu_info("pte_window: percpu windows initialized\n");
	return 0;
}

void linyu_pte_window_cleanup(void)
{
	int cpu;

	if (g_cpu_windows) {
		for_each_possible_cpu(cpu) {
			struct pte_cpu_window *win = per_cpu_ptr(g_cpu_windows, cpu);
			if (win->vaddr) {
				vfree((void *)win->vaddr);
				win->vaddr = 0;
				win->ptep = NULL;
			}
		}
		free_percpu(g_cpu_windows);
		g_cpu_windows = NULL;
	}

	if (g_pte_window) {
		vfree((void *)g_pte_window);
		g_pte_window = 0;
		g_pte_window_ptep = NULL;
	}
}

void linyu_pte_caches_clear(void)
{
	int cpu;

	g_pte_read_last_pfn = -1UL;

	if (g_cpu_windows) {
		for_each_possible_cpu(cpu) {
			struct pte_cpu_window *win = per_cpu_ptr(g_cpu_windows, cpu);
			win->last_pfn = -1UL;
		}
	}
}

int linyu_pte_read_physical(phys_addr_t pa, void *dest, size_t len)
{
	unsigned long offset;

	if (!dest || !len)
		return -EINVAL;
	if (!g_pte_window || !g_pte_window_ptep)
		return -EINVAL;

	offset = pa & ~PAGE_MASK;
	if (offset + len > PAGE_SIZE)
		return -EINVAL;

	if (g_pte_read_last_pfn != (pa >> PAGE_SHIFT)) {
		linyu_pte_window_remap(g_pte_window_ptep, g_pte_window, pa);
		g_pte_read_last_pfn = pa >> PAGE_SHIFT;
	}

	linyu_pte_dc_cvac_range(g_pte_window + offset, len);
	memcpy(dest, (void *)(g_pte_window + offset), len);
	return 0;
}

int linyu_pte_read_nc_fast(phys_addr_t pa, void *dest, size_t len)
{
	struct pte_cpu_window *win;
	unsigned long offset;
	int cpu;

	if (!dest || !len)
		return -EINVAL;

	offset = pa & ~PAGE_MASK;
	if (offset + len > PAGE_SIZE)
		return -EINVAL;

	if (!g_cpu_windows)
		return -EINVAL;

	preempt_disable();
	cpu = smp_processor_id();
	win = per_cpu_ptr(g_cpu_windows, cpu);

	if (!win->ptep || !win->vaddr) {
		preempt_enable();
		return -EINVAL;
	}

	if (win->last_pfn != (pa >> PAGE_SHIFT)) {
		linyu_pte_window_remap(win->ptep, win->vaddr, pa);
		win->last_pfn = pa >> PAGE_SHIFT;
	}

	linyu_pte_dc_cvac_range(win->vaddr + offset, len);
	memcpy(dest, (void *)(win->vaddr + offset), len);

	preempt_enable();
	return 0;
}

int linyu_read_phys_to_user(phys_addr_t pa, void __user *ubuf, size_t len)
{
	struct pte_cpu_window *win;
	unsigned long offset;
	int ret;

	if (!ubuf || !len)
		return -EINVAL;

	offset = pa & ~PAGE_MASK;
	if (offset + len > PAGE_SIZE)
		return -EINVAL;

	if (!g_cpu_windows)
		return -EINVAL;

	preempt_disable();
	win = this_cpu_ptr(g_cpu_windows);

	if (!win->ptep || !win->vaddr) {
		preempt_enable();
		return -EINVAL;
	}

	if (win->last_pfn != (pa >> PAGE_SHIFT)) {
		linyu_pte_window_remap(win->ptep, win->vaddr, pa);
		win->last_pfn = pa >> PAGE_SHIFT;
	}

	linyu_pte_dc_cvac_range(win->vaddr + offset, len);

	ret = copy_to_user(ubuf, (void *)(win->vaddr + offset), len);
	preempt_enable();

	return ret ? -EFAULT : 0;
}

int linyu_convert_wmt_to_pgprot(unsigned int wmt, u64 *out)
{
	const u64 base_normal_wb = 0x68000000000703ULL;
	const u64 base_normal_nc = 0x68000000000707ULL;
	const u64 base_writethru = 0x6800000000070BULL;
	const u64 base_writeback = 0x6800000000070FULL;
	const u64 base_devngnre = 0x68000000000713ULL;

	if (!out)
		return -EINVAL;

	switch (wmt) {
	case 0:
		*out = base_normal_wb;
		return 0;
	case 1:
		*out = base_normal_nc;
		return 0;
	case 2:
		*out = base_writethru;
		return 0;
	case 3:
		return -EINVAL;
	case 4:
		*out = base_writeback;
		return 0;
	case 5:
		*out = base_devngnre;
		return 0;
	default:
		return -EINVAL;
	}
}

void linyu_clean_dcache_area(unsigned long addr, size_t len)
{
	unsigned long line;
	unsigned long end = addr + len;

	for (line = addr & ~63UL; line < end; line += 64)
		asm volatile("dc cvac, %0" :: "r"(line) : "memory");
	dsb(ish);
}

void *linyu_ioremap_prot(phys_addr_t phys, size_t len, unsigned long prot_val)
{
	struct vm_struct *(*p_get_vm_area)(unsigned long, unsigned long,
					   unsigned long, const void *);
	int (*p_ioremap_page_range)(unsigned long addr, unsigned long end,
				    phys_addr_t phys_addr, pgprot_t prot);
	struct vm_struct *area;
	unsigned long offset, aligned_size;
	phys_addr_t aligned_phys;
	pgprot_t prot;

	if (!len)
		return NULL;

	offset = phys & ~PAGE_MASK;
	aligned_phys = phys & PAGE_MASK;
	aligned_size = ALIGN(offset + len, PAGE_SIZE);

	p_get_vm_area = (void *)linyu_resolve_symbol("__get_vm_area_caller");
	p_ioremap_page_range = (void *)linyu_resolve_symbol("ioremap_page_range");
	if (!p_get_vm_area || !p_ioremap_page_range) {
		linyu_warn("ioremap_prot: kernel symbols not resolvable\n");
		return NULL;
	}

	area = p_get_vm_area(aligned_size, VM_IOREMAP,
			     VMALLOC_START, __builtin_return_address(0));
	if (!area)
		return NULL;

	prot = __pgprot(prot_val);
	if (p_ioremap_page_range((unsigned long)area->addr,
				 (unsigned long)area->addr + aligned_size,
				 aligned_phys, prot) < 0) {
		void (*p_free_vm_area)(struct vm_struct *) =
			(void *)linyu_resolve_symbol("free_vm_area");
		if (p_free_vm_area)
			p_free_vm_area(area);
		return NULL;
	}

	return (u8 *)area->addr + offset;
}

void linyu_pte_window_hide_vmalloc(void)
{
	struct list_head *vmap_list;
	struct rb_root *vmap_root;
	struct list_head *pos;

	if (!g_pte_window)
		return;

	vmap_list = (struct list_head *)linyu_resolve_symbol("vmap_area_list");
	vmap_root = (struct rb_root *)linyu_resolve_symbol("vmap_area_root");
	if (!vmap_list || !vmap_root) {
		linyu_warn("hide_vmalloc: vmap symbols not found\n");
		return;
	}

	list_for_each(pos, vmap_list) {
		u8 *va = (u8 *)pos - 24;
		u64 va_start = *(u64 *)(va + 40);
		u64 va_end = *(u64 *)(va + 48);

		if (va_start <= g_pte_window && va_end > g_pte_window) {
			list_del_init(pos);
			rb_erase((struct rb_node *)va, vmap_root);
			linyu_info("hide_vmalloc: dropped window @ %lx\n",
				   (unsigned long)g_pte_window);
			return;
		}
	}
}

int linyu_read_ptem(phys_addr_t pa, void *dest, size_t len)
{
	unsigned long offset;

	if (!dest || !len)
		return -EINVAL;
	if (!g_pte_window || !g_pte_window_ptep)
		return -EINVAL;

	offset = pa & ~PAGE_MASK;
	if (offset + len > PAGE_SIZE)
		return -EINVAL;

	if (g_pte_read_last_pfn != (pa >> PAGE_SHIFT)) {
		linyu_pte_window_remap(g_pte_window_ptep, g_pte_window, pa);
		g_pte_read_last_pfn = pa >> PAGE_SHIFT;
	}

	memcpy(dest, (void *)(g_pte_window + offset), len);
	return 0;
}

int linyu_read_line(phys_addr_t pa, void *dest)
{
	unsigned long offset;

	if (!dest)
		return -EINVAL;
	if (!g_pte_window || !g_pte_window_ptep)
		return -EINVAL;

	offset = pa & ~PAGE_MASK;
	if (offset + 64 > PAGE_SIZE)
		return -EINVAL;

	if (g_pte_read_last_pfn != (pa >> PAGE_SHIFT)) {
		linyu_pte_window_remap(g_pte_window_ptep, g_pte_window, pa);
		g_pte_read_last_pfn = pa >> PAGE_SHIFT;
	}

	asm volatile("dc cvac, %0" :: "r"(g_pte_window + offset));
	dsb(ish);
	memcpy(dest, (void *)(g_pte_window + offset), 64);
	return 0;
}

int linyu_pte_write_physical(phys_addr_t pa, const void *src, size_t len)
{
	unsigned long offset;

	if (!src || !len)
		return -EINVAL;
	if (!g_pte_window || !g_pte_window_ptep)
		return -EINVAL;

	offset = pa & ~PAGE_MASK;
	if (offset + len > PAGE_SIZE)
		return -EINVAL;

	if (g_pte_read_last_pfn != (pa >> PAGE_SHIFT)) {
		linyu_pte_window_remap(g_pte_window_ptep, g_pte_window, pa);
		g_pte_read_last_pfn = pa >> PAGE_SHIFT;
	}

	memcpy((void *)(g_pte_window + offset), src, len);
	linyu_pte_dc_cvac_range(g_pte_window + offset, len);
	return 0;
}
