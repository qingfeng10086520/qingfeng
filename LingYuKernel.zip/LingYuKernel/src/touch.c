#include "linyu.h"
#include "comm.h"
#include <linux/input.h>
#include <linux/input/mt.h>
#include <linux/fdtable.h>
#include <linux/file.h>
#include <linux/poll.h>

#define MAX_TOUCH_SLOTS 10
#define MAX_TOUCH_SLOTS_MTSLOT 6
#define EVENT_POOL_SIZE 1024
#define FOPS_EVENT_BUF_SIZE 24584

static int linyu_touch_upload_event_direct(unsigned int slot, int action, int x, int y);
static int linyu_touch_inject_down(int x, int y);
static int linyu_touch_inject_up(void);
static void linyu_touch_pool_add_event(u32 type, u32 code, s32 value);
static struct input_dev *linyu_touch_find_device(void *unused);
static void linyu_touch_mtslot_send_report(int slot, unsigned int x, unsigned int y, unsigned int is_down);

struct touch_slot_mode1 {
	int x;
	int y;
	int pressure;
	u8  active;
	int tracking_id;
};

struct pool_event {
	u32 type;
	u32 code;
	s32 value;
};

struct event_pool {
	struct pool_event events[EVENT_POOL_SIZE];
	u32 count;
	spinlock_t lock;
};

static DEFINE_MUTEX(g_touch_mode_lock);
static DEFINE_MUTEX(g_touch_lock);
static bool g_touch_initialized;
static int  g_touch_mode;

static bool g_fops_initialized;
static void *g_final_events_fops;
static void *g_read_events_fops;
static DEFINE_MUTEX(g_slot_lock_fops);
static DEFINE_MUTEX(g_hook_lock_fops);

struct fops_slot {
	int  tracking_id;
	int  x;
	int  y;
	u8   active;
	u8   need_report;
	u8   need_up;
};
static struct fops_slot g_fops_slots[MAX_TOUCH_SLOTS];
static struct input_dev *g_target_dev_fops;
static void *g_target_file_fops;
static void *g_dev_fops;
static void *g_mydev_fops;
static void *g_myclient_fops;
static bool  g_need_wakeup_fops;

static struct files_struct *(*g_get_files_struct_ptr_fops)(struct task_struct *);
static void (*g_put_files_struct_ptr_fops)(struct files_struct *);

static struct file_operations g_hooked_fops_fops;
static const struct file_operations *g_original_fops_fops;
static ssize_t (*g_old_read_fops)(struct file *, char __user *, size_t, loff_t *);
static __poll_t (*g_old_poll_fops)(struct file *, struct poll_table_struct *);

static void *linyu_get_touch_device_fops_cached_dev;
static void *linyu_input_dev_to_evdev_fops_evdev_handler_ptr;
static void *linyu_get_touch_device_fops_input_dev_list;
static void *linyu_get_touch_device_fops_input_mutex;
static int   g_persistent_current_slot_fops;
static bool  g_is_first_down_fops;

static ssize_t linyu_hook_read_fops(struct file *file, char __user *buf,
				     size_t count, loff_t *ppos);
static __poll_t linyu_hook_poll_fops(struct file *file,
				      struct poll_table_struct *wait);

static struct files_struct *linyu_get_files_struct_fops(struct task_struct *task)
{
	struct files_struct *files;

	task_lock(task);
	files = task->files;
	if (files)
		atomic_inc(&files->count);
	task_unlock(task);
	return files;
}

static void (*my_input_handle_event)(struct input_dev *, unsigned int,
				     unsigned int, int);
static struct event_pool *g_pool;
static struct touch_slot_mode1 g_touch_slots[MAX_TOUCH_SLOTS];

static struct input_dev *g_touch_dev_direct;
static DEFINE_MUTEX(g_touch_lock_direct);
static bool g_fallback_used_direct __maybe_unused;
static bool g_iter_funcs_inited_direct;

struct direct_slot {
	u8  active;
	int tracking_id;
};
static struct direct_slot g_direct_slots[MAX_TOUCH_SLOTS];

static void (*fn_class_dev_iter_init_direct)(void *, void *, void *, void *);
static void *(*fn_class_dev_iter_next_direct)(void *);
static void (*fn_class_dev_iter_exit_direct)(void *);
static void *g_input_class_ptr;

static struct input_dev *g_mtslot_dev;
static bool  g_mtslot_ready;
static int   g_mtslot_slot_ids[MAX_TOUCH_SLOTS_MTSLOT];
static bool  g_mtslot_has_pressure;
static bool  g_mtslot_has_touch_major;
static bool  g_mtslot_has_width_major;

struct inject_ctx {
	struct input_dev  *dev;
	unsigned long      max_slots;
	unsigned long     *slot_bitmap;
	int                cur_slot;
	int                next_id;
	int                state;   
	atomic_t           active_count;
	spinlock_t         lock;
	struct completion   done;
};
static struct inject_ctx g_touch_inject_ctx;
static bool g_inject_ctx_inited;

static bool linyu_touch_is_device(struct input_dev *dev)
{
	if (!dev) return false;
	if (!test_bit(EV_ABS, dev->evbit)) return false;
	if (!test_bit(ABS_MT_POSITION_X, dev->absbit)) return false;
	if (!test_bit(ABS_MT_POSITION_Y, dev->absbit)) return false;
	return true;
}

static int linyu_touch_match_device(struct device *dev, const void *data)
{
	struct input_dev *idev = to_input_dev(dev);
	return linyu_touch_is_device(idev) ? 1 : 0;
}

static struct input_dev *linyu_touch_find_device(void *unused)
{
	struct device *dev;
	struct class *cls;

	if (g_touch_dev_direct)
		return g_touch_dev_direct;

	
	if (g_iter_funcs_inited_direct && fn_class_dev_iter_init_direct &&
	    fn_class_dev_iter_next_direct && fn_class_dev_iter_exit_direct &&
	    g_input_class_ptr) {
		char iter_buf[128];
		struct device *d;

		fn_class_dev_iter_init_direct(iter_buf, g_input_class_ptr, NULL, NULL);
		while ((d = fn_class_dev_iter_next_direct(iter_buf)) != NULL) {
			struct input_dev *idev = to_input_dev(d);
			if (linyu_touch_is_device(idev)) {
				g_touch_dev_direct = idev;
				fn_class_dev_iter_exit_direct(iter_buf);
				return idev;
			}
		}
		fn_class_dev_iter_exit_direct(iter_buf);
	}

	
	cls = (struct class *)linyu_resolve_symbol("input_class");
	if (!cls) return NULL;

	dev = class_find_device(cls, NULL, NULL, linyu_touch_match_device);
	if (dev) {
		g_touch_dev_direct = to_input_dev(dev);
		return g_touch_dev_direct;
	}
	return NULL;
}

static void linyu_init_fingers_fops(void)
{
	int i;

	if (g_fops_initialized)
		return;

	if (!g_final_events_fops) {
		g_final_events_fops = kvmalloc(FOPS_EVENT_BUF_SIZE, GFP_KERNEL);
		if (!g_final_events_fops) {
			linyu_warn("touch: fops final_events alloc failed\n");
			return;
		}
	}
	if (!g_read_events_fops) {
		g_read_events_fops = kvmalloc(FOPS_EVENT_BUF_SIZE, GFP_KERNEL);
		if (!g_read_events_fops) {
			linyu_warn("touch: fops read_events alloc failed\n");
			kvfree(g_final_events_fops);
			g_final_events_fops = NULL;
			return;
		}
	}

	for (i = 0; i < MAX_TOUCH_SLOTS; i++) {
		g_fops_slots[i].tracking_id = -1;
		g_fops_slots[i].x = 0;
		g_fops_slots[i].y = 0;
		g_fops_slots[i].active = 0;
		g_fops_slots[i].need_report = 0;
		g_fops_slots[i].need_up = 0;
	}

	g_fops_initialized = true;
	linyu_info("touch: mode 0 (fops) buffers ready\n");
}

static int linyu_hook_fops_fops(int target_pid, unsigned int fd_idx)
{
	struct pid *vpid;
	struct task_struct *task;
	struct file *target_file = NULL;
	struct files_struct *files;
	struct fdtable *fdt;
	const struct file_operations *orig_fops;
	void *client, *evdev, *handle_dev;

	vpid = find_get_pid(target_pid);
	if (!vpid) {
		linyu_warn("touch: fops hook - pid not found\n");
		return -ESRCH;
	}
	task = get_pid_task(vpid, PIDTYPE_PID);
	put_pid(vpid);
	if (!task) {
		linyu_warn("touch: fops hook - task not found\n");
		return -ESRCH;
	}

	
	files = g_get_files_struct_ptr_fops(task);
	if (files) {
		spin_lock(&files->file_lock);
		fdt = files_fdtable(files);
		if (fdt && fd_idx < fdt->max_fds) {
			target_file = fdt->fd[fd_idx];
			if (target_file)
				get_file(target_file);
		}
		spin_unlock(&files->file_lock);
		if (g_put_files_struct_ptr_fops)
			g_put_files_struct_ptr_fops(files);
	}

	put_task_struct(task);
	g_target_file_fops = (void *)target_file;

	if (!target_file) {
		linyu_warn("touch: fops hook - file not found\n");
		return -ENOENT;
	}

	

	client = *(void **)((char *)target_file + 216);  
	g_myclient_fops = client;
	if (!client) {
		linyu_warn("touch: fops hook - no client\n");
		goto fail;
	}

	evdev = *(void **)((char *)client + 48);  
	g_mydev_fops = evdev;
	if (!evdev) {
		linyu_warn("touch: fops hook - no evdev\n");
		goto fail;
	}

	handle_dev = *(void **)((char *)evdev + 32);  
	g_dev_fops = handle_dev;
	if (!handle_dev) {
		linyu_warn("touch: fops hook - no handle dev\n");
		goto fail;
	}

	
	orig_fops = (const struct file_operations *)
		    *(void **)((char *)target_file + 192);  
	g_original_fops_fops = orig_fops;
	if (!orig_fops || !orig_fops->read || !orig_fops->poll) {
		linyu_warn("touch: fops hook - invalid fops\n");
		goto fail;
	}

	memcpy(&g_hooked_fops_fops, orig_fops, sizeof(g_hooked_fops_fops));
	g_old_read_fops = orig_fops->read;
	g_old_poll_fops = orig_fops->poll;
	g_hooked_fops_fops.read = linyu_hook_read_fops;
	g_hooked_fops_fops.poll = linyu_hook_poll_fops;

	
	*(const struct file_operations **)((char *)target_file + 192) =
		&g_hooked_fops_fops;

	linyu_info("touch: fops hook installed on pid %d fd %d\n",
		   target_pid, fd_idx);
	return 0;

fail:
	fput(target_file);
	g_target_file_fops = NULL;
	g_dev_fops = NULL;
	g_mydev_fops = NULL;
	g_myclient_fops = NULL;
	return -ENOENT;
}

static int linyu_ensure_hook_installed_fops(void *unused)
{
	struct input_dev *idev;
	struct list_head *dev_list, *pos;
	struct mutex *input_mutex_ptr;
	void *evdev_handler_ptr;
	void *h_list_head;
	struct list_head *hpos;
	void *handle, *evdev;
	unsigned int evdev_minor;
	int ss_pid;
	struct pid *vpid;
	struct task_struct *task;
	struct files_struct *files;
	struct fdtable *fdt;
	unsigned int i;
	int ret;

	mutex_lock(&g_hook_lock_fops);
	if (g_target_file_fops) {
		mutex_unlock(&g_hook_lock_fops);
		return 0;
	}

	
	if (!g_get_files_struct_ptr_fops) {
		g_get_files_struct_ptr_fops = (void *)linyu_resolve_symbol(
			"get_files_struct");
		if (!g_get_files_struct_ptr_fops) {
			linyu_info("touch: using fallback get_files_struct\n");
			g_get_files_struct_ptr_fops = linyu_get_files_struct_fops;
		}
	}
	if (!g_put_files_struct_ptr_fops) {
		g_put_files_struct_ptr_fops = (void *)linyu_resolve_symbol(
			"put_files_struct");
		if (!g_put_files_struct_ptr_fops) {
			linyu_warn("touch: put_files_struct not found\n");
			mutex_unlock(&g_hook_lock_fops);
			return -ENOENT;
		}
	}
	mutex_unlock(&g_hook_lock_fops);

	
	if (!mutex_trylock(&g_hook_lock_fops)) {
		linyu_warn("touch: fops hook lock busy\n");
		return -EBUSY;
	}
	if (g_target_file_fops) {
		mutex_unlock(&g_hook_lock_fops);
		return 0;
	}

	
	idev = (struct input_dev *)linyu_get_touch_device_fops_cached_dev;
	if (!idev) {
		
		if (!linyu_get_touch_device_fops_input_dev_list)
			linyu_get_touch_device_fops_input_dev_list =
				(void *)linyu_resolve_symbol("input_dev_list");
		if (!linyu_get_touch_device_fops_input_mutex)
			linyu_get_touch_device_fops_input_mutex =
				(void *)linyu_resolve_symbol("input_mutex");

		dev_list = (struct list_head *)linyu_get_touch_device_fops_input_dev_list;
		input_mutex_ptr = (struct mutex *)linyu_get_touch_device_fops_input_mutex;

		if (!dev_list || !input_mutex_ptr) {
			mutex_unlock(&g_hook_lock_fops);
			return -ENODEV;
		}

		if (!mutex_trylock(input_mutex_ptr)) {
			mutex_unlock(&g_hook_lock_fops);
			return -EBUSY;
		}

		
		list_for_each(pos, dev_list) {
			struct input_dev *d = container_of(pos, struct input_dev,
							    node);
			if (linyu_touch_is_device(d)) {
				linyu_get_touch_device_fops_cached_dev = d;
				idev = d;
				break;
			}
		}
		mutex_unlock(input_mutex_ptr);

		if (!idev) {
			mutex_unlock(&g_hook_lock_fops);
			return -ENODEV;
		}
	}

	
	if (!linyu_input_dev_to_evdev_fops_evdev_handler_ptr) {
		linyu_input_dev_to_evdev_fops_evdev_handler_ptr =
			(void *)linyu_resolve_symbol("evdev_handler");
		if (!linyu_input_dev_to_evdev_fops_evdev_handler_ptr) {
			linyu_warn("touch: evdev_handler not found\n");
			mutex_unlock(&g_hook_lock_fops);
			return -ENOENT;
		}
	}

	evdev_handler_ptr = linyu_input_dev_to_evdev_fops_evdev_handler_ptr;
	evdev = NULL;
	evdev_minor = 0;

	

	if (!mutex_trylock((struct mutex *)((char *)idev + 520))) {
		mutex_unlock(&g_hook_lock_fops);
		return -ENOENT;
	}

	h_list_head = (char *)idev + 1512;
	list_for_each(hpos, (struct list_head *)h_list_head) {
		
		handle = (char *)hpos - 40;
		
		if (*(void **)((char *)hpos - 8) == evdev_handler_ptr) {
			
			evdev = *(void **)handle;
			if (evdev) {
				
				evdev_minor = *(unsigned int *)((char *)evdev + 1232) & 0xFFFFF;
			}
			break;
		}
	}
	mutex_unlock((struct mutex *)((char *)idev + 520));

	if (!evdev || evdev_minor <= 63) {
		mutex_unlock(&g_hook_lock_fops);
		return evdev ? (int)(evdev_minor - 64) : -ENOENT;
	}

	
	ss_pid = linyu_find_process_by_name("system_server");
	if (ss_pid <= 0) {
		mutex_unlock(&g_hook_lock_fops);
		return -ESRCH;
	}

	vpid = find_get_pid(ss_pid);
	task = vpid ? get_pid_task(vpid, PIDTYPE_PID) : NULL;
	if (vpid) put_pid(vpid);
	if (!task) {
		mutex_unlock(&g_hook_lock_fops);
		return -ESRCH;
	}

	files = g_get_files_struct_ptr_fops(task);
	put_task_struct(task);

	if (!files) {
		mutex_unlock(&g_hook_lock_fops);
		return -ENOENT;
	}

	

	ret = -ENOENT;
	rcu_read_lock();
	fdt = files_fdtable(files);
	for (i = 0; fdt && i < fdt->max_fds; i++) {
		struct file *f = fdt->fd[i];
		struct inode *ino;
		if (!f) continue;
		ino = file_inode(f);
		if (!ino) continue;
		if (!S_ISCHR(ino->i_mode)) continue;
		
		if (MINOR(ino->i_rdev) == evdev_minor &&
		    MAJOR(ino->i_rdev) == 13) {
			ret = (int)i;
			break;
		}
	}
	rcu_read_unlock();

	if (g_put_files_struct_ptr_fops)
		g_put_files_struct_ptr_fops(files);

	if (ret < 0) {
		mutex_unlock(&g_hook_lock_fops);
		return ret;
	}

	
	ret = linyu_hook_fops_fops(ss_pid, (unsigned int)ret);
	if (ret < 0) {
		linyu_warn("touch: fops hook failed: %d\n", ret);
		mutex_unlock(&g_hook_lock_fops);
		return ret;
	}

	linyu_info("touch: fops hook installed for pid %d\n", ss_pid);
	mutex_unlock(&g_hook_lock_fops);
	return 0;
}

static void linyu_touch_down_internal_fops(unsigned int slot, int x, int y)
{
	mutex_lock(&g_slot_lock_fops);
	if (slot >= MAX_TOUCH_SLOTS) {
		mutex_unlock(&g_slot_lock_fops);
		return;
	}

	if (!g_fops_slots[slot].active || g_fops_slots[slot].tracking_id < 0)
		g_fops_slots[slot].tracking_id = slot + 10000;

	g_fops_slots[slot].active = 1;
	g_fops_slots[slot].x = x;
	g_fops_slots[slot].y = y;
	g_fops_slots[slot].need_report = 1;
	g_fops_slots[slot].need_up = 1;

	mutex_unlock(&g_slot_lock_fops);

	
	if (g_dev_fops && g_mydev_fops) {
		if (mutex_trylock((struct mutex *)((char *)g_dev_fops + 520))) {
			g_need_wakeup_fops = true;
			if (g_myclient_fops)
				wake_up_interruptible((wait_queue_head_t *)
					((char *)g_myclient_fops + 16));
			mutex_unlock((struct mutex *)((char *)g_dev_fops + 520));
		}
	}
}

static void linyu_touch_fops_emit_event(void *buf, u64 sec, u64 usec,
			     u16 type, u16 code, s32 value)
{
	u32 *pcnt = (u32 *)((char *)buf + 24576);
	u32 idx = *pcnt;
	char *ev;

	if (idx >= 1024)
		return;

	ev = (char *)buf + 24 * idx;
	*(u64 *)(ev + 0)  = sec;
	*(u64 *)(ev + 8)  = usec;
	*(u16 *)(ev + 16) = type;
	*(u16 *)(ev + 18) = code;
	*(s32 *)(ev + 20) = value;
	*pcnt = idx + 1;
}

static ssize_t linyu_hook_read_fops(struct file *file, char __user *buf,
				     size_t count, loff_t *ppos)
{
	ssize_t orig_ret;
	size_t orig_count;
	int i;
	u64 sec, usec;
	bool any_need = false;
	u32 final_count;
	size_t final_bytes;
	bool has_pressure;

	if (!file || !buf) {
		linyu_warn("touch: hook_read bad args\n");
		return -EINVAL;
	}

	
	if (!g_dev_fops || !g_myclient_fops || !g_mydev_fops) {
		void *client = *(void **)((char *)file + 216);
		if (client) {
			void *ev = *(void **)((char *)client + 48);
			g_myclient_fops = client;
			if (ev) {
				void *hdev = *(void **)((char *)ev + 32);
				g_mydev_fops = ev;
				if (hdev)
					g_dev_fops = hdev;
				else
					return -EINVAL;
			} else {
				return -EINVAL;
			}
		} else {
			return -EINVAL;
		}
	}

	mutex_lock(&g_slot_lock_fops);
	if (!g_read_events_fops || !g_final_events_fops) {
		mutex_unlock(&g_slot_lock_fops);
		if (!g_old_read_fops)
			return -EIO;
		return g_old_read_fops(file, buf, count, ppos);
	}

	
	for (i = 0; i < MAX_TOUCH_SLOTS; i++) {
		if (g_fops_slots[i].need_up) {
			any_need = true;
			break;
		}
	}

	
	orig_ret = g_old_read_fops(file, buf, count, ppos);

	if (!any_need && orig_ret <= 0) {
		mutex_unlock(&g_slot_lock_fops);
		return orig_ret;
	}

	orig_count = (orig_ret > 0) ? (size_t)orig_ret / 24 : 0;
	if (orig_count > 1024) {
		linyu_warn("touch: too many events %zu\n", orig_count);
		mutex_unlock(&g_slot_lock_fops);
		return orig_ret;
	}

	
	memset(g_read_events_fops, 0, FOPS_EVENT_BUF_SIZE);
	memset(g_final_events_fops, 0, FOPS_EVENT_BUF_SIZE);

	
	if (orig_ret > 0) {
		if (copy_from_user(g_read_events_fops, buf, orig_ret)) {
			linyu_warn("touch: copy_from_user failed in read hook\n");
			mutex_unlock(&g_slot_lock_fops);
			return orig_ret;
		}
	}

	
	sec = ktime_get_real_seconds();
	usec = ktime_get_ns() / 1000;

	
	for (i = 0; i < (int)orig_count; i++) {
		char *ev = (char *)g_read_events_fops + 24 * i;
		u16 type = *(u16 *)(ev + 16);
		u16 code = *(u16 *)(ev + 18);
		s32 value = *(s32 *)(ev + 20);

		if (type == EV_ABS) {
			if (code == ABS_MT_SLOT) {
				if (value >= 0 && value < MAX_TOUCH_SLOTS)
					g_persistent_current_slot_fops = value;
			} else if (g_persistent_current_slot_fops >= 0) {
				int s = g_persistent_current_slot_fops;
				
				g_fops_slots[s].need_report = 1;
				if (code == ABS_MT_TRACKING_ID) {
					if (value == -1) {
						g_fops_slots[s].active = 0;
						g_fops_slots[s].tracking_id = -1;
					} else {
						g_fops_slots[s].active = 1;
						g_fops_slots[s].tracking_id = value;
						g_fops_slots[s].need_up = 0;
					}
				} else if (g_fops_slots[s].active) {
					if (code == ABS_MT_POSITION_Y)
						g_fops_slots[s].y = value;
					else if (code == ABS_MT_POSITION_X)
						g_fops_slots[s].x = value;
				}
			}
		}
	}

	
	has_pressure = g_dev_fops &&
		       (*(u64 *)((char *)g_dev_fops + 88) & 0x400) != 0;

	
	if (any_need && !g_is_first_down_fops) {
		if (has_pressure) {
			linyu_touch_fops_emit_event(g_final_events_fops, sec, usec / 1000,
					EV_KEY, BTN_TOUCH, 1);
			linyu_touch_fops_emit_event(g_final_events_fops, sec, usec / 1000,
					EV_KEY, BTN_TOOL_FINGER, 1);
		}
		g_is_first_down_fops = true;
	}

	
	for (i = 0; i < MAX_TOUCH_SLOTS; i++) {
		if (!g_fops_slots[i].need_up)
			continue;

		
		linyu_touch_fops_emit_event(g_final_events_fops, sec, usec / 1000,
				EV_ABS, ABS_MT_SLOT, i);

		if (g_fops_slots[i].active) {
			
			linyu_touch_fops_emit_event(g_final_events_fops, sec, usec / 1000,
					EV_ABS, ABS_MT_TRACKING_ID,
					g_fops_slots[i].tracking_id);
			linyu_touch_fops_emit_event(g_final_events_fops, sec, usec / 1000,
					EV_ABS, ABS_MT_POSITION_X,
					g_fops_slots[i].x);
			linyu_touch_fops_emit_event(g_final_events_fops, sec, usec / 1000,
					EV_ABS, ABS_MT_POSITION_Y,
					g_fops_slots[i].y);
			if (has_pressure)
				linyu_touch_fops_emit_event(g_final_events_fops, sec,
						usec / 1000, EV_ABS,
						ABS_MT_PRESSURE, 50);
			
			linyu_touch_fops_emit_event(g_final_events_fops, sec, usec / 1000,
					EV_ABS, ABS_MT_TOUCH_MAJOR, 8);
		} else {
			
			linyu_touch_fops_emit_event(g_final_events_fops, sec, usec / 1000,
					EV_ABS, ABS_MT_TRACKING_ID, -1);
			if (has_pressure)
				linyu_touch_fops_emit_event(g_final_events_fops, sec,
						usec / 1000, EV_ABS,
						ABS_MT_PRESSURE, 0);
			linyu_touch_fops_emit_event(g_final_events_fops, sec, usec / 1000,
					EV_ABS, ABS_MT_TOUCH_MAJOR, 0);
		}
		g_fops_slots[i].need_up = 0;
	}

	
	{
		bool all_up = true;
		for (i = 0; i < MAX_TOUCH_SLOTS; i++) {
			if (g_fops_slots[i].active) {
				all_up = false;
				break;
			}
		}
		if (all_up && g_is_first_down_fops) {
			g_is_first_down_fops = false;
		}
	}

	
	linyu_touch_fops_emit_event(g_final_events_fops, sec, usec / 1000,
			EV_SYN, SYN_REPORT, 0);

	
	linyu_init_fingers_fops();

	
	final_count = *(u32 *)((char *)g_final_events_fops + 24576);
	final_bytes = 24 * (size_t)final_count;
	if (final_count > 0 && final_bytes <= count) {
		if (copy_to_user(buf, g_final_events_fops, final_bytes)) {
			linyu_warn("touch: copy_to_user failed in read hook\n");
			mutex_unlock(&g_slot_lock_fops);
			return orig_ret;
		}
		mutex_unlock(&g_slot_lock_fops);
		return (ssize_t)final_bytes;
	}

	mutex_unlock(&g_slot_lock_fops);
	return orig_ret;
}

static __poll_t linyu_hook_poll_fops(struct file *file,
				      struct poll_table_struct *wait)
{
	__poll_t mask;

	if (g_need_wakeup_fops) {
		g_need_wakeup_fops = false;
		return POLLIN | POLLRDNORM;
	}

	if (!g_old_poll_fops)
		return 0;

	mask = g_old_poll_fops(file, wait);

	
	if (g_need_wakeup_fops) {
		g_need_wakeup_fops = false;
		mask |= POLLIN | POLLRDNORM;
	}

	return mask;
}

static void linyu_touch_pool_add_event(u32 type, u32 code, s32 value)
{
	u32 idx;

	if (!g_pool)
		return;

	idx = g_pool->count;
	if (idx < EVENT_POOL_SIZE) {
		g_pool->events[idx].type = type;
		g_pool->events[idx].code = code;
		g_pool->events[idx].value = value;
		g_pool->count = idx + 1;
	}
}

static void linyu_touch_pool_flush(struct input_dev *dev)
{
	struct pool_event *events;
	unsigned long flags;
	u32 count, i;

	if (!dev || !g_pool || !my_input_handle_event)
		return;

	spin_lock_irqsave(&g_pool->lock, flags);
	count = g_pool->count;
	if (!count) {
		spin_unlock_irqrestore(&g_pool->lock, flags);
		return;
	}

	events = kmemdup(g_pool->events, sizeof(*events) * count, GFP_ATOMIC);
	if (events)
		g_pool->count = 0;
	spin_unlock_irqrestore(&g_pool->lock, flags);

	if (!events)
		return;

	for (i = 0; i < count; i++)
		my_input_handle_event(dev, events[i].type, events[i].code,
				      events[i].value);
	kfree(events);
}

static void linyu_touch_mtslot_send_report(int slot, unsigned int x, unsigned int y, unsigned int is_down)
{
	struct input_dev *dev = g_mtslot_dev;
	struct input_mt *mt;
	int num_active = 0;
	unsigned long flags;
	int i, saved_slot;

	if (!dev)
		return;

	mt = dev->mt;
	if (!mt)
		return;

	flags = arch_local_irq_save();

	
	saved_slot = mt->slot;
	mt->trkid = 10;

	input_event(dev, EV_ABS, ABS_MT_SLOT, slot + 4);
	input_mt_report_slot_state(dev, 0, is_down);

	if (is_down) {
		input_event(dev, EV_ABS, ABS_MT_POSITION_X, x);
		input_event(dev, EV_ABS, ABS_MT_POSITION_Y, y);
		if (g_mtslot_has_pressure)
			input_event(dev, EV_ABS, ABS_MT_PRESSURE, 10);
		if (g_mtslot_has_touch_major)
			input_event(dev, EV_ABS, ABS_MT_TOUCH_MAJOR, 10);
		if (g_mtslot_has_width_major)
			input_event(dev, EV_ABS, ABS_MT_WIDTH_MAJOR, 60);
	}

	
	mt->trkid = 4;
	input_event(dev, EV_ABS, ABS_MT_SLOT, saved_slot);

	
	for (i = 0; i < MAX_TOUCH_SLOTS_MTSLOT; i++) {
		if (g_mtslot_slot_ids[i] != -1)
			num_active++;
	}

	input_event(dev, EV_KEY, BTN_TOUCH, num_active > 0);
	input_event(dev, EV_KEY, BTN_TOOL_FINGER, num_active == 1);
	input_event(dev, EV_KEY, BTN_TOOL_DOUBLETAP, num_active > 1);
	input_sync(dev);

	arch_local_irq_restore(flags);
}

static int linyu_touch_init_mode_locked(int mode)
{
	int ret = 0;
	int i;

	switch (mode) {
	case 0: 
		linyu_init_fingers_fops();
		if (!g_fops_initialized)
			ret = -ENOMEM;
		break;

	case 1: 
		if (!my_input_handle_event)
			my_input_handle_event = (void *)linyu_resolve_symbol(
				"input_handle_event");
		if (!my_input_handle_event) {
			linyu_warn("touch: input_handle_event not found\n");
			ret = -ENOENT;
			break;
		}

		g_pool = kvmalloc(sizeof(*g_pool), GFP_KERNEL);
		if (!g_pool) {
			ret = -ENOMEM;
			break;
		}
		g_pool->count = 0;
		spin_lock_init(&g_pool->lock);

		
		mutex_lock(&g_touch_lock);
		for (i = 0; i < MAX_TOUCH_SLOTS; i++) {
			g_touch_slots[i].x = 0;
			g_touch_slots[i].y = 0;
			g_touch_slots[i].pressure = 0;
			g_touch_slots[i].active = 0;
			g_touch_slots[i].tracking_id = i + 0xFFFFFFFF;
		}
		mutex_unlock(&g_touch_lock);
		linyu_info("touch: mode 1 (kprobe+pool) ready\n");
		break;

	case 2: 
		mutex_lock(&g_touch_lock_direct);
		g_touch_dev_direct = NULL;
		for (i = 0; i < MAX_TOUCH_SLOTS; i++) {
			g_direct_slots[i].active = 0;
			g_direct_slots[i].tracking_id = -1;
		}
		mutex_unlock(&g_touch_lock_direct);
		ret = 0;
		break;

	case 3: 
		if (g_mtslot_ready)
			break;
		
		if (!g_mtslot_dev) {
			g_mtslot_dev = (struct input_dev *)linyu_resolve_symbol(
				"input_dev_pointers");
			if (!g_mtslot_dev) {
				
				g_mtslot_dev = linyu_touch_find_device(NULL);
			}
		}
		if (!g_mtslot_dev) {
			ret = -ENODEV;
			break;
		}

		
		g_mtslot_has_pressure = test_bit(ABS_MT_PRESSURE, g_mtslot_dev->absbit);
		g_mtslot_has_touch_major = test_bit(ABS_MT_TOUCH_MAJOR, g_mtslot_dev->absbit);
		g_mtslot_has_width_major = test_bit(ABS_MT_WIDTH_MAJOR, g_mtslot_dev->absbit);

		for (i = 0; i < MAX_TOUCH_SLOTS_MTSLOT; i++)
			g_mtslot_slot_ids[i] = -1;

		g_mtslot_ready = true;
		linyu_info("touch: mode 3 (mtslot) ready\n");
		break;

	case 4: 
		if (g_inject_ctx_inited)
			break;
		memset(&g_touch_inject_ctx, 0, sizeof(g_touch_inject_ctx));
		g_touch_inject_ctx.dev = NULL;
		g_touch_inject_ctx.cur_slot = -1;
		g_touch_inject_ctx.state = 0;
		atomic_set(&g_touch_inject_ctx.active_count, 0);
		spin_lock_init(&g_touch_inject_ctx.lock);
		init_completion(&g_touch_inject_ctx.done);
		g_inject_ctx_inited = true;
		linyu_info("touch: mode 4 (inject) ready\n");
		break;

	default:
		ret = -EINVAL;
		break;
	}
	return ret;
}

static void linyu_touch_cleanup_mode_locked(int mode)
{
	int i;

	switch (mode) {
	case 0:
		if (g_target_file_fops) {
			struct file *target_file = (struct file *)g_target_file_fops;
			if (g_original_fops_fops)
				*(const struct file_operations **)((char *)target_file + 192) =
					g_original_fops_fops;
			fput(target_file);
		}
		kvfree(g_final_events_fops);
		kvfree(g_read_events_fops);
		g_final_events_fops = NULL;
		g_read_events_fops  = NULL;
		g_fops_initialized = false;
		g_target_file_fops = NULL;
		g_target_dev_fops = NULL;
		g_dev_fops = NULL;
		g_mydev_fops = NULL;
		g_myclient_fops = NULL;
		g_original_fops_fops = NULL;
		g_old_read_fops = NULL;
		g_old_poll_fops = NULL;
		break;

	case 1:
		if (g_pool) {
			kvfree(g_pool);
			g_pool = NULL;
		}
		break;

	case 2:
		mutex_lock(&g_touch_lock_direct);
		if (g_touch_dev_direct) {
			for (i = 0; i < MAX_TOUCH_SLOTS; i++) {
				if (g_direct_slots[i].active) {
					input_event(g_touch_dev_direct, EV_ABS,
						    ABS_MT_SLOT, i);
					input_event(g_touch_dev_direct, EV_ABS,
						    ABS_MT_TRACKING_ID, -1);
					g_direct_slots[i].active = 0;
				}
			}
			input_sync(g_touch_dev_direct);
			g_touch_dev_direct = NULL;
		}
		mutex_unlock(&g_touch_lock_direct);
		break;

	case 3:
		if (g_mtslot_dev && g_mtslot_ready) {
			for (i = 0; i < MAX_TOUCH_SLOTS_MTSLOT; i++) {
				if (g_mtslot_slot_ids[i] != -1) {
					linyu_touch_mtslot_send_report(i, 0, 0, 0);
					g_mtslot_slot_ids[i] = -1;
				}
			}
		}
		g_mtslot_ready = false;
		break;

	case 4:
		g_inject_ctx_inited = false;
		break;
	}
}

void linyu_touch_cleanup(void)
{
	mutex_lock(&g_touch_mode_lock);
	if (g_touch_initialized) {
		linyu_touch_cleanup_mode_locked(g_touch_mode);
		g_touch_initialized = false;
	}
	mutex_unlock(&g_touch_mode_lock);
}

static int linyu_touch_down(unsigned int slot, int x, int y)
{
	int ret;
	unsigned long flags;
	struct input_dev *dev;

	mutex_lock(&g_touch_mode_lock);
	if (!g_touch_initialized) {
		ret = linyu_touch_init_mode_locked(g_touch_mode);
		if (ret) {
			mutex_unlock(&g_touch_mode_lock);
			return ret;
		}
		g_touch_initialized = true;
	}

	switch (g_touch_mode) {
	case 0: 
		if (slot >= MAX_TOUCH_SLOTS) {
			linyu_warn("touch: slot %d out of range\n", slot);
			ret = -EINVAL;
			break;
		}
		if (!g_target_file_fops) {
			ret = linyu_ensure_hook_installed_fops(NULL);
			if (ret < 0)
				break;
		}
		linyu_touch_down_internal_fops(slot, x, y);
		ret = 0;
		break;

	case 1: 
		if (slot >= MAX_TOUCH_SLOTS) {
			linyu_warn("touch: slot %d out of range\n", slot);
			ret = -EINVAL;
			break;
		}
		dev = linyu_touch_find_device(NULL);
		if (!dev) {
			linyu_warn("touch: no touch device\n");
			ret = -ENODEV;
			break;
		}
		mutex_lock(&g_touch_lock);
		g_touch_slots[slot].tracking_id = slot + 10000;
		g_touch_slots[slot].x = x;
		g_touch_slots[slot].y = y;
		g_touch_slots[slot].active = 1;
		mutex_unlock(&g_touch_lock);

		
		flags = 0;
		spin_lock_irqsave(&g_pool->lock, flags);
		if (my_input_handle_event) {
			linyu_touch_pool_add_event(EV_ABS, ABS_MT_SLOT, slot);
			linyu_touch_pool_add_event(EV_ABS, ABS_MT_TRACKING_ID, slot + 10000);
			linyu_touch_pool_add_event(EV_ABS, ABS_MT_POSITION_X, x);
			linyu_touch_pool_add_event(EV_ABS, ABS_MT_POSITION_Y, y);
			linyu_touch_pool_add_event(EV_ABS, ABS_MT_PRESSURE, 0);
			linyu_touch_pool_add_event(EV_SYN, SYN_REPORT, 0);
		}
		spin_unlock_irqrestore(&g_pool->lock, flags);
		linyu_touch_pool_flush(dev);
		ret = 0;
		break;

	case 2: 
		ret = linyu_touch_upload_event_direct(slot, 1, x, y);
		break;

	case 3: 
		if (!g_mtslot_ready) {
			ret = -ENODEV;
			break;
		}
		if (slot > 5) {
			ret = -EINVAL;
			break;
		}
		if (g_mtslot_slot_ids[slot] == -1) {
			g_mtslot_slot_ids[slot] = slot + 40000;
			linyu_touch_mtslot_send_report(slot, x, y, 1);
		}
		ret = 0;
		break;

	case 4: 
		ret = linyu_touch_inject_down(x, y);
		break;

	default:
		ret = -EINVAL;
		break;
	}
	mutex_unlock(&g_touch_mode_lock);
	return ret;
}

static int linyu_touch_move(unsigned int slot, int x, int y)
{
	int ret;
	unsigned long flags;
	struct input_dev *dev;

	mutex_lock(&g_touch_mode_lock);
	if (!g_touch_initialized) {
		ret = linyu_touch_init_mode_locked(g_touch_mode);
		if (ret) {
			mutex_unlock(&g_touch_mode_lock);
			return ret;
		}
		g_touch_initialized = true;
	}

	switch (g_touch_mode) {
	case 0:
		if (slot >= MAX_TOUCH_SLOTS) {
			linyu_warn("touch: slot %d out of range\n", slot);
			ret = -EINVAL;
			break;
		}
		if (!g_target_file_fops) {
			ret = linyu_ensure_hook_installed_fops(NULL);
			if (ret < 0)
				break;
		}
		
		linyu_touch_down_internal_fops(slot, x, y);
		ret = 0;
		break;

	case 1:
		if (slot >= MAX_TOUCH_SLOTS) {
			ret = -EINVAL;
			break;
		}
		dev = linyu_touch_find_device(NULL);
		if (!dev) {
			ret = -ENODEV;
			break;
		}
		mutex_lock(&g_touch_lock);
		if (!g_touch_slots[slot].active) {
			mutex_unlock(&g_touch_lock);
			ret = -EINVAL;
			break;
		}
		g_touch_slots[slot].x = x;
		g_touch_slots[slot].y = y;
		mutex_unlock(&g_touch_lock);

		flags = 0;
		spin_lock_irqsave(&g_pool->lock, flags);
		if (my_input_handle_event) {
			linyu_touch_pool_add_event(EV_ABS, ABS_MT_SLOT, slot);
			linyu_touch_pool_add_event(EV_ABS, ABS_MT_TRACKING_ID,
				       g_touch_slots[slot].tracking_id);
			linyu_touch_pool_add_event(EV_ABS, ABS_MT_POSITION_X, x);
			linyu_touch_pool_add_event(EV_ABS, ABS_MT_POSITION_Y, y);
			linyu_touch_pool_add_event(EV_ABS, ABS_MT_PRESSURE, 0);
			linyu_touch_pool_add_event(EV_SYN, SYN_REPORT, 0);
		}
		spin_unlock_irqrestore(&g_pool->lock, flags);
		linyu_touch_pool_flush(dev);
		ret = 0;
		break;

	case 2:
		ret = linyu_touch_upload_event_direct(slot, 1, x, y);
		break;

	case 3:
		if (!g_mtslot_ready) {
			ret = -ENODEV;
			break;
		}
		if (slot > 5) {
			ret = -EINVAL;
			break;
		}
		if (g_mtslot_slot_ids[slot] != -1)
			linyu_touch_mtslot_send_report(slot, x, y, 1);
		ret = 0;
		break;

	case 4:
		
		ret = linyu_touch_inject_down(x, y);
		break;

	default:
		ret = -EINVAL;
		break;
	}
	mutex_unlock(&g_touch_mode_lock);
	return ret;
}

static int linyu_touch_up(unsigned int slot)
{
	int ret;
	unsigned long flags;
	struct input_dev *dev;

	mutex_lock(&g_touch_mode_lock);
	if (!g_touch_initialized) {
		ret = linyu_touch_init_mode_locked(g_touch_mode);
		if (ret) {
			mutex_unlock(&g_touch_mode_lock);
			return ret;
		}
		g_touch_initialized = true;
	}

	switch (g_touch_mode) {
	case 0:
		if (slot >= MAX_TOUCH_SLOTS) {
			linyu_warn("touch: slot %d out of range\n", slot);
			ret = -EINVAL;
			break;
		}
		if (!g_target_file_fops) {
			ret = linyu_ensure_hook_installed_fops(NULL);
			if (ret < 0)
				break;
		}
		mutex_lock(&g_slot_lock_fops);
		if (g_fops_slots[slot].active) {
			g_fops_slots[slot].active = 0;
			g_fops_slots[slot].need_up = 1;
		}
		mutex_unlock(&g_slot_lock_fops);
		ret = 0;
		
		if (g_dev_fops && g_mydev_fops) {
			if (mutex_trylock((struct mutex *)((char *)g_dev_fops + 520))) {
				g_need_wakeup_fops = true;
				if (g_myclient_fops)
					wake_up_interruptible((wait_queue_head_t *)
						((char *)g_myclient_fops + 16));
				mutex_unlock((struct mutex *)((char *)g_dev_fops + 520));
			}
		}
		break;

	case 1:
		if (slot >= MAX_TOUCH_SLOTS) {
			ret = -EINVAL;
			break;
		}
		dev = linyu_touch_find_device(NULL);
		if (!dev) {
			ret = -ENODEV;
			break;
		}
		mutex_lock(&g_touch_lock);
		if (!g_touch_slots[slot].active) {
			mutex_unlock(&g_touch_lock);
			ret = -EINVAL;
			break;
		}
		g_touch_slots[slot].active = 0;
		g_touch_slots[slot].tracking_id = -1;
		mutex_unlock(&g_touch_lock);

		flags = 0;
		spin_lock_irqsave(&g_pool->lock, flags);
		if (my_input_handle_event) {
			linyu_touch_pool_add_event(EV_ABS, ABS_MT_SLOT, slot);
			linyu_touch_pool_add_event(EV_ABS, ABS_MT_TRACKING_ID, -1);
			linyu_touch_pool_add_event(EV_SYN, SYN_REPORT, 0);
		}
		spin_unlock_irqrestore(&g_pool->lock, flags);
		linyu_touch_pool_flush(dev);
		ret = 0;
		break;

	case 2:
		ret = linyu_touch_upload_event_direct(slot, 0, 0, 0);
		break;

	case 3:
		if (!g_mtslot_ready) {
			ret = -ENODEV;
			break;
		}
		if (slot > 5) {
			ret = -EINVAL;
			break;
		}
		if (g_mtslot_slot_ids[slot] != -1) {
			g_mtslot_slot_ids[slot] = -1;
			linyu_touch_mtslot_send_report(slot, 0, 0, 0);
		}
		ret = 0;
		break;

	case 4:
		ret = linyu_touch_inject_up();
		break;

	default:
		ret = -EINVAL;
		break;
	}
	mutex_unlock(&g_touch_mode_lock);
	return ret;
}

static int linyu_touch_upload_event_direct(unsigned int slot, int action,
					    int x, int y)
{
	struct input_dev *dev;
	int i, num_active;

	if (slot >= MAX_TOUCH_SLOTS) {
		linyu_warn("touch: slot %d out of range\n", slot);
		return -EINVAL;
	}

	mutex_lock(&g_touch_lock_direct);
	dev = g_touch_dev_direct;
	if (!dev) {
		mutex_unlock(&g_touch_lock_direct);
		
		dev = linyu_touch_find_device(NULL);
		if (!dev)
			return -ENODEV;
		mutex_lock(&g_touch_lock_direct);
	}

	if (action) {
		
		if (!g_direct_slots[slot].active) {
			g_direct_slots[slot].active = 1;
			g_direct_slots[slot].tracking_id = slot + 20000;
		}
		mutex_unlock(&g_touch_lock_direct);

		input_event(dev, EV_ABS, ABS_MT_SLOT, slot);
		input_event(dev, EV_ABS, ABS_MT_TRACKING_ID,
			    g_direct_slots[slot].tracking_id);
		input_event(dev, EV_ABS, ABS_MT_POSITION_X, x);
		input_event(dev, EV_ABS, ABS_MT_POSITION_Y, y);
		if (test_bit(ABS_MT_PRESSURE, dev->absbit))
			input_event(dev, EV_ABS, ABS_MT_PRESSURE, 100);
		if (test_bit(ABS_MT_TOUCH_MAJOR, dev->absbit))
			input_event(dev, EV_ABS, ABS_MT_TOUCH_MAJOR, 10);
	} else {
		
		if (!g_direct_slots[slot].active) {
			mutex_unlock(&g_touch_lock_direct);
			return 0;
		}
		g_direct_slots[slot].active = 0;
		g_direct_slots[slot].tracking_id = -1;
		mutex_unlock(&g_touch_lock_direct);

		input_event(dev, EV_ABS, ABS_MT_SLOT, slot);
		input_event(dev, EV_ABS, ABS_MT_TRACKING_ID, -1);
	}

	
	num_active = 0;
	for (i = 0; i < MAX_TOUCH_SLOTS; i++) {
		if (g_direct_slots[i].active)
			num_active++;
	}
	input_event(dev, EV_KEY, BTN_TOUCH, num_active > 0);
	if (test_bit(BTN_TOOL_FINGER, dev->keybit))
		input_event(dev, EV_KEY, BTN_TOOL_FINGER, num_active == 1);
	if (test_bit(BTN_TOOL_DOUBLETAP, dev->keybit))
		input_event(dev, EV_KEY, BTN_TOOL_DOUBLETAP, num_active > 1);
	input_sync(dev);
	return 0;
}

static int linyu_touch_inject_down(int x, int y)
{
	struct inject_ctx *ctx = &g_touch_inject_ctx;
	unsigned long flags;
	struct input_dev *dev;
	int slot;
	int id;

	if (!g_inject_ctx_inited)
		return -ENODEV;

	spin_lock_irqsave(&ctx->lock, flags);
	dev = ctx->dev;
	if (!dev) {
		
		dev = linyu_touch_find_device(NULL);
		if (dev)
			ctx->dev = dev;
	}
	if (!dev) {
		spin_unlock_irqrestore(&ctx->lock, flags);
		return -ENODEV;
	}

	if (ctx->state == 1) {
		
		slot = ctx->cur_slot;
		spin_unlock_irqrestore(&ctx->lock, flags);
		if (slot >= 0) {
			input_event(dev, EV_ABS, ABS_MT_SLOT, slot);
			input_event(dev, EV_ABS, ABS_MT_POSITION_X, x);
			input_event(dev, EV_ABS, ABS_MT_POSITION_Y, y);
			input_sync(dev);
		}
		return 0;
	}
	if (ctx->state == 2) {
		ctx->state = 0;
	}

	
	slot = 0;
	if (ctx->slot_bitmap) {
		unsigned long first = find_first_zero_bit(ctx->slot_bitmap, ctx->max_slots);
		if (first >= ctx->max_slots) {
			spin_unlock_irqrestore(&ctx->lock, flags);
			return -EBUSY;
		}
		slot = (int)first;
		set_bit(slot, ctx->slot_bitmap);
	}

	ctx->cur_slot = slot;
	ctx->state = 1;
	id = ctx->next_id++;

	spin_unlock_irqrestore(&ctx->lock, flags);

	
	get_device(&dev->dev);
	input_event(dev, EV_ABS, ABS_MT_SLOT, slot);
	input_event(dev, EV_ABS, ABS_MT_TRACKING_ID, id);
	input_event(dev, EV_ABS, ABS_MT_POSITION_X, x);
	input_event(dev, EV_ABS, ABS_MT_POSITION_Y, y);
	if (test_bit(ABS_MT_PRESSURE, dev->absbit))
		input_event(dev, EV_ABS, ABS_MT_PRESSURE, 100);
	input_event(dev, EV_KEY, BTN_TOUCH, 1);
	if (test_bit(BTN_TOOL_FINGER, dev->keybit))
		input_event(dev, EV_KEY, BTN_TOOL_FINGER, 1);
	input_sync(dev);
	put_device(&dev->dev);

	return 0;
}

static int linyu_touch_inject_up(void)
{
	struct inject_ctx *ctx = &g_touch_inject_ctx;
	unsigned long flags;
	struct input_dev *dev;
	int slot;
	bool any_remaining = false;

	if (!g_inject_ctx_inited)
		return -ENODEV;

	spin_lock_irqsave(&ctx->lock, flags);
	dev = ctx->dev;
	if (!dev) {
		spin_unlock_irqrestore(&ctx->lock, flags);
		return -ENODEV;
	}

	if (ctx->state != 1) {
		spin_unlock_irqrestore(&ctx->lock, flags);
		return (ctx->state == 2) ? -ENODATA : -EINVAL;
	}

	slot = ctx->cur_slot;
	ctx->cur_slot = -1;
	ctx->state = 0;

	
	if (ctx->slot_bitmap && slot >= 0) {
		clear_bit(slot, ctx->slot_bitmap);
		any_remaining = !bitmap_empty(ctx->slot_bitmap, ctx->max_slots);
	}

	spin_unlock_irqrestore(&ctx->lock, flags);

	get_device(&dev->dev);
	input_event(dev, EV_ABS, ABS_MT_SLOT, slot);
	input_event(dev, EV_ABS, ABS_MT_TRACKING_ID, -1);
	if (!any_remaining) {
		input_event(dev, EV_KEY, BTN_TOUCH, 0);
		if (test_bit(BTN_TOOL_FINGER, dev->keybit))
			input_event(dev, EV_KEY, BTN_TOOL_FINGER, 0);
	}
	input_sync(dev);
	put_device(&dev->dev);

	return 0;
}

static int linyu_touch_set_mode(unsigned int mode)
{
	int ret;
	int old_mode;

	if (mode >= 5) return -EINVAL;

	mutex_lock(&g_touch_mode_lock);
	if (g_touch_initialized && g_touch_mode == (int)mode) {
		mutex_unlock(&g_touch_mode_lock);
		return 0;
	}

	old_mode = g_touch_mode;
	if (g_touch_initialized) {
		g_touch_initialized = false;
		linyu_touch_cleanup_mode_locked(old_mode);
	}

	ret = linyu_touch_init_mode_locked(mode);
	if (ret) {
		if (old_mode != (int)mode) {
			if (!linyu_touch_init_mode_locked(old_mode)) {
				g_touch_mode = old_mode;
				g_touch_initialized = true;
			}
		}
		mutex_unlock(&g_touch_mode_lock);
		linyu_warn("touch: mode %d failed: %d\n", mode, ret);
	} else {
		g_touch_mode = mode;
		g_touch_initialized = true;
		mutex_unlock(&g_touch_mode_lock);
		linyu_info("touch: mode %d active\n", mode);
	}
	return ret;
}

int linyu_touch_ioctl(unsigned long arg)
{
	struct linyu_touch_args a;

	if (copy_from_user(&a, (void __user *)arg, sizeof(a)))
		return -EFAULT;

	switch (a.action) {
	case 0: return linyu_touch_up(a.slot);
	case 1: return linyu_touch_down(a.slot, a.x, a.y);
	case 2: return linyu_touch_move(a.slot, a.x, a.y);
	default: return -EINVAL;
	}
}

int linyu_touch_mode_ioctl(unsigned long arg)
{
	struct linyu_touch_mode_args a;

	if (copy_from_user(&a, (void __user *)arg, sizeof(a)))
		return -EFAULT;

	return linyu_touch_set_mode(a.mode);
}
