# LingYuKernel 项目说明

## 项目结构

- `entry.c`：模块初始化、匿名 inode FD、ioctl 分发和 bind proc 入口。
- `comm.h`：用户态 ioctl 协议结构体和命令号。
- `linyu.h`：模块内部共享声明。
- `memory.c`、`pte_window.c`：进程虚拟地址转换、物理内存读写和 PTE window 访问。
- `process.c`：进程查找、模块基址、进程信息和进程间复制。
- `hide.c`、`hide_vfs.c`：模块隐藏、PID/路径隐藏和信号过滤相关逻辑。
- `touch.c`、`gyro.c`：触控与传感器数据控制。
- `remote_call.c`、`safe_signal.c`：目标进程远程调用和异常信号保护。
- `syscall_trace.c`：指定进程 syscall 追踪。
- `hwbp.c`：ARM64 硬件断点/观察点控制。
- `inline_hook.c`：ARM64 inline hook 扩展能力。
- `arraylist.c`：模块内部动态指针数组。
- `Makefile`：ARM64 GKI 内核模块构建脚本。

## 构建方式

默认内核源码目录：

```sh
make
```

可覆盖内核目录：

```sh
make KDIR=/path/to/kernel/common
```

构建产物：

- 源码目录：`LinYuKernel.ko`，保留调试信息，便于定位问题。
- 输出目录：`../out/LinYuKernel.ko`，默认移除调试段，作为发行版模块。
- 调试备份：`../out/LinYuKernel.debug.ko`，与源码目录模块一致，保留完整调试信息。

清理：

```sh
make clean
```

## 运行方式

该项目构建为 Linux 内核模块，加载方式取决于目标设备内核配置和权限策略。常规加载命令为：

```sh
insmod LinYuKernel.ko
```

卸载命令为：

```sh
rmmod LinYuKernel
```

## 核心功能入口

- `linyu_init` / `linyu_exit`：模块生命周期。
- `linyu_anon_ioctl`：匿名 FD ioctl 分发入口。
- `linyu_memory_*`：内存读写、地址转换和页表查询。
- `linyu_process_*`：进程查询、进程信息和权限相关操作。
- `linyu_hide_*`：隐藏模块、进程、路径和信号过滤。
- `linyu_touch_*`：触控事件控制。
- `linyu_gyro_*`：传感器数据控制。
- `linyu_syscall_trace_*`：syscall 追踪控制与读取。
- `linyu_remote_call_*` / `linyu_rc_*`：目标进程远程调用。
- `linyu_hwbp_*`：硬件断点/观察点管理。
- `linyu_inline_*`：inline hook 安装、移除和清理。

## 命名规则

保留函数统一使用 `linyu_` 前缀：

- 普通入口：`linyu_功能`
- 模块函数：`linyu_模块_功能`
- ioctl 处理：`linyu_模块_ioctl` 或 `linyu_模块_功能`
- 初始化/清理：`linyu_模块_init`、`linyu_模块_exit`、`linyu_模块_cleanup`
- 内部回调：`linyu_模块_回调用途`

模块最终产物统一为 `LinYuKernel.ko`。

## 本次重构内容

- 将构建目标统一为 `LinYuKernel.o`，最终模块名统一为 `LinYuKernel.ko`。
- 将 ioctl 处理函数从 `do_*` 统一重命名为 `linyu_模块_功能` 风格，并同步更新 `linyu.h` 和 `entry.c` 分发表。
- 将内部回调和静态辅助函数统一为 `linyu_` 命名，包括 bindproc、hide、VFS、gyro、touch、remote call、syscall trace、hwbp、pte window 和 inline hook 模块。
- 删除源码中的反编译说明和冗余解释性注释，保留代码本身表达功能。
- 修复匿名 inode FD release 未释放 `bindproc_priv` 和事件数组的问题。
- 修复 touch fops 模式清理时未恢复原始 `file_operations`、未释放文件引用的问题。
- 修复 hwbp 初始化重复调用时可能重复分配大缓冲区的问题。
- 删除无实现的 `linyu_touch_init` 声明。
- 删除未调用的 hide 清理壳函数。
- 恢复并保留 `inline_hook.c`、`arraylist.c`、PTE 扩展 helper、hwbp 辅助函数和 entry 文件辅助函数。
- 补齐 path-hide kretprobe 卸载路径，`linyu_hide_proc_exit` 会同步注销 path-hide kretprobe。
- 补齐 inline hook 的目标校验和空指针校验，卸载阶段会执行 `linyu_inline_hook_remove_all`。
- 恢复 supercall work 回调和 bindproc 事件数组释放路径，当前作为扩展入口保留。
- 补齐 touch mode 1 的事件池 flush 流程，池化事件会提交到 `input_handle_event`。
- 补齐 hwbp 示例回调的寄存器快照记录，触发时会写入 hwbp 共享缓冲区。
- 默认关闭 `linyu_info` 调试日志，保留 `linyu_warn` / `linyu_err` 用于异常诊断；需要调试时可显式定义 `LINYU_DEBUG_LOG`。
- 移除默认执行的 CFI handler patch 和 kprobe blacklist 改写逻辑，避免主动修改内核保护路径。
- 修正 remote call 中 `task_work_cancel` 的错误原型调用，改为匹配内核声明的 `task_work_cancel_func`。
- 简化 touch mode 1 初始化路径，移除无实际处理逻辑的空 kprobe 注册，仅保留 `input_handle_event` 事件提交路径。
- 调整构建打包流程，输出目录默认保存 stripped 发行版模块，同时保留 debug 版本用于排查。
- 构建时关闭模块 BTF 生成开关，避免缺少 `vmlinux` 时产生 BTF 打包提示。
- 移除 `-Wno-unused-function`，避免构建配置继续掩盖未用静态函数。
- 删除旧模块构建产物和内核构建中间文件，避免污染验证结果。

## 删除内容

- 旧模块产物和旧输出文件。
- 旧 `.cmd`、`.mod`、`modules.order`、`Module.symvers` 等生成文件。
- 未实现声明：`linyu_touch_init`。
- 未调用函数：`linyu_hide_cleanup_all`。
- 源码内冗余注释块和行注释。

## 验证结果

已执行：

```sh
make
```

结果：

- 编译成功。
- 已生成源码目录调试版 `LinYuKernel.ko`。
- 已生成输出目录发行版 `../out/LinYuKernel.ko`。
- 已生成输出目录调试备份 `../out/LinYuKernel.debug.ko`。
- IDE linter 未报告错误。

当前体积：

- 调试版：约 `1.4M`。
- 发行版：约 `182K`。

构建环境提示：

- 当前内核构建环境缺少完整 `Module.symvers`，因此 `modpost` 报告外部符号未解析警告。
- 当前环境没有可用 `Module.symvers`，该警告需要匹配目标内核的符号版本表才能彻底消除。
- 已关闭模块 BTF 生成，避免缺少 `vmlinux` 时的 BTF 提示。

## 剩余风险

- 已在连接设备上执行过 `insmod /data/local/tmp/LinYuKernel.ko`，命令返回成功；模块会按当前逻辑自隐藏，常规 `/proc/modules` 与 `/sys/module` 不显示。
- 尚未完成完整 ioctl 功能回归和卸载后状态验证。
- `modpost` 外部符号警告需要目标内核的完整符号版本信息进一步确认。
- touch、remote call、hide、hwbp 等功能依赖具体 ARM64/GKI 内核符号和结构体布局，跨内核版本仍需实机验证。
