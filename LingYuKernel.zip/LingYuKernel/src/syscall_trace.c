#include "linyu.h"
#include "comm.h"
#include <linux/kprobes.h>
#include <linux/ktime.h>
#include <linux/percpu.h>

#define TRACE_RING_SLOTS   256
#define TRACE_PER_CPU_SLOTS 32 
#define MAX_TRACE_PIDS      32

#define SYS_NR_OPENAT  56
#define SYS_NR_CLOSE   57
#define SYS_NR_READ    63
#define SYS_NR_WRITE   64

struct trace_entry_slot {
	bool in_use;
	int  syscall_nr;
	pid_t pid;
	u64  enter_ns;
	unsigned long args[6];
};

struct trace_record {
	pid_t          pid;
	int            syscall_nr;
	u64            enter_ns;
	u64            duration_ns;
	long           retval;
	unsigned long  args[6];
};

static DEFINE_PER_CPU(struct trace_entry_slot, trace_staging);

static struct trace_record *trace_ring;
static unsigned int  trace_head;
static unsigned int  trace_count;
static DEFINE_SPINLOCK(trace_lock);

static pid_t traced_pids[MAX_TRACE_PIDS];
static int   traced_pid_count;
static DEFINE_SPINLOCK(pid_filter_lock);

static bool trace_inited;

struct sys_kretprobe {
	struct kretprobe kp;
	int    syscall_nr;
	bool   registered;
};

static struct sys_kretprobe probes[4];

static bool linyu_syscall_trace_pid_match(pid_t pid)
{
	int i;
	unsigned long flags;
	bool hit = false;

	spin_lock_irqsave(&pid_filter_lock, flags);
	for (i = 0; i < traced_pid_count; i++) {
		if (traced_pids[i] == pid) {
			hit = true;
			break;
		}
	}
	spin_unlock_irqrestore(&pid_filter_lock, flags);
	return hit;
}

static int linyu_syscall_trace_entry_common(int syscall_nr, struct pt_regs *regs)
{
	struct trace_entry_slot *slot;
	pid_t pid = current->pid;

	if (!trace_inited)
		return 1; 

	if (!linyu_syscall_trace_pid_match(pid))
		return 1;

	slot = this_cpu_ptr(&trace_staging);
	slot->syscall_nr = syscall_nr;
	slot->pid        = pid;
	slot->enter_ns   = ktime_get_ns();
	slot->args[0]    = regs->regs[0];
	slot->args[1]    = regs->regs[1];
	slot->args[2]    = regs->regs[2];
	slot->args[3]    = regs->regs[3];
	slot->args[4]    = regs->regs[4];
	slot->args[5]    = regs->regs[5];
	slot->in_use     = true;
	return 0;
}

static int linyu_syscall_trace_ret_common(struct kretprobe_instance *ri, struct pt_regs *regs)
{
	struct trace_entry_slot *slot;
	struct trace_record    *rec;
	unsigned long flags;
	long retval;
	u64 now;

	if (!trace_inited || !trace_ring)
		return 0;

	slot = this_cpu_ptr(&trace_staging);
	if (!slot->in_use)
		return 0;
	slot->in_use = false;

	now    = ktime_get_ns();
	retval = (long)regs->regs[0];

	spin_lock_irqsave(&trace_lock, flags);

	if (trace_count >= TRACE_RING_SLOTS) {
		
		trace_head = (trace_head + 1) % TRACE_RING_SLOTS;
		trace_count = TRACE_RING_SLOTS - 1;
	}

	rec = &trace_ring[(trace_head + trace_count) % TRACE_RING_SLOTS];
	rec->pid          = slot->pid;
	rec->syscall_nr   = slot->syscall_nr;
	rec->enter_ns     = slot->enter_ns;
	rec->duration_ns  = now - slot->enter_ns;
	rec->retval       = retval;
	rec->args[0]      = slot->args[0];
	rec->args[1]      = slot->args[1];
	rec->args[2]      = slot->args[2];
	rec->args[3]      = slot->args[3];
	rec->args[4]      = slot->args[4];
	rec->args[5]      = slot->args[5];

	trace_count++;

	spin_unlock_irqrestore(&trace_lock, flags);
	return 0;
}

static int linyu_syscall_trace_entry_openat(struct kretprobe_instance *ri, struct pt_regs *regs)
{
	return linyu_syscall_trace_entry_common(SYS_NR_OPENAT, regs);
}

static int linyu_syscall_trace_entry_close(struct kretprobe_instance *ri, struct pt_regs *regs)
{
	return linyu_syscall_trace_entry_common(SYS_NR_CLOSE, regs);
}

static int linyu_syscall_trace_entry_read(struct kretprobe_instance *ri, struct pt_regs *regs)
{
	return linyu_syscall_trace_entry_common(SYS_NR_READ, regs);
}

static int linyu_syscall_trace_entry_write(struct kretprobe_instance *ri, struct pt_regs *regs)
{
	return linyu_syscall_trace_entry_common(SYS_NR_WRITE, regs);
}

static int linyu_syscall_trace_register_one(struct sys_kretprobe *p, const char *sym,
			kretprobe_handler_t entry, int syscall_nr)
{
	int ret;

	memset(&p->kp, 0, sizeof(p->kp));
	p->kp.kp.symbol_name = sym;
	p->kp.entry_handler  = entry;
	p->kp.handler        = linyu_syscall_trace_ret_common;
	p->kp.maxactive      = NR_CPUS * 4;
	p->syscall_nr        = syscall_nr;

	ret = register_kretprobe(&p->kp);
	if (ret) {
		linyu_warn("syscall_trace: kretprobe '%s' failed: %d\n", sym, ret);
		return ret;
	}
	p->registered = true;
	return 0;
}

int linyu_syscall_trace_init(void)
{
	int rc;

	trace_ring = kvzalloc(sizeof(*trace_ring) * TRACE_RING_SLOTS, GFP_KERNEL);
	if (!trace_ring)
		return -ENOMEM;

	trace_head  = 0;
	trace_count = 0;
	traced_pid_count = 0;
	trace_inited = true;

	rc = linyu_syscall_trace_register_one(&probes[0], "__arm64_sys_openat", linyu_syscall_trace_entry_openat, SYS_NR_OPENAT);
	linyu_syscall_trace_register_one(&probes[1], "__arm64_sys_close",  linyu_syscall_trace_entry_close,  SYS_NR_CLOSE);
	linyu_syscall_trace_register_one(&probes[2], "__arm64_sys_read",   linyu_syscall_trace_entry_read,   SYS_NR_READ);
	linyu_syscall_trace_register_one(&probes[3], "__arm64_sys_write",  linyu_syscall_trace_entry_write,  SYS_NR_WRITE);

	linyu_info("syscall_trace: initialized (ring=%d slots, base_rc=%d)\n",
		   TRACE_RING_SLOTS, rc);
	return 0;
}

void linyu_syscall_trace_exit(void)
{
	int i;

	trace_inited = false;

	for (i = 0; i < ARRAY_SIZE(probes); i++) {
		if (probes[i].registered) {
			unregister_kretprobe(&probes[i].kp);
			probes[i].registered = false;
		}
	}

	if (trace_ring) {
		kvfree(trace_ring);
		trace_ring = NULL;
	}
}

int linyu_syscall_trace_ctl(unsigned long arg)
{
	struct linyu_syscall_trace_ctl_args a;
	unsigned long flags;
	int i;

	if (copy_from_user(&a, (void __user *)arg, sizeof(a)))
		return -EFAULT;

	if (!trace_inited)
		return -ENODEV;

	spin_lock_irqsave(&pid_filter_lock, flags);

	switch (a.action) {
	case 1: 
		for (i = 0; i < traced_pid_count; i++) {
			if (traced_pids[i] == a.pid) {
				spin_unlock_irqrestore(&pid_filter_lock, flags);
				return 0;
			}
		}
		if (traced_pid_count >= MAX_TRACE_PIDS) {
			spin_unlock_irqrestore(&pid_filter_lock, flags);
			return -ENOSPC;
		}
		traced_pids[traced_pid_count++] = a.pid;
		break;

	case 0: 
		for (i = 0; i < traced_pid_count; i++) {
			if (traced_pids[i] == a.pid) {
				traced_pids[i] = traced_pids[--traced_pid_count];
				break;
			}
		}
		break;

	case 2: 
		traced_pid_count = 0;
		spin_unlock_irqrestore(&pid_filter_lock, flags);

		spin_lock_irqsave(&trace_lock, flags);
		trace_head = 0;
		trace_count = 0;
		spin_unlock_irqrestore(&trace_lock, flags);
		return 0;

	default:
		spin_unlock_irqrestore(&pid_filter_lock, flags);
		return -EINVAL;
	}

	spin_unlock_irqrestore(&pid_filter_lock, flags);
	return 0;
}

int linyu_syscall_trace_list(unsigned long arg)
{
	struct linyu_syscall_trace_list_args a;
	struct trace_record *kbuf;
	unsigned long flags;
	unsigned long want, copied = 0;
	int ret = 0;

	if (copy_from_user(&a, (void __user *)arg, sizeof(a)))
		return -EFAULT;

	if (!trace_inited)
		return -ENODEV;

	want = a.max_count;
	if (want == 0)
		return -EINVAL;
	if (want > TRACE_RING_SLOTS)
		want = TRACE_RING_SLOTS;

	kbuf = kvmalloc(sizeof(*kbuf) * want, GFP_KERNEL);
	if (!kbuf)
		return -ENOMEM;

	spin_lock_irqsave(&trace_lock, flags);
	while (copied < want && trace_count > 0) {
		kbuf[copied++] = trace_ring[trace_head];
		trace_head = (trace_head + 1) % TRACE_RING_SLOTS;
		trace_count--;
	}
	spin_unlock_irqrestore(&trace_lock, flags);

	if (copied && copy_to_user((void __user *)a.buf, kbuf,
				   sizeof(*kbuf) * copied)) {
		ret = -EFAULT;
		goto out;
	}

	a.count = copied;
	if (copy_to_user((void __user *)arg, &a, sizeof(a)))
		ret = -EFAULT;

out:
	kvfree(kbuf);
	return ret;
}
