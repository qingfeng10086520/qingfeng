#include "linyu.h"
#include "comm.h"
#include <linux/string.h>
#include <linux/rcupdate.h>

struct task_struct *linyu_get_target_task(pid_t pid)
{
	struct pid *pid_s;
	struct task_struct *task;

	pid_s = find_get_pid(pid);
	if (!pid_s)
		return NULL;

	task = get_pid_task(pid_s, PIDTYPE_PID);
	put_pid(pid_s);
	return task;
}

unsigned long linyu_get_module_base(pid_t pid, const char *name)
{
	struct task_struct *task;
	struct mm_struct *mm;
	struct vm_area_struct *vma;
	struct vma_iterator vmi;
	unsigned long base = 0;
	char buf[256];

	task = linyu_get_target_task(pid);
	if (!task)
		return 0;

	mm = get_task_mm(task);
	put_task_struct(task);
	if (!mm)
		return 0;

	mmap_read_lock(mm);
	vma_iter_init(&vmi, mm, 0);
	for_each_vma(vmi, vma) {
		if (vma->vm_file) {
			char *p = d_path(&vma->vm_file->f_path, buf, sizeof(buf));
			if (!IS_ERR(p)) {
				const char *bname = kbasename(p);
				if (strcmp(bname, name) == 0) {
					base = vma->vm_start;
					break;
				}
			}
		}
	}
	mmap_read_unlock(mm);
	mmput(mm);
	return base;
}

unsigned long linyu_get_module_base_bss(pid_t pid, const char *name)
{
	struct task_struct *task;
	struct mm_struct *mm;
	struct vm_area_struct *vma;
	struct vma_iterator vmi;
	unsigned long base = 0;
	unsigned long module_end = 0;
	bool found_module = false;
	char buf[256];

	task = linyu_get_target_task(pid);
	if (!task)
		return 0;

	mm = get_task_mm(task);
	put_task_struct(task);
	if (!mm)
		return 0;

	mmap_read_lock(mm);
	vma_iter_init(&vmi, mm, 0);
	for_each_vma(vmi, vma) {
		if (vma->vm_file) {
			char *p = d_path(&vma->vm_file->f_path, buf, sizeof(buf));
			if (!IS_ERR(p)) {
				const char *bname = kbasename(p);
				if (strcmp(bname, name) == 0) {
					found_module = true;
					module_end = vma->vm_end;
					continue;
				}
			}
			if (found_module) {
				found_module = false;
			}
		} else if (found_module) {
			if (vma->vm_start == module_end) {
				base = vma->vm_start;
				break;
			}
			found_module = false;
		}
	}
	mmap_read_unlock(mm);
	mmput(mm);
	return base;
}

pid_t linyu_find_process_by_name(const char *name)
{
	struct task_struct *task;
	pid_t found_pid = 0;

	rcu_read_lock();
	for_each_process(task) {
		if (strcmp(task->comm, name) == 0) {
			found_pid = task->pid;
			break;
		}
	}
	rcu_read_unlock();

	return found_pid;
}

int linyu_is_pid_alive(pid_t pid)
{
	struct pid *pid_s;
	struct task_struct *task;

	pid_s = find_get_pid(pid);
	if (!pid_s)
		return 0;

	task = pid_task(pid_s, PIDTYPE_PID);
	put_pid(pid_s);
	return task ? 1 : 0;
}

int linyu_process_find(unsigned long arg)
{
	struct linyu_find_process_args a;

	if (copy_from_user(&a, (void __user *)arg, sizeof(a)))
		return -EFAULT;

	a.name[sizeof(a.name) - 1] = '\0';
	a.pid = linyu_find_process_by_name(a.name);

	if (copy_to_user((void __user *)arg, &a, sizeof(a)))
		return -EFAULT;
	return a.pid > 0 ? 0 : -ESRCH;
}

int linyu_process_get_module_base(unsigned long arg)
{
	struct linyu_module_base_args a;

	if (copy_from_user(&a, (void __user *)arg, sizeof(a)))
		return -EFAULT;

	a.name[sizeof(a.name) - 1] = '\0';
	a.base = linyu_get_module_base(a.pid, a.name);
	a.size = 0;

	if (copy_to_user((void __user *)arg, &a, sizeof(a)))
		return -EFAULT;
	return a.base ? 0 : -ENOENT;
}

int linyu_process_get_module_base_bss(unsigned long arg)
{
	struct linyu_module_base_args a;

	if (copy_from_user(&a, (void __user *)arg, sizeof(a)))
		return -EFAULT;

	a.name[sizeof(a.name) - 1] = '\0';
	a.base = linyu_get_module_base_bss(a.pid, a.name);
	a.size = 0;

	if (copy_to_user((void __user *)arg, &a, sizeof(a)))
		return -EFAULT;
	return a.base ? 0 : -ENOENT;
}

int linyu_process_is_alive(unsigned long arg)
{
	struct linyu_is_alive_args a;

	if (copy_from_user(&a, (void __user *)arg, sizeof(a)))
		return -EFAULT;

	a.alive = linyu_is_pid_alive(a.pid);

	if (copy_to_user((void __user *)arg, &a, sizeof(a)))
		return -EFAULT;
	return 0;
}

int linyu_process_list(unsigned long arg)
{
	struct linyu_list_procs_args a;
	struct task_struct *task;
	unsigned long count = 0;
	int *kbuf;
	size_t max;

	if (copy_from_user(&a, (void __user *)arg, sizeof(a)))
		return -EFAULT;

	max = a.max_count;
	if (max > 4096)
		max = 4096;

	kbuf = kvmalloc(max * sizeof(int), GFP_KERNEL);
	if (!kbuf)
		return -ENOMEM;

	rcu_read_lock();
	for_each_process(task) {
		if (count >= max)
			break;
		kbuf[count++] = task->pid;
	}
	rcu_read_unlock();

	if (copy_to_user((void __user *)a.buf, kbuf, count * sizeof(int))) {
		kvfree(kbuf);
		return -EFAULT;
	}

	kvfree(kbuf);
	a.count = count;

	if (copy_to_user((void __user *)arg, &a, sizeof(a)))
		return -EFAULT;
	return 0;
}

int linyu_process_get_info(unsigned long arg)
{
	struct linyu_process_info_args a;
	struct task_struct *task;
	struct mm_struct *mm;

	if (copy_from_user(&a, (void __user *)arg, sizeof(a)))
		return -EFAULT;

	task = linyu_get_target_task(a.pid);
	if (!task)
		return -ESRCH;

	strncpy(a.name, task->comm, sizeof(a.name) - 1);
	a.name[sizeof(a.name) - 1] = '\0';

	mm = get_task_mm(task);
	put_task_struct(task);

	if (mm) {
		a.total_vm = mm->total_vm;
		a.maps_count = mm->map_count;
		mmput(mm);
	} else {
		a.total_vm = 0;
		a.maps_count = 0;
	}

	if (copy_to_user((void __user *)arg, &a, sizeof(a)))
		return -EFAULT;
	return 0;
}
