#ifndef _COMM_H_
#define _COMM_H_

#include <linux/ioctl.h>

#define LINYU_IOC_MAGIC 'X'

struct linyu_vaddr_translate_args {
	int pid;
	int _pad;
	unsigned long vaddr;
	unsigned long result;
};
#define LINYU_VADDR_TRANSLATE  _IOWR(LINYU_IOC_MAGIC, 0x01, struct linyu_vaddr_translate_args)

struct linyu_debug_info_args {
	unsigned long data[7];
};
#define LINYU_DEBUG_INFO       _IOR(LINYU_IOC_MAGIC, 0x02, struct linyu_debug_info_args)

struct linyu_at_s1e0r_args {
	int pid;
	int _pad;
	unsigned long vaddr;
	unsigned long result;
};
#define LINYU_AT_S1E0R         _IOWR(LINYU_IOC_MAGIC, 0x03, struct linyu_at_s1e0r_args)

struct linyu_page_info_args {
	int pid;
	int _pad;
	unsigned long vaddr;
	unsigned long phys;
	unsigned long flags;
};
#define LINYU_GET_PAGE_INFO    _IOWR(LINYU_IOC_MAGIC, 0x04, struct linyu_page_info_args)

struct linyu_pte_mapping_args {
	int pid;
	int _pad;
	unsigned long vaddr;
	unsigned long pte_val;
};
#define LINYU_PTE_MAPPING      _IOWR(LINYU_IOC_MAGIC, 0x06, struct linyu_pte_mapping_args)

struct linyu_page_table_walk_args {
	int pid;
	int _pad;
	unsigned long vaddr;
	unsigned long pgd_val;
	unsigned long pte_val;
};
#define LINYU_PAGE_TABLE_WALK  _IOWR(LINYU_IOC_MAGIC, 0x07, struct linyu_page_table_walk_args)

struct linyu_copy_process_args {
	int src_pid;
	int _pad;
	unsigned long src_addr;
	int dst_pid;
	int _pad2;
	unsigned long dst_addr;
	unsigned long size;
};
#define LINYU_COPY_PROCESS     _IOWR(LINYU_IOC_MAGIC, 0x08, struct linyu_copy_process_args)

struct linyu_rw_args {
	int pid;
	int _pad;
	unsigned long vaddr;
	unsigned long __user ubuf;
	unsigned long size;
};
#define LINYU_READ_PHYS        _IOWR(LINYU_IOC_MAGIC, 0x09, struct linyu_rw_args)
#define LINYU_WRITE_PHYS       _IOWR(LINYU_IOC_MAGIC, 0x0c, struct linyu_rw_args)
#define LINYU_READ_PHYS_IOREMAP _IOWR(LINYU_IOC_MAGIC, 0x10, struct linyu_rw_args)

struct linyu_rw_fast_args {
	int pid;
	int mode;
	unsigned long vaddr;
	unsigned long __user ubuf;
	unsigned long size;
};
#define LINYU_READ_PHYS_FAST   _IOWR(LINYU_IOC_MAGIC, 0x1a, struct linyu_rw_fast_args)

struct linyu_phys_read_args {
	int pid;
	int mode;
	unsigned long vaddr;
	unsigned long __user ubuf;
	unsigned long size;
};
#define LINYU_PHYS_READ        _IOWR(LINYU_IOC_MAGIC, 0x22, struct linyu_phys_read_args)

struct linyu_module_base_args {
	int pid;
	int _pad;
	char name[0x100];
	unsigned long base;
	unsigned long size;
};
#define LINYU_GET_MODULE_BASE  _IOWR(LINYU_IOC_MAGIC, 0x0a, struct linyu_module_base_args)
#define LINYU_GET_MODULE_BASE_BSS _IOWR(LINYU_IOC_MAGIC, 0x21, struct linyu_module_base_args)

struct linyu_find_process_args {
	char name[0x100];
	int pid;
};
#define LINYU_FIND_PROCESS     _IOWR(LINYU_IOC_MAGIC, 0x0b, struct linyu_find_process_args)

struct linyu_is_alive_args {
	int pid;
	int alive;
};
#define LINYU_IS_PROCESS_ALIVE _IOWR(LINYU_IOC_MAGIC, 0x0d, struct linyu_is_alive_args)

struct linyu_give_root_args {
	int pid;
};
#define LINYU_GIVE_ROOT        _IOWR(LINYU_IOC_MAGIC, 0x0f, struct linyu_give_root_args)

struct linyu_hide_process_args {
	int pid;
};
#define LINYU_HIDE_PROCESS     _IOWR(LINYU_IOC_MAGIC, 0x0e, struct linyu_hide_process_args)

struct linyu_hide_path_args {
	char path[0x100];
	int action;
	int _pad;
};
#define LINYU_HIDE_PATH        _IOWR(LINYU_IOC_MAGIC, 0x17, struct linyu_hide_path_args)

struct linyu_hide_kgsl_args {
	int pid;
};
#define LINYU_HIDE_KGSL        _IOWR(LINYU_IOC_MAGIC, 0x18, struct linyu_hide_kgsl_args)

struct linyu_bind_proc_args {
	int pid;
	int fd;
};
#define LINYU_BIND_PROC        _IOWR(LINYU_IOC_MAGIC, 0x12, struct linyu_bind_proc_args)

struct linyu_list_procs_args {
	unsigned long __user buf;
	unsigned long count;
	unsigned long max_count;
};
#define LINYU_LIST_PROCESSES   _IOWR(LINYU_IOC_MAGIC, 0x13, struct linyu_list_procs_args)

struct linyu_process_info_args {
	int pid;
	int _pad;
	char name[0x100];
	unsigned long maps_count;
	unsigned long total_vm;
};
#define LINYU_GET_PROCESS_INFO _IOWR(LINYU_IOC_MAGIC, 0x14, struct linyu_process_info_args)

struct linyu_touch_args {
	int action;
	int slot;
	int x;
	int y;
};
#define LINYU_TOUCH            _IOWR(LINYU_IOC_MAGIC, 0x15, struct linyu_touch_args)

struct linyu_touch_mode_args {
	int mode;
};
#define LINYU_TOUCH_MODE       _IOWR(LINYU_IOC_MAGIC, 0x19, struct linyu_touch_mode_args)

struct linyu_gyro_args {
	int action;
	int _pad;
	long values[2];
};
#define LINYU_CONFIG_GYRO      _IOWR(LINYU_IOC_MAGIC, 0x16, struct linyu_gyro_args)

struct linyu_syscall_trace_ctl_args {
	int pid;
	int action;
};
#define LINYU_SYSCALL_TRACE_CTL  _IOWR(LINYU_IOC_MAGIC, 0x1d, struct linyu_syscall_trace_ctl_args)

struct linyu_syscall_trace_list_args {
	unsigned long __user buf;
	unsigned long count;
	unsigned long max_count;
};
#define LINYU_SYSCALL_TRACE_LIST _IOWR(LINYU_IOC_MAGIC, 0x1e, struct linyu_syscall_trace_list_args)

struct linyu_remote_call_args {
	int pid;
	int _pad;
	unsigned long func_addr;
	unsigned long args[40];
	int arg_count;
	int _pad2;
	unsigned long retval;
};
#define LINYU_REMOTE_CALL      _IOWR(LINYU_IOC_MAGIC, 0x1f, struct linyu_remote_call_args)

struct linyu_remote_call_batch_args {
	int pid;
	int count;
	unsigned long __user calls;
	unsigned long __user results;
	unsigned long timeout_ms;
};
#define LINYU_REMOTE_CALL_BATCH _IOWR(LINYU_IOC_MAGIC, 0x20, struct linyu_remote_call_batch_args)

#define LINYU_HWBP_INFO        _IOR(LINYU_IOC_MAGIC, 0x23, int)
#define LINYU_HWBP_SET         _IOW(LINYU_IOC_MAGIC, 0x24, int)
#define LINYU_HWBP_REMOVE      _IO(LINYU_IOC_MAGIC, 0x25)

#define LINYU_ACQUIRE_FD       0xC0185806

#endif 
