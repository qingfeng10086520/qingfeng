#include "linyu.h"
#include <linux/kprobes.h>
#include <linux/slab.h>
#include <linux/spinlock.h>
#include <linux/signal.h>
#include <linux/sched/signal.h>

struct unsafe_area {
	unsigned long vaddr;
	u32           size;
	u32           tag;
	int           pid;
	int           _pad;
};

struct unsafe_region_table {
	struct unsafe_area **items;
	size_t               count;
	size_t               capacity;
};

#define INIT_CAPACITY 16

static struct unsafe_region_table *g_areas;
static DEFINE_RWLOCK(g_areas_lock);

static struct kretprobe get_signal_krp;
static bool             get_signal_krp_registered;

static int linyu_safe_signal_areas_table_init(void)
{
	struct unsafe_region_table *t;
	struct unsafe_area        **slots;

	if (g_areas)
		return 0;

	t = kmalloc(sizeof(*t), GFP_KERNEL);
	if (!t)
		return -ENOMEM;

	slots = kmalloc_array(INIT_CAPACITY, sizeof(*slots), GFP_KERNEL);
	if (!slots) {
		kfree(t);
		return -ENOMEM;
	}

	t->items    = slots;
	t->count    = 0;
	t->capacity = INIT_CAPACITY;
	g_areas     = t;
	return 0;
}

static void linyu_safe_signal_areas_table_destroy(void)
{
	struct unsafe_region_table *t;
	unsigned long flags;
	size_t i;

	write_lock_irqsave(&g_areas_lock, flags);
	t = g_areas;
	g_areas = NULL;
	write_unlock_irqrestore(&g_areas_lock, flags);

	if (!t)
		return;

	for (i = 0; i < t->count; i++)
		kvfree(t->items[i]);
	kfree(t->items);
	kfree(t);
}

int linyu_add_unsafe_region(int pid, unsigned long vaddr, u32 size, u32 tag)
{
	struct unsafe_area *a;
	unsigned long flags;
	int ret = 0;

	a = kvmalloc(sizeof(*a), GFP_KERNEL);
	if (!a)
		return -ENOMEM;

	a->pid   = pid;
	a->vaddr = vaddr;
	a->size  = size;
	a->tag   = tag;

	write_lock_irqsave(&g_areas_lock, flags);
	if (!g_areas) {
		ret = -ENODEV;
		goto out;
	}

	if (g_areas->count == g_areas->capacity) {
		size_t new_cap = g_areas->capacity + (g_areas->capacity >> 1);
		struct unsafe_area **new_items;

		if (new_cap < g_areas->count + 1)
			new_cap = g_areas->count + 1;

		new_items = krealloc(g_areas->items,
				     sizeof(*new_items) * new_cap, GFP_ATOMIC);
		if (!new_items) {
			ret = -ENOMEM;
			goto out;
		}
		g_areas->items    = new_items;
		g_areas->capacity = new_cap;
	}

	g_areas->items[g_areas->count++] = a;
	a = NULL; 

out:
	write_unlock_irqrestore(&g_areas_lock, flags);
	if (a)
		kvfree(a);
	return ret;
}

int linyu_del_unsafe_region(int pid)
{
	unsigned long flags;
	size_t i;
	int removed = 0;

	write_lock_irqsave(&g_areas_lock, flags);
	if (!g_areas) {
		write_unlock_irqrestore(&g_areas_lock, flags);
		return -ENODEV;
	}

	for (i = 0; i < g_areas->count;) {
		struct unsafe_area *a = g_areas->items[i];
		if (a && a->pid == pid) {
			kvfree(a);
			if (i + 1 < g_areas->count)
				memmove(&g_areas->items[i],
					&g_areas->items[i + 1],
					sizeof(*g_areas->items) * (g_areas->count - i - 1));
			g_areas->count--;
			removed++;
			continue;
		}
		i++;
	}
	write_unlock_irqrestore(&g_areas_lock, flags);
	return removed;
}

bool linyu_check_unsafe_region(int pid, unsigned long vaddr)
{
	unsigned long flags;
	size_t i;
	bool hit = false;

	read_lock_irqsave(&g_areas_lock, flags);
	if (!g_areas) {
		read_unlock_irqrestore(&g_areas_lock, flags);
		return false;
	}

	for (i = 0; i < g_areas->count; i++) {
		struct unsafe_area *a = g_areas->items[i];
		if (!a)
			continue;
		if (a->pid != pid)
			continue;
		if (vaddr >= a->vaddr && vaddr < a->vaddr + a->size) {
			hit = true;
			break;
		}
	}
	read_unlock_irqrestore(&g_areas_lock, flags);
	return hit;
}

struct gs_data {
	struct ksignal *ksig;
};

static int linyu_safe_signal_get_signal_entry(struct kretprobe_instance *ri, struct pt_regs *regs)
{
	struct gs_data *d = (struct gs_data *)ri->data;
	d->ksig = (struct ksignal *)regs->regs[0];
	return 0;
}

static int linyu_safe_signal_get_signal_return(struct kretprobe_instance *ri, struct pt_regs *regs)
{
	struct gs_data *d = (struct gs_data *)ri->data;
	long retval = (long)regs->regs[0];
	struct ksignal *ksig;
	int sig;
	pid_t pid;
	unsigned long fault_addr;

	if (!retval || !d->ksig)
		return 0;

	ksig = d->ksig;
	sig  = ksig->info.si_signo;

	
	if (sig != SIGSEGV && sig != SIGBUS)
		return 0;

	pid = task_pid_nr(current);
	fault_addr = (unsigned long)ksig->info.si_addr;

	if (linyu_check_unsafe_region(pid, fault_addr)) {
		

		regs->regs[0] = 0;

		

		linyu_rc_try_restore_context(pid);

		linyu_info("safe_signal: swallowed sig %d for pid %d @ %lx\n",
			   sig, pid, fault_addr);
	}
	return 0;
}

int linyu_safe_signal_init(void)
{
	int ret;
	int maxactive;

	ret = linyu_safe_signal_areas_table_init();
	if (ret)
		return ret;

	maxactive = num_possible_cpus() * 2;
	if (maxactive < 20)
		maxactive = 20;

	memset(&get_signal_krp, 0, sizeof(get_signal_krp));
	get_signal_krp.kp.symbol_name = "get_signal";
	get_signal_krp.entry_handler  = linyu_safe_signal_get_signal_entry;
	get_signal_krp.handler        = linyu_safe_signal_get_signal_return;
	get_signal_krp.data_size      = sizeof(struct gs_data);
	get_signal_krp.maxactive      = maxactive;

	ret = register_kretprobe(&get_signal_krp);
	if (ret) {
		linyu_warn("safe_signal: get_signal kretprobe failed: %d (non-fatal)\n", ret);
		
		return 0;
	}
	get_signal_krp_registered = true;

	linyu_info("safe_signal: initialized (maxactive=%d)\n", maxactive);
	return 0;
}

void linyu_safe_signal_cleanup(void)
{
	if (get_signal_krp_registered) {
		unregister_kretprobe(&get_signal_krp);
		get_signal_krp_registered = false;
	}
	linyu_safe_signal_areas_table_destroy();
}
