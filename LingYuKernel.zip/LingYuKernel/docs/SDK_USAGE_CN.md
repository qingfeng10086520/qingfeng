# LingYuKernel SDK 使用说明

本文档说明用户态程序如何对接 LingYuKernel 内核模块。SDK 位于 `sdk/lingyu_kernel_sdk.h`，示例位于 `sdk/examples/basic_usage.c`。

## 对接流程

1. 先将发行版模块加载到设备：

```sh
adb push out/LinYuKernel.ko /data/local/tmp/LinYuKernel.ko
adb shell 'su -c "insmod /data/local/tmp/LinYuKernel.ko"'
```

2. 在用户态程序中包含 SDK 头文件：

```c
#include "lingyu_kernel_sdk.h"
```

3. 调用 `lingyu_kernel_open()` 获取模块匿名 FD：

```c
int fd = lingyu_kernel_open();
if (fd < 0) {
    perror("lingyu_kernel_open");
    return 1;
}
```

4. 通过 SDK 封装函数或 `lingyu_kernel_ioctl()` 调用功能。

5. 使用完成后调用 `lingyu_kernel_close(fd)`。

## 核心接口

- `lingyu_kernel_open()`
  - 通过模块的 supercall 入口获取匿名 FD。
  - 成功返回可用于 ioctl 的 fd，失败返回 `-1` 并设置 `errno`。

- `lingyu_kernel_close(fd)`
  - 关闭匿名 FD。

- `lingyu_kernel_ioctl(fd, request, arg)`
  - 直接调用底层 ioctl。
  - 用于访问 SDK 暂未封装的功能。

- `lingyu_find_process(fd, name)`
  - 按进程名查找 PID。

- `lingyu_get_module_base(fd, pid, name, base, size)`
  - 查询目标进程内模块基址和大小。

- `lingyu_read_process_memory(fd, pid, vaddr, buf, size)`
  - 从目标进程虚拟地址读取内存。

- `lingyu_set_touch_mode(fd, mode)`
  - 切换触摸注入模式。

- `lingyu_touch_event(fd, action, slot, x, y)`
  - 发送触摸事件。
  - `action` 可取：
    - `LINGYU_TOUCH_UP`
    - `LINGYU_TOUCH_DOWN`
    - `LINGYU_TOUCH_MOVE`

## 编译示例

使用 Android NDK 交叉编译：

```sh
$ANDROID_NDK_HOME/toolchains/llvm/prebuilt/linux-x86_64/bin/aarch64-linux-android35-clang \
  -I sdk \
  sdk/examples/basic_usage.c \
  -o lingyu_example
```

如果在设备本地有可用 clang，也可以在设备上直接编译：

```sh
clang -I sdk sdk/examples/basic_usage.c -o lingyu_example
```

## 运行示例

```sh
adb push lingyu_example /data/local/tmp/lingyu_example
adb shell 'chmod 755 /data/local/tmp/lingyu_example'
adb shell 'su -c "/data/local/tmp/lingyu_example system_server"'
```

示例会：

1. 打开 LingYuKernel 匿名 FD。
2. 查找指定进程 PID，默认查找 `system_server`。
3. 尝试查询目标进程内 `libc.so` 的模块基址。
4. 关闭 FD。

## 直接 ioctl 示例

SDK 未封装的 ioctl 可以直接调用：

```c
struct linyu_is_alive_args args = {
    .pid = pid,
};

if (lingyu_kernel_ioctl(fd, LINYU_IS_PROCESS_ALIVE, &args) == 0)
    printf("alive=%d\n", args.alive);
```

## 注意事项

- 用户态结构体必须和内核侧 `src/comm.h` 保持一致。
- 目标程序需要能访问模块匿名 FD 入口，通常需要 root 环境。
- 模块可能自隐藏，所以加载后不一定能通过 `/proc/modules` 查看。
- 不同 Android/GKI 内核版本的符号和结构体布局可能不同，升级内核后需要重新验证。
