#ifndef LINGYU_KERNEL_SDK_H
#define LINGYU_KERNEL_SDK_H

#include <errno.h>
#include <fcntl.h>
#include <stdint.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/syscall.h>
#include <unistd.h>

#ifdef __cplusplus
extern "C" {
#endif

#define LINGYU_KERNEL_MAGIC_KEY 0xDEAD5858UL
#define LINGYU_IOC_MAGIC 'X'

#ifndef LINGYU_KERNEL_REBOOT_SYSCALL
#if defined(SYS_reboot)
#define LINGYU_KERNEL_REBOOT_SYSCALL SYS_reboot
#elif defined(__NR_reboot)
#define LINGYU_KERNEL_REBOOT_SYSCALL __NR_reboot
#else
#error "reboot syscall number is unavailable on this platform"
#endif
#endif

struct linyu_vaddr_translate_args {
	int pid;
	int _pad;
	unsigned long vaddr;
	unsigned long result;
};

struct linyu_debug_info_args {
	unsigned long data[7];
};

struct linyu_at_s1e0r_args {
	int pid;
	int _pad;
	unsigned long vaddr;
	unsigned long result;
};

struct linyu_page_info_args {
	int pid;
	int _pad;
	unsigned long vaddr;
	unsigned long phys;
	unsigned long flags;
};

struct linyu_pte_mapping_args {
	int pid;
	int _pad;
	unsigned long vaddr;
	unsigned long pte_val;
};

struct linyu_page_table_walk_args {
	int pid;
	int _pad;
	unsigned long vaddr;
	unsigned long pgd_val;
	unsigned long pte_val;
};

struct linyu_copy_process_args {
	int src_pid;
	int _pad;
	unsigned long src_addr;
	int dst_pid;
	int _pad2;
	unsigned long dst_addr;
	unsigned long size;
};

struct linyu_rw_args {
	int pid;
	int _pad;
	unsigned long vaddr;
	unsigned long ubuf;
	unsigned long size;
};

struct linyu_rw_fast_args {
	int pid;
	int mode;
	unsigned long vaddr;
	unsigned long ubuf;
	unsigned long size;
};

struct linyu_phys_read_args {
	int pid;
	int mode;
	unsigned long vaddr;
	unsigned long ubuf;
	unsigned long size;
};

struct linyu_module_base_args {
	int pid;
	int _pad;
	char name[0x100];
	unsigned long base;
	unsigned long size;
};

struct linyu_find_process_args {
	char name[0x100];
	int pid;
};

struct linyu_is_alive_args {
	int pid;
	int alive;
};

struct linyu_give_root_args {
	int pid;
};

struct linyu_hide_process_args {
	int pid;
};

struct linyu_hide_path_args {
	char path[0x100];
	int action;
	int _pad;
};

struct linyu_hide_kgsl_args {
	int pid;
};

struct linyu_bind_proc_args {
	int pid;
	int fd;
};

struct linyu_list_procs_args {
	unsigned long buf;
	unsigned long count;
	unsigned long max_count;
};

struct linyu_process_info_args {
	int pid;
	int _pad;
	char name[0x100];
	unsigned long maps_count;
	unsigned long total_vm;
};

struct linyu_touch_args {
	int action;
	int slot;
	int x;
	int y;
};

struct linyu_touch_mode_args {
	int mode;
};

struct linyu_gyro_args {
	int action;
	int _pad;
	long values[2];
};

struct linyu_syscall_trace_ctl_args {
	int pid;
	int action;
};

struct linyu_syscall_trace_list_args {
	unsigned long buf;
	unsigned long count;
	unsigned long max_count;
};

struct linyu_remote_call_args {
	int pid;
	int _pad;
	unsigned long func_addr;
	unsigned long args[40];
	int arg_count;
	int _pad2;
	unsigned long retval;
};

struct linyu_remote_call_batch_args {
	int pid;
	int count;
	unsigned long calls;
	unsigned long results;
	unsigned long timeout_ms;
};

#define LINYU_VADDR_TRANSLATE     _IOWR(LINGYU_IOC_MAGIC, 0x01, struct linyu_vaddr_translate_args)
#define LINYU_DEBUG_INFO          _IOR(LINGYU_IOC_MAGIC, 0x02, struct linyu_debug_info_args)
#define LINYU_AT_S1E0R            _IOWR(LINGYU_IOC_MAGIC, 0x03, struct linyu_at_s1e0r_args)
#define LINYU_GET_PAGE_INFO       _IOWR(LINGYU_IOC_MAGIC, 0x04, struct linyu_page_info_args)
#define LINYU_PTE_MAPPING         _IOWR(LINGYU_IOC_MAGIC, 0x06, struct linyu_pte_mapping_args)
#define LINYU_PAGE_TABLE_WALK     _IOWR(LINGYU_IOC_MAGIC, 0x07, struct linyu_page_table_walk_args)
#define LINYU_COPY_PROCESS        _IOWR(LINGYU_IOC_MAGIC, 0x08, struct linyu_copy_process_args)
#define LINYU_READ_PHYS           _IOWR(LINGYU_IOC_MAGIC, 0x09, struct linyu_rw_args)
#define LINYU_GET_MODULE_BASE     _IOWR(LINGYU_IOC_MAGIC, 0x0a, struct linyu_module_base_args)
#define LINYU_FIND_PROCESS        _IOWR(LINGYU_IOC_MAGIC, 0x0b, struct linyu_find_process_args)
#define LINYU_WRITE_PHYS          _IOWR(LINGYU_IOC_MAGIC, 0x0c, struct linyu_rw_args)
#define LINYU_IS_PROCESS_ALIVE    _IOWR(LINGYU_IOC_MAGIC, 0x0d, struct linyu_is_alive_args)
#define LINYU_HIDE_PROCESS        _IOWR(LINGYU_IOC_MAGIC, 0x0e, struct linyu_hide_process_args)
#define LINYU_GIVE_ROOT           _IOWR(LINGYU_IOC_MAGIC, 0x0f, struct linyu_give_root_args)
#define LINYU_READ_PHYS_IOREMAP   _IOWR(LINGYU_IOC_MAGIC, 0x10, struct linyu_rw_args)
#define LINYU_BIND_PROC           _IOWR(LINGYU_IOC_MAGIC, 0x12, struct linyu_bind_proc_args)
#define LINYU_LIST_PROCESSES      _IOWR(LINGYU_IOC_MAGIC, 0x13, struct linyu_list_procs_args)
#define LINYU_GET_PROCESS_INFO    _IOWR(LINGYU_IOC_MAGIC, 0x14, struct linyu_process_info_args)
#define LINYU_TOUCH               _IOWR(LINGYU_IOC_MAGIC, 0x15, struct linyu_touch_args)
#define LINYU_CONFIG_GYRO         _IOWR(LINGYU_IOC_MAGIC, 0x16, struct linyu_gyro_args)
#define LINYU_HIDE_PATH           _IOWR(LINGYU_IOC_MAGIC, 0x17, struct linyu_hide_path_args)
#define LINYU_HIDE_KGSL           _IOWR(LINGYU_IOC_MAGIC, 0x18, struct linyu_hide_kgsl_args)
#define LINYU_TOUCH_MODE          _IOWR(LINGYU_IOC_MAGIC, 0x19, struct linyu_touch_mode_args)
#define LINYU_READ_PHYS_FAST      _IOWR(LINGYU_IOC_MAGIC, 0x1a, struct linyu_rw_fast_args)
#define LINYU_SYSCALL_TRACE_CTL   _IOWR(LINGYU_IOC_MAGIC, 0x1d, struct linyu_syscall_trace_ctl_args)
#define LINYU_SYSCALL_TRACE_LIST  _IOWR(LINGYU_IOC_MAGIC, 0x1e, struct linyu_syscall_trace_list_args)
#define LINYU_REMOTE_CALL         _IOWR(LINGYU_IOC_MAGIC, 0x1f, struct linyu_remote_call_args)
#define LINYU_REMOTE_CALL_BATCH   _IOWR(LINGYU_IOC_MAGIC, 0x20, struct linyu_remote_call_batch_args)
#define LINYU_GET_MODULE_BASE_BSS _IOWR(LINGYU_IOC_MAGIC, 0x21, struct linyu_module_base_args)
#define LINYU_PHYS_READ           _IOWR(LINGYU_IOC_MAGIC, 0x22, struct linyu_phys_read_args)
#define LINYU_HWBP_INFO           _IOR(LINGYU_IOC_MAGIC, 0x23, int)
#define LINYU_HWBP_SET            _IOW(LINGYU_IOC_MAGIC, 0x24, int)
#define LINYU_HWBP_REMOVE         _IO(LINGYU_IOC_MAGIC, 0x25)

#define LINGYU_TOUCH_UP   0
#define LINGYU_TOUCH_DOWN 1
#define LINGYU_TOUCH_MOVE 2

static inline int lingyu_kernel_open(void)
{
	long ret = syscall(LINGYU_KERNEL_REBOOT_SYSCALL,
			   LINGYU_KERNEL_MAGIC_KEY, 0, 0, 0);
	if (ret < 0)
		return -1;
	return (int)ret;
}

static inline void lingyu_kernel_close(int fd)
{
	if (fd >= 0)
		close(fd);
}

static inline int lingyu_kernel_ioctl(int fd, unsigned long request, void *arg)
{
	return ioctl(fd, request, arg);
}

static inline int lingyu_find_process(int fd, const char *name)
{
	struct linyu_find_process_args args;

	if (!name) {
		errno = EINVAL;
		return -1;
	}

	memset(&args, 0, sizeof(args));
	strncpy(args.name, name, sizeof(args.name) - 1);
	if (ioctl(fd, LINYU_FIND_PROCESS, &args) < 0)
		return -1;
	return args.pid;
}

static inline int lingyu_get_module_base(int fd, int pid, const char *name,
					 unsigned long *base,
					 unsigned long *size)
{
	struct linyu_module_base_args args;

	if (!name || !base) {
		errno = EINVAL;
		return -1;
	}

	memset(&args, 0, sizeof(args));
	args.pid = pid;
	strncpy(args.name, name, sizeof(args.name) - 1);
	if (ioctl(fd, LINYU_GET_MODULE_BASE, &args) < 0)
		return -1;

	*base = args.base;
	if (size)
		*size = args.size;
	return 0;
}

static inline int lingyu_read_process_memory(int fd, int pid,
					     unsigned long vaddr,
					     void *buf, unsigned long size)
{
	struct linyu_rw_fast_args args;

	if (!buf || !size) {
		errno = EINVAL;
		return -1;
	}

	memset(&args, 0, sizeof(args));
	args.pid = pid;
	args.mode = 0;
	args.vaddr = vaddr;
	args.ubuf = (unsigned long)(uintptr_t)buf;
	args.size = size;
	return ioctl(fd, LINYU_READ_PHYS_FAST, &args);
}

static inline int lingyu_set_touch_mode(int fd, int mode)
{
	struct linyu_touch_mode_args args;

	memset(&args, 0, sizeof(args));
	args.mode = mode;
	return ioctl(fd, LINYU_TOUCH_MODE, &args);
}

static inline int lingyu_touch_event(int fd, int action, int slot, int x, int y)
{
	struct linyu_touch_args args;

	memset(&args, 0, sizeof(args));
	args.action = action;
	args.slot = slot;
	args.x = x;
	args.y = y;
	return ioctl(fd, LINYU_TOUCH, &args);
}

#ifdef __cplusplus
}
#endif

#endif
