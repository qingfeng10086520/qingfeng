#include "../lingyu_kernel_sdk.h"

#include <stdio.h>
#include <stdlib.h>

int main(int argc, char **argv)
{
	const char *process_name = argc > 1 ? argv[1] : "system_server";
	unsigned long base = 0;
	unsigned long size = 0;
	int fd;
	int pid;

	fd = lingyu_kernel_open();
	if (fd < 0) {
		perror("lingyu_kernel_open");
		return 1;
	}

	pid = lingyu_find_process(fd, process_name);
	if (pid < 0) {
		perror("lingyu_find_process");
		lingyu_kernel_close(fd);
		return 1;
	}
	printf("process %s pid=%d\n", process_name, pid);

	if (lingyu_get_module_base(fd, pid, "libc.so", &base, &size) == 0)
		printf("libc.so base=0x%lx size=0x%lx\n", base, size);
	else
		perror("lingyu_get_module_base");

	lingyu_kernel_close(fd);
	return 0;
}
